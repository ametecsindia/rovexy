@echo off
rem Builds the Play bundle and copies it here as 01-rovexy-1.0.0-vc1.aab
cd /d "%~dp0..\android"
call gradlew.bat clean :app:bundlePlayRelease || (echo BUILD FAILED & pause & exit /b 1)
copy /y "app\build\outputs\bundle\playRelease\app-play-release.aab" "%~dp001-rovexy-1.0.0-vc1.aab"
echo Done: %~dp001-rovexy-1.0.0-vc1.aab
pause
