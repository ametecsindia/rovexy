import numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt
SR=44100; DUR=64.4; N=int(SR*DUR); t=np.arange(N)/SR
bpm=92; beat=60/bpm; bar=4*beat
def hz(m): return 440*2**((m-69)/12)
# chords as midi notes (D major colours)
chords=[[50,57,62,66,69,73],[47,54,59,62,66,69],[43,50,55,59,62,66],[45,52,57,61,64,66]]
roots=[38,35,31,33]
mix=np.zeros(N)
def env_ad(n,a,d):
    e=np.ones(n); ai=int(a*SR); di=int(d*SR)
    e[:ai]=np.linspace(0,1,ai); e[-di:]=np.linspace(1,0,di); return e
seg=2*bar
k=0; s=0.0
rng=np.random.default_rng(7)
while s<DUR:
    i0=int(s*SR); n=min(int(seg*SR)+int(0.8*SR),N-i0)
    if n<=0: break
    tt=np.arange(n)/SR; ch=chords[k%4]; e=env_ad(n,0.9,1.4)
    pad=np.zeros(n)
    for m in ch:
        f=hz(m)
        for det in (-0.12,0.12):
            ff=f*2**(det/12)
            pad+= (np.sin(2*np.pi*ff*tt)+0.25*np.sin(2*np.pi*2*ff*tt)+0.08*np.sin(2*np.pi*3*ff*tt))
    mix[i0:i0+n]+=pad*e*0.018
    # sub bass
    fb=hz(roots[k%4]); mix[i0:i0+n]+=np.sin(2*np.pi*fb*tt)*env_ad(n,0.3,1.0)*0.05
    # arpeggio bell: 8th notes over chord tones up an octave
    for j in range(int(seg/(beat/2))):
        st=i0+int(j*beat/2*SR); m=ch[[1,2,3,4,3,2,5,3][j%8]]+12; f=hz(m)
        ln=int(1.2*SR); ln=min(ln,N-st)
        if ln<=0: continue
        u=np.arange(ln)/SR
        bell=(np.sin(2*np.pi*f*u)+0.3*np.sin(2*np.pi*f*2.01*u))*np.exp(-u*4.5)
        vel=0.7+0.3*rng.random()
        if s>4.0: mix[st:st+ln]+=bell*0.020*vel
    s+=seg; k+=1
# soft hats on off-beats after intro
for j in range(int(DUR/beat)):
    ts=j*beat+beat/2
    if ts<4.2 or ts>DUR-4: continue
    st=int(ts*SR); ln=int(0.06*SR)
    nz=rng.standard_normal(ln)*np.exp(-np.arange(ln)/SR*70)
    mix[st:st+ln]+=nz*0.006
sos=butter(4,7000,'low',fs=SR,output='sos'); mix=sosfilt(sos,mix)
sos=butter(2,40,'high',fs=SR,output='sos'); mix=sosfilt(sos,mix)
# simple stereo reverb-ish: delays
L=mix.copy(); R=mix.copy()
for d,g in ((0.031,0.35),(0.047,0.3),(0.089,0.22),(0.137,0.15)):
    o=int(d*SR); L[o:]+=mix[:-o]*g; o2=int((d*1.13)*SR); R[o2:]+=mix[:-o2]*g
st=np.stack([L,R],1)
fade=np.ones(N); fi=int(2.0*SR); fo=int(3.5*SR); fade[:fi]=np.linspace(0,1,fi)**2; fade[-fo:]=np.linspace(1,0,fo)**1.5
st*=fade[:,None]; st/=np.max(np.abs(st))*1.12
sf.write('music.wav',st,SR); print('ok',st.shape)
