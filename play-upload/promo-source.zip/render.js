const { chromium } = require('playwright');
const { spawn } = require('child_process');
(async () => {
  const FPS = 30;
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  await p.goto('http://127.0.0.1:8777/index.html'); await p.waitForTimeout(1500);
  await p.evaluate(async () => { for (const i of document.images) if (!i.complete) await new Promise(r => i.onload = r); });
  // preload every screen image so crossfades never show a blank frame
  await p.evaluate(async () => { const n = new Set(); for (const s of Object.values(SC)) for (const [, im] of s.img) n.add(im);
    await Promise.all([...n].map(x => new Promise(r => { const i = new Image(); i.onload = r; i.src = `img/${x}.png`; }))); });
  const total = await p.evaluate(() => TOTAL); const frames = Math.round(total * FPS);
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-',
    '-i', 'mix.wav', '-c:v', 'libx264', '-preset', 'slow', '-crf', '16', '-profile:v', 'high', '-pix_fmt', 'yuv420p', '-r', String(FPS),
    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-shortest', '-movflags', '+faststart', 'ROVEXY-Promo-1080x1920.mp4'], { stdio: ['pipe', 'inherit', 'inherit'] });
  for (let i = 0; i < frames; i++) {
    await p.evaluate((t) => render(t), i / FPS);
    const buf = await p.screenshot({ type: 'jpeg', quality: 95 });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (i % 300 === 0) console.log('frame', i, '/', frames);
  }
  ff.stdin.end(); await new Promise(r => ff.on('close', r)); await b.close(); console.log('done', frames);
})();
