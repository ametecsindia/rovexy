import json, soundfile as sf, numpy as np
from kokoro_onnx import Kokoro
k=Kokoro('/home/claude/tts/kokoro.onnx','/home/claude/tts/voices.bin')
L=[("s0","Meet Roh-vexy."),
("s1","The work app for collection agencies and their field teams. Calls, visits and payments, all on record."),
("s2","Each day starts with prioritised cases. Dues, follow-ups and progress, at a glance."),
("s3","Open a case to call the customer, set a callback, record a payment, or get directions."),
("s4","Calls go out from the employee's own phone. The recording and the call outcome are saved together."),
("s5","Collect payments on the spot, with the mode, reference and a slip photo, for the office to verify."),
("s6","Customers near me shows who to visit next. Navigate there, and check in at the address."),
("s7","Supervisors can message, call over the internet, or ask to see the screen, only when the employee accepts."),
("s8","Transparent by design. Built for collections. Connected to your office, in real time."),
("s9","Roh-vexy. Your workforce, in motion.")]
out={}
for key,t in L:
    a,sr=k.create(t,voice='af_heart',speed=0.98,lang='en-us')
    # trim silence
    idx=np.where(np.abs(a)>0.01)[0]; a=a[max(0,idx[0]-1200):idx[-1]+2400]
    sf.write(f'{key}.wav',a,sr); out[key]=round(len(a)/sr,2)
json.dump(out,open('vo.json','w')); print(out, sum(out.values()))
