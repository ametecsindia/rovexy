// screen events: [secondsIntoScene, image]; highlights: [from, to, x, y, w, h] in 1170x2526 image pixels
const SC = {
 s1:{side:'R', eb:'01 · INTRODUCING', hd:['Field','collections,','<g>on record.'], sb:'For collection agencies and their field teams.', ch:['Calls','Visits','Payments'],
     img:[[0,'S1-login']], hl:[]},
 s2:{side:'L', eb:'02 · CASES', hd:['Your','day,','<g>prioritised.'], sb:'Dues, follow-ups and progress at a glance.', ch:['Overdue','Due today','Promises today'],
     img:[[0,'S2-cases']], hl:[[1.0,3.0,50,794,1067,214],[3.2,6.4,50,1455,1080,202]]},
 s3:{side:'R', eb:'03 · CASE DETAIL', hd:['Every','case','in','<g>one','<g>place.'], sb:'Everything you need before you act.', ch:['Call','Callback','Payment','Directions'],
     img:[[0,'S3-case-detail']], hl:[[1.0,5.8,38,655,1095,192]]},
 s4:{side:'L', eb:'04 · CALLS', hd:['Every','call','<g>on','<g>record.'], sb:"Placed from your own phone. The recording and outcome are saved together.", ch:['Recording saved','Call outcome'],
     img:[[0,'X-feedback']], hl:[[1.2,3.4,134,321,901,120],[3.6,6.3,134,555,901,1300]]},
 s5:{side:'R', eb:'05 · PAYMENTS', hd:['Payments','<g>on','<g>the','<g>spot.'], sb:'Amount, mode, reference and slip photo, for the office to verify.', ch:['UPI · Cash · Cheque','Reference / UTR','Slip photo'],
     img:[[0,'S5-call-result']], hl:[[1.0,2.4,134,602,901,166],[2.5,4.0,134,855,901,405],[4.1,6.4,134,1675,700,115]]},
 s6:{side:'L', eb:'06 · FIELD VISITS', hd:['Customers','<g>near','<g>you.'], sb:'See who to visit next, navigate and check in at the address.', ch:['Nearest customer','Navigation','Check-in'],
     img:[[0,'X-map'],[1.8,'X-map-near'],[3.8,'X-map-checked']], hl:[[2.3,3.7,100,2312,970,164],[4.0,5.9,100,2312,970,164]]},
 s7:{side:'R', eb:'07 · SUPERVISION', hd:['Your','supervisor,','<g>one','<g>tap','<g>away.'], sb:'Chat, voice calls and screen sharing, only when you accept.', ch:['Chat','Voice call','Screen share'],
     img:[[0,'X-chat'],[2.0,'X-voice-incoming'],[3.7,'X-screen-request'],[5.5,'X-screen-sharing']], hl:[]},
};
const BEN = [
 ['shield','Transparent by design','A ROVEXY notification is shown whenever location, a call or a session is active.'],
 ['case','Built for collections','Outcomes, promises, payments and slips, with every call.'],
 ['link','Connected to your office','Live status, recordings and payments in the web console.'],
];
const ICONS = {
 shield:'<svg width="50" height="50" viewBox="0 0 24 24" fill="#0B1A2E"><path d="M12 2 4 5v6c0 5 3.4 9.7 8 11 4.6-1.3 8-6 8-11V5l-8-3zm-1.2 14.2-3.5-3.5 1.4-1.4 2.1 2.1 4.9-4.9 1.4 1.4-6.3 6.3z"/></svg>',
 case:'<svg width="50" height="50" viewBox="0 0 24 24" fill="#0B1A2E"><path d="M10 3h4a2 2 0 0 1 2 2v1h4a1 1 0 0 1 1 1v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a1 1 0 0 1 1-1h4V5a2 2 0 0 1 2-2zm0 3h4V5h-4v1z"/></svg>',
 link:'<svg width="50" height="50" viewBox="0 0 24 24" fill="#0B1A2E"><path d="M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-6v2h3v2H7v-2h3v-2H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm1 2v9h14V6H5z"/></svg>',
};
