const $ = (id) => document.getElementById(id);
const cl = (x) => Math.max(0, Math.min(1, x));
const eo = (x) => 1 - Math.pow(1 - cl(x), 3);              // ease out
const eio = (x) => { x = cl(x); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
const ORDER = ['s0','s1','s2','s3','s4','s5','s6','s7','s8','s9'];
const TOTAL = TL.s9.start + TL.s9.dur;
const K = 520 / 1170;                                          // image px → screen px
const PH = { R: 480, L: 40 }, TXT = { R: 60, L: 630 }, PHY = 380;
let built = null;

function buildText(id) {
  const s = SC[id];
  const hd = s.hd.map((w) => w.startsWith('<g>') ? `<span class="g">${w.slice(3)}</span>` : `<span>${w}</span>`).join('');
  $('tx').innerHTML = `<div class="eb a"><i></i>${s.eb}</div><div class="hd">${hd}</div><div class="sb a">${s.sb}</div>`
    + `<div class="ch">${s.ch.map((c) => `<div class="c a"><b></b>${c}</div>`).join('')}</div>`;
}
function buildBen() {
  $('bn').innerHTML = `<div class="bh a">WHY ROVEXY</div><div class="bt a">Made for teams<br>in the field</div>`
    + BEN.map(([i, h, p]) => `<div class="cd a"><div class="ic">${ICONS[i]}</div><div><h3>${h}</h3><p>${p}</p></div></div>`).join('');
}
function fadeIn(el, lt, d, dy = 34) { const e = eo((lt - d) / 0.7); el.style.opacity = e; el.style.transform = `translateY(${(1 - e) * dy}px)`; }

function render(t) {
  // background motion
  $('g1').style.transform = `translate(${-200 + Math.sin(t * .23) * 160}px, ${120 + Math.cos(t * .17) * 140}px)`;
  $('g2').style.transform = `translate(${300 + Math.cos(t * .19) * 180}px, ${900 + Math.sin(t * .21) * 160}px)`;
  $('dots').style.transform = `translateY(${-(t * 6) % 44}px)`;
  $('streak').style.transform = `translateX(${-900 + ((t * 70) % 2400)}px) rotate(24deg)`;
  $('bar').style.width = (t / TOTAL * 1080) + 'px';
  let id = ORDER[0]; for (const k of ORDER) if (t >= TL[k].start) id = k;
  const sc = TL[id], lt = t - sc.start, rem = sc.dur - lt;
  const idx = ORDER.indexOf(id);

  // opening
  const op = $('op');
  if (id === 's0') {
    op.style.display = 'flex'; op.style.top = '700px';
    const img = op.children[0], rule = op.children[1], tag = op.children[2];
    const e = eo(lt / 1.1); img.style.opacity = e; img.style.transform = `scale(${0.86 + e * 0.14})`; img.style.filter = `blur(${(1 - e) * 12}px)`;
    rule.style.opacity = eo((lt - .8) / .6); rule.style.width = (eo((lt - .8) / .8) * 120) + 'px';
    fadeIn(tag, lt, 1.2);
    op.style.opacity = 1 - eo((lt - (sc.dur - .55)) / .55);
  } else op.style.display = 'none';
  $('top').style.opacity = id === 's0' || id === 's9' ? 0 : eo((t - TL.s1.start) / .8);

  // phone
  const ph = $('ph'), inPhone = idx >= 1 && idx <= 7;
  const showPh = inPhone || (id === 's8' && lt < .8);
  ph.style.display = showPh ? 'block' : 'none';
  if (showPh) {
    let side = id === 's8' ? SC.s7.side : SC[id].side;
    let x = PH[side], y = PHY + Math.sin(t * .9) * 7, op = 1, sc2 = 1;
    if (id === 's1') { const e = eio(lt / 1.0); y += (1 - e) * 700; op = e; }
    else if (id !== 's8') { const prev = SC[ORDER[idx - 1]].side; if (prev !== side) x = PH[prev] + (PH[side] - PH[prev]) * eio(lt / .9); }
    if (id === 's8') { const e = eio(lt / .8); y += e * 700; op = 1 - e; }
    ph.style.transform = `translate(${x}px, ${y}px) scale(${sc2})`; ph.style.opacity = op;
    // screens
    const evs = [];
    for (const k of ORDER.slice(1, 8)) for (const [d, im] of SC[k].img) evs.push([TL[k].start + d, im]);
    let i = 0; for (let j = 0; j < evs.length; j++) if (t >= evs[j][0]) i = j;
    const ia = $('ia'), ib = $('ib'), cur = evs[i], prv = evs[Math.max(0, i - 1)];
    const want = `img/${cur[1]}.png`, wantP = `img/${prv[1]}.png`;
    if (!ib.src.endsWith(want)) ib.src = want; if (!ia.src.endsWith(wantP)) ia.src = wantP;
    ib.style.opacity = i === 0 ? 1 : eo((t - cur[0]) / .45);
    // highlight
    const hl = $('hl'); let on = null;
    if (SC[id]) for (const h of SC[id].hl) if (lt >= h[0] && lt <= h[1]) on = h;
    if (on) {
      const a = eo((lt - on[0]) / .35) * (1 - eo((lt - (on[1] - .3)) / .3)), p = .5 + .5 * Math.sin((lt - on[0]) * 5);
      hl.style.display = 'block'; hl.style.opacity = a;
      hl.style.left = (on[2] * K - 6) + 'px'; hl.style.top = (on[3] * K - 6) + 'px'; hl.style.width = (on[4] * K + 12) + 'px'; hl.style.height = (on[5] * K + 12) + 'px';
      hl.style.boxShadow = `0 0 ${18 + p * 22}px rgba(212,174,106,${.55 + p * .3}), inset 0 0 0 9999px rgba(212,174,106,.07)`;
    } else hl.style.display = 'none';
  }

  // side text
  const tx = $('tx');
  if (SC[id]) {
    if (built !== id) { buildText(id); built = id; }
    tx.style.display = 'block'; tx.style.left = TXT[SC[id].side] + 'px';
    tx.style.top = (960 - tx.offsetHeight / 2) + 'px';
    const out = 1 - eo((lt - (sc.dur - .45)) / .45);
    tx.style.opacity = out;
    const a = tx.querySelectorAll('.a'), words = tx.querySelectorAll('.hd span');
    fadeIn(a[0], lt, .25);
    words.forEach((w, k) => fadeIn(w, lt, .45 + k * .12, 40));
    fadeIn(a[1], lt, .9 + words.length * .1);
    for (let k = 2; k < a.length; k++) fadeIn(a[k], lt, 1.4 + words.length * .1 + (k - 2) * .35, 24);
  } else tx.style.display = 'none';

  // benefits
  const bn = $('bn');
  if (id === 's8') {
    if (built !== id) { buildBen(); built = id; }
    bn.style.display = 'block'; bn.style.top = (980 - bn.offsetHeight / 2) + 'px';
    bn.style.opacity = 1 - eo((lt - (sc.dur - .45)) / .45);
    const a = bn.querySelectorAll('.a'); fadeIn(a[0], lt, .3); fadeIn(a[1], lt, .5);
    const d = [0, 1.45, 2.9].map((x) => x + (sc.vo - sc.start));
    for (let k = 0; k < 3; k++) { const el = a[2 + k], e = eo((lt - d[k]) / .7); el.style.opacity = e; el.style.transform = `translateX(${(1 - e) * 120}px)`; }
  } else bn.style.display = 'none';

  // ending
  const en = $('en');
  if (id === 's9') {
    en.style.display = 'flex'; en.style.top = '680px';
    const [img, rule, sm, tag] = en.children;
    const e = eo(lt / 1.0); img.style.opacity = e; img.style.transform = `scale(${0.9 + e * 0.1})`;
    rule.style.width = (eo((lt - .6) / .8) * 120) + 'px';
    fadeIn(sm, lt, 1.0); fadeIn(tag, lt, 1.3);
    en.style.opacity = 1 - eo((lt - (sc.dur - .6)) / .6) * .0;
  } else en.style.display = 'none';
}
const _r = render;
render = function (t) { _r(t);
  const c = CAPS.find(([a, b]) => t >= a && t <= b + .25), el = $('cap');
  if (c) { if (el.dataset.k !== c[2]) { el.innerHTML = `<span>${c[2]}</span>`; el.dataset.k = c[2]; }
    el.style.opacity = eo((t - c[0]) / .2) * (1 - eo((t - c[1] - .05) / .2)); el.style.top = (TL.s8.start <= t && t < TL.s9.start ? 1720 : 1640) + 'px'; }
  else el.style.opacity = 0;
};
window.render = render; window.TOTAL = TOTAL;
render(0);
