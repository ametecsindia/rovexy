import json, numpy as np, soundfile as sf
from scipy.signal import resample_poly
SR=44100; m,_=sf.read('music.wav'); N=len(m)
tl=json.load(open('timeline.json')); vo=np.zeros(N); act=np.zeros(N)
for s in tl:
    a,sr=sf.read(f"{s['id']}.wav"); a=resample_poly(a,147,80); i=int(s['vo']*SR)
    n=min(len(a),N-i); vo[i:i+n]+=a[:n]; act[i:i+n]=1
vo/=np.max(np.abs(vo)); vo*=0.89
# ducking envelope (attack 0.25 s, release 0.6 s)
k=int(0.25*SR); env=np.convolve(act,np.ones(k)/k,'same'); env=np.clip(env*1.6,0,1)
r=int(0.6*SR); env=np.maximum(env,np.convolve(env,np.ones(r)/r,'same'))
g=10**(-15/20)*(1-env)+10**(-24/20)*env      # music level: -15 dB alone, -24 dB under voice
out=m*g[:,None]+vo[:,None]
out/=max(1,np.max(np.abs(out))/0.97)
sf.write('mix.wav',out,SR); print('ok', len(out)/SR)
