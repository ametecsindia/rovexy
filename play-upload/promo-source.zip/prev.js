const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  p.on('pageerror', e => console.log('ERR', e.message)); p.on('console', m => console.log('LOG', m.text()));
  await p.goto('http://127.0.0.1:8777/index.html'); await p.waitForTimeout(1500);
  for (const t of process.argv.slice(2)) { await p.evaluate(t => render(+t), t); await p.waitForTimeout(150); await p.screenshot({ path: `pv-${t}.jpg`, quality: 80 }); }
  await b.close();
})();
