<?php

namespace Tests\Feature;

use App\Models\Call;
use App\Models\Company;
use App\Models\Customer;
use App\Models\ManagedDevice;
use App\Models\PolicyAcknowledgement;
use App\Models\Recording;
use App\Models\Role;
use App\Models\User;
use App\Domain\Policy\PolicyCatalog;
use App\Services\CallService;
use App\Support\CurrentCompany;
use App\Telephony\TelephonyManager;
use Database\Seeders\CompanyDefaults;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Support\FakeTelephony;
use Tests\Support\MobileClient;
use Tests\TestCase;

/**
 * Server-side acceptance criteria (numbers refer to the brief's §20). NOTE: written while composer could not run in the
 * build environment — execute with `php artisan test` after `composer install`.
 */
final class AcceptanceTest extends TestCase
{
    use RefreshDatabase;

    private Company $a;
    private Company $b;
    private array $users = [];
    private FakeTelephony $tel;

    protected function setUp(): void
    {
        parent::setUp();
        $this->tel = new FakeTelephony();
        app(TelephonyManager::class)->swap($this->tel);
        $this->a = $this->company('alpha');
        $this->b = $this->company('bravo');
    }

    private function company(string $slug): Company
    {
        $c = Company::query()->create(['slug' => $slug, 'name' => ucfirst($slug), 'timezone' => 'UTC', 'default_country' => 'IN']);
        app(CurrentCompany::class)->run($c, function () use ($c, $slug) {
            CompanyDefaults::apply($c);
            $mk = function (string $code, string $role, ?string $email = null) use ($c) {
                $u = User::query()->create(['employee_code' => $code, 'name' => $code, 'email' => $email, 'phone' => '+919811111111', 'password' => 'Secret-123456', 'status' => 'active', 'mfa_enabled_at' => now()]);
                $u->roles()->attach(Role::query()->where('key', $role)->value('id'), ['company_id' => $c->id]);
                return $u;
            };
            $this->users[$slug] = ['admin' => $mk('admin', 'company_admin', "admin@{$slug}.test"), 'emp' => $mk('EMP1', 'employee'), 'emp2' => $mk('EMP2', 'employee')];
            Customer::query()->create(['customer_ref' => 'C1', 'name' => 'Cust', 'phone' => '+919876543210', 'status' => 'new', 'assigned_user_id' => $this->users[$slug]['emp']->id]);
            Customer::query()->create(['customer_ref' => 'C2', 'name' => 'Other', 'phone' => '+919876500000', 'status' => 'new', 'assigned_user_id' => $this->users[$slug]['emp2']->id]);
        });
        return $c;
    }

    private function admin(string $slug)
    {
        return $this->actingAs($this->users[$slug]['admin'], 'web')
            ->withSession(['mfa_verified_at' => time(), 'auth_started_at' => time()])
            ->withHeaders(['X-Workspace' => $slug, 'Referer' => 'http://localhost/']); // Sanctum treats it as the SPA
    }

    private function approvedPhone(string $slug = 'alpha', string $emp = 'emp'): MobileClient
    {
        $m = new MobileClient($this, $slug);
        $code = $m->register()->assertCreated()->json('approval_code');
        $device = app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->firstOrFail());
        $this->admin($slug)->postJson("/api/admin/devices/{$device->id}/approve", ['code' => $code, 'user_id' => $this->users[$slug][$emp]->id])->assertOk();
        $m->deviceToken = $m->signed('POST', '/api/mobile/v1/device/session')->assertOk()->json('device_token');
        return $m;
    }

    private function login(MobileClient $m, string $code = 'EMP1'): void
    {
        $r = $m->deviceCall('POST', '/api/mobile/v1/auth/login', ['employee_code' => $code, 'password' => 'Secret-123456'])->assertOk();
        [$m->accessToken, $m->refreshToken] = [$r->json('access_token'), $r->json('refresh_token')];
    }

    private function ackAll(MobileClient $m, bool $verified = true): void
    {
        $fp = $m->deviceCall('GET', '/api/mobile/v1/policy')->assertOk()->json('fingerprint');
        $results = array_fill_keys(array_keys(PolicyCatalog::all()), ['status' => 'applied', 'verified' => $verified]);
        $m->deviceCall('POST', '/api/mobile/v1/policy/ack', ['fingerprint' => $fp, 'results' => $results])->assertOk();
    }

    /** Device-level controls report requires_setup in app_only mode, so for these server tests mandatory = app-level only. */
    private function appOnlyMandatory(): void
    {
        app(CurrentCompany::class)->run($this->a, function () {
            $p = \App\Models\PolicyProfile::query()->first();
            $v = \App\Models\PolicyVersion::query()->where('profile_id', $p->id)->first();
            $v->forceFill(['settings' => $v->settings + ['compliance.mandatory' => ['calling.enabled', 'recording.mode'],
                'calling.hours' => ['days' => [1, 2, 3, 4, 5, 6, 7], 'start' => '00:00', 'end' => '23:59']]])->save();
        });
    }

    public function test_1_and_2_unapproved_phone_and_device_id_alone_get_nothing(): void
    {
        $m = new MobileClient($this, 'alpha');
        $m->register()->assertCreated()->assertJsonPath('state', 'pending')->assertJsonMissingPath('device_token');
        $m->signed('POST', '/api/mobile/v1/device/session')->assertStatus(403);
        // Device ID / installation ID without the private key:
        $this->withHeaders(['X-Workspace' => 'alpha', 'X-Installation-Id' => $m->installationId, 'X-Timestamp' => (string) time(), 'X-Nonce' => str_repeat('a', 20), 'X-Signature' => base64_encode('x')])
            ->postJson('/api/mobile/v1/device/session')->assertStatus(401);
        $this->withHeaders(['X-Workspace' => 'alpha'])->getJson('/api/mobile/v1/customers')->assertStatus(401);
        $this->withHeaders(['X-Workspace' => 'alpha'])->getJson('/api/mobile/v1/me?device=1&app=1')->assertStatus(401);
    }

    public function test_3_approved_device_with_unassigned_employee_cannot_work(): void
    {
        $m = $this->approvedPhone();
        $m->deviceCall('POST', '/api/mobile/v1/auth/login', ['employee_code' => 'EMP2', 'password' => 'Secret-123456'])->assertStatus(403)->assertJsonPath('error', 'not_assigned');
    }

    public function test_4_company_isolation(): void
    {
        $m = $this->approvedPhone('alpha');
        // Same token presented against company B's workspace: rejected.
        $m2 = new MobileClient($this, 'bravo');
        $m2->deviceToken = $m->deviceToken;
        $m2->deviceCall('GET', '/api/mobile/v1/policy')->assertStatus(401);
        // Admin of B cannot see or act on A's device/calls.
        $deviceA = app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->first());
        $this->admin('bravo')->getJson("/api/admin/devices/{$deviceA->id}")->assertNotFound();
        $this->admin('bravo')->postJson("/api/admin/devices/{$deviceA->id}/revoke", ['reason' => 'x'])->assertNotFound();
        // Admin session of A presented with B workspace: rejected by MFA/company guard.
        $this->admin('alpha')->withHeaders(['X-Workspace' => 'bravo'])->getJson('/api/admin/overview')->assertStatus(403);
        // Unknown and conflicting workspace: rejected, never defaulted.
        $this->withHeaders(['X-Workspace' => 'nope'])->getJson('/api/mobile/v1/bootstrap')->assertNotFound();
    }

    public function test_5_and_6_revocation_is_immediate_and_reapproval_issues_fresh_credentials(): void
    {
        $this->appOnlyMandatory();
        $m = $this->approvedPhone();
        $this->login($m);
        $m->work('GET', '/api/mobile/v1/me')->assertOk();
        $device = app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->first());
        $this->admin('alpha')->postJson("/api/admin/devices/{$device->id}/revoke", ['reason' => 'lost'])->assertOk();
        $m->work('GET', '/api/mobile/v1/me')->assertStatus(401);           // next request: blocked (bound = 0 s online)
        $m->deviceCall('GET', '/api/mobile/v1/policy')->assertStatus(401);
        $m->signed('GET', '/api/mobile/v1/device/status')->assertOk()->assertJsonPath('state', 'revoked');
        $m->signed('POST', '/api/mobile/v1/auth/refresh', ['refresh_token' => $m->refreshToken])->assertStatus(401);
        // Re-approval requires a new registration (new key); the old key can never come back.
        $m->register()->assertStatus(200)->assertJsonPath('state', 'revoked');
        $fresh = $this->approvedPhone();
        $this->assertNotSame($fresh->deviceToken, $m->deviceToken);
        $m->deviceCall('GET', '/api/mobile/v1/policy')->assertStatus(401);
    }

    public function test_7_duplicate_registration_is_idempotent_and_key_conflict_rejected(): void
    {
        $m = new MobileClient($this, 'alpha');
        $c1 = $m->register()->assertCreated()->json('approval_code');
        $c2 = $m->register()->assertOk()->json('approval_code');
        $this->assertSame($c1, $c2);
        $this->assertSame(1, app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->count()));
        $evil = new MobileClient($this, 'alpha');
        $evil->installationId = $m->installationId;
        $evil->register()->assertStatus(422)->assertJsonPath('error', 'installation_conflict');
    }

    public function test_8_and_9_unsupported_controls_reported_and_noncompliance_blocks_work(): void
    {
        $m = $this->approvedPhone();
        $this->login($m);
        $policy = $m->deviceCall('GET', '/api/mobile/v1/policy')->json();
        $this->assertSame('requires_setup', $policy['controls']['device.camera']['status']);   // app_only: honest
        $this->ackAll($m);   // app CLAIMS all applied…
        $m->work('GET', '/api/mobile/v1/customers')->assertStatus(403)->assertJsonPath('error', 'device_not_compliant'); // …server disagrees
    }

    public function test_10_call_restrictions_enforced_server_side(): void
    {
        $this->appOnlyMandatory();
        $m = $this->approvedPhone();
        $this->login($m);
        $this->ackAll($m);
        $ids = $m->work('GET', '/api/mobile/v1/customers')->assertOk()->json('visible_ids');
        $this->assertCount(1, $ids);
        $other = app(CurrentCompany::class)->withoutScope(fn () => Customer::query()->where('company_id', $this->a->id)->where('customer_ref', 'C2')->value('id'));
        $m->work('POST', '/api/mobile/v1/calls', ['customer_id' => $other, 'which' => 'primary'])->assertStatus(422)->assertJsonPath('error', 'customer_not_assigned');
        $m->work('POST', '/api/mobile/v1/calls', ['customer_id' => $ids[0], 'which' => 'primary', 'number' => '+911800000000'])->assertJsonPath('error', 'destination_mismatch');
        $m->work('POST', '/api/mobile/v1/calls', ['customer_id' => null, 'which' => 'primary', 'number' => '+911800000000'])->assertJsonPath('error', 'manual_dial_disabled');
        $m->work('POST', '/api/mobile/v1/calls', ['customer_id' => $ids[0], 'which' => 'primary'])->assertCreated();
        $this->assertSame('919876543210', ltrim($this->tel->originated[0]['customer_e164'], '+'));
    }

    public function test_11_and_12_duplicate_events_and_recording_failure_visible(): void
    {
        $this->appOnlyMandatory();
        $m = $this->approvedPhone();
        $this->login($m);
        $this->ackAll($m);
        $cid = $m->work('GET', '/api/mobile/v1/customers')->json('visible_ids')[0];
        $uuid = $m->work('POST', '/api/mobile/v1/calls', ['customer_id' => $cid, 'which' => 'primary'])->json('call_id');
        $svc = app(CallService::class);
        $ev = fn ($type, $id, $at, $extra = []) => $svc->ingest(['call_id' => $uuid, 'company_id' => $this->a->id, 'provider_event_id' => $id, 'type' => $type, 'at' => $at] + $extra);
        $this->assertSame('applied', $ev('agent_answered', 'e1', '2026-10-01T06:00:05Z'));
        $this->assertSame('duplicate', $ev('agent_answered', 'e1', '2026-10-01T06:00:05Z'));
        $ev('customer_answered', 'e2', '2026-10-01T06:00:10Z');
        $ev('hangup', 'e3', '2026-10-01T06:01:10Z', ['cause' => 'NORMAL_CLEARING']);
        $this->assertSame('duplicate', $ev('hangup', 'e3', '2026-10-01T06:01:10Z', ['cause' => 'NORMAL_CLEARING']));
        $call = app(CurrentCompany::class)->withoutScope(fn () => Call::query()->where('uuid', $uuid)->first());
        $this->assertSame('completed', $call->state);
        $this->assertSame(60, $call->talk_seconds);
        $this->assertSame(1, app(CurrentCompany::class)->withoutScope(fn () => Call::query()->where('uuid', $uuid)->count()));
        // No recording file exists → FetchRecording (sync queue) ends Failed, never Available.
        $rec = app(CurrentCompany::class)->withoutScope(fn () => Recording::query()->where('call_id', $call->id)->first());
        $this->assertNotSame('available', $rec->status);
        // Wrong company tag on an event is ignored.
        $this->assertSame('ignored', $svc->ingest(['call_id' => $uuid, 'company_id' => $this->b->id, 'provider_event_id' => 'x', 'type' => 'hangup', 'at' => '2026-10-01T06:02:00Z']));
    }

    public function test_13_and_14_offline_sync_idempotent_and_lease_enforced(): void
    {
        $this->appOnlyMandatory();
        $m = $this->approvedPhone();
        $this->login($m);
        $evt = ['id' => (string) \Illuminate\Support\Str::uuid(), 'type' => 'activity', 'occurred_at' => now()->subMinute()->toAtomString(), 'payload' => ['type' => 'idle_start']];
        $m->work('POST', '/api/mobile/v1/sync', ['events' => [$evt]])->assertJsonPath('results.0.result', 'accepted');
        $m->work('POST', '/api/mobile/v1/sync', ['events' => [$evt]])->assertJsonPath('results.0.result', 'duplicate');
        $late = ['id' => (string) \Illuminate\Support\Str::uuid(), 'type' => 'activity', 'occurred_at' => now()->addMinutes(2)->toAtomString(), 'payload' => ['type' => 'idle_end']];
        app(CurrentCompany::class)->withoutScope(fn () => \App\Models\WorkSession::query()->whereNull('ended_at')->update(['lease_expires_at' => now()->subMinute()]));
        $this->travel(2)->minutes();
        // Lease expired before the event happened → rejected.
        $late['occurred_at'] = now()->toAtomString();
        $m->work('POST', '/api/mobile/v1/sync', ['events' => [$late]])->assertJsonPath('results.0.reason', 'event_after_lease_expiry');
    }

    public function test_15_media_session_requires_employee_acceptance_and_ends_on_revoke(): void
    {
        app(CurrentCompany::class)->run($this->a, function () {
            $v = \App\Models\PolicyVersion::query()->first();
            $v->forceFill(['settings' => $v->settings + ['live_view.enabled' => true]])->save();
        });
        $m = $this->approvedPhone();
        $this->login($m);
        $device = app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->first());
        app(CurrentCompany::class)->run($this->a, fn () => app(\App\Services\PolicyService::class)->refreshDevice($device));
        $uuid = $this->admin('alpha')->postJson('/api/admin/media-sessions', ['device_id' => $device->id, 'kind' => 'screen', 'purpose' => 'Help with app'])->assertCreated()->json('uuid');
        $m->work('POST', "/api/mobile/v1/media/{$uuid}/start")->assertStatus(422);   // cannot start before accepting
        $m->work('POST', "/api/mobile/v1/media/{$uuid}/accept")->assertOk();
        $m->work('POST', "/api/mobile/v1/media/{$uuid}/start")->assertOk()->assertJsonPath('state', 'active');
        $this->admin('alpha')->postJson("/api/admin/devices/{$device->id}/revoke", ['reason' => 'test'])->assertOk();
        $this->assertSame('revoked', app(CurrentCompany::class)->withoutScope(fn () => \App\Models\MediaSession::query()->where('uuid', $uuid)->value('end_reason')));
    }

    public function test_16_policy_available_without_push(): void
    {
        $m = $this->approvedPhone();   // no push token ever registered
        $m->deviceCall('GET', '/api/mobile/v1/policy')->assertOk()->assertJsonStructure(['fingerprint', 'values', 'controls']);
    }

    public function test_17_logout_keeps_device_approval_and_policy(): void
    {
        $m = $this->approvedPhone();
        $this->login($m);
        $m->work('POST', '/api/mobile/v1/auth/logout')->assertOk();
        $m->work('GET', '/api/mobile/v1/me')->assertStatus(401);
        $m->deviceCall('GET', '/api/mobile/v1/policy')->assertOk();
        $this->assertSame('approved', app(CurrentCompany::class)->withoutScope(fn () => ManagedDevice::query()->where('installation_id', $m->installationId)->first()->approval_state->value));
    }

    public function test_18_import_validation_and_reassignment(): void
    {
        $csv = "Customer ID,Customer Name,Phone Number,Assigned Employee\nN1,New One,9000011111,EMP1\nN2,,bad,EMP1\nC1,Cust,9000022222,EMP2\n";
        $file = \Illuminate\Http\UploadedFile::fake()->createWithContent('import.csv', $csv);
        $job = $this->admin('alpha')->post('/api/admin/imports', ['file' => $file], ['Accept' => 'application/json'])->assertCreated()->json();
        $this->admin('alpha')->postJson("/api/admin/imports/{$job['id']}/preview", ['mapping' => $job['mapping']])->assertOk()
            ->assertJsonCount(2, 'result.valid');
        $this->admin('alpha')->postJson("/api/admin/imports/{$job['id']}/validate")->assertStatus(202);
        $this->admin('alpha')->postJson("/api/admin/imports/{$job['id']}/commit")->assertStatus(202);
        $status = $this->admin('alpha')->getJson("/api/admin/imports/{$job['id']}")->assertOk()->json();
        $this->assertSame('completed', $status['status']);
        $this->assertSame(1, $status['created_count']);
        $this->assertSame(1, $status['updated_count']);
        $this->assertSame(1, $status['error_rows']);
        $c1 = app(CurrentCompany::class)->withoutScope(fn () => Customer::query()->where('company_id', $this->a->id)->where('customer_ref', 'C1')->first());
        $this->assertSame($this->users['alpha']['emp2']->id, $c1->assigned_user_id);
        $this->admin('alpha')->postJson('/api/admin/customers/withdraw', ['customer_ids' => [$c1->id]])->assertOk()->assertJsonPath('withdrawn', 1);
    }

    public function test_20_simulator_refused_outside_development(): void
    {
        $this->app['env'] = 'production';
        config(['ammp.telephony.driver' => 'simulator']);
        $this->expectException(\RuntimeException::class);
        (new TelephonyManager())->adapter();
    }
}
