<?php

declare(strict_types=1);

namespace App\Services;

use App\Domain\Customers\ImportValidator;
use App\Domain\DomainException;
use App\Jobs\ProcessImport;
use App\Models\Customer;
use App\Models\CustomerAssignment;
use App\Models\ImportJob;
use App\Models\ImportRowError;
use App\Models\Team;
use App\Models\User;
use App\Support\Audit;
use App\Support\CurrentCompany;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use OpenSpout\Reader\CSV\Reader as CsvReader;
use OpenSpout\Reader\XLSX\Reader as XlsxReader;

/**
 * Upload → (auto) mapping suggestion → preview (first rows, validated) → background validate → commit.
 * Nothing touches customers until commit. Customer numbers are never written to the phone's contacts.
 */
final class ImportService
{
    public const PREVIEW_ROWS = 20;

    public function __construct(private readonly CurrentCompany $current)
    {
    }

    public function upload(UploadedFile $file, User $actor): ImportJob
    {
        $ext = strtolower($file->getClientOriginalExtension());
        $mime = (string) $file->getMimeType();
        $ok = ($ext === 'csv' && in_array($mime, ['text/csv', 'text/plain', 'application/csv', 'application/vnd.ms-excel'], true))
            || ($ext === 'xlsx' && in_array($mime, ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'], true));
        if (!$ok) {
            throw new DomainException('invalid_upload', 'Upload a .csv or .xlsx file.');
        }
        if ($file->getSize() > config('ammp.uploads.import_max_mb') * 1024 * 1024) {
            throw new DomainException('upload_too_large');
        }
        $cid = $this->current->id();
        $key = $file->storeAs("companies/{$cid}/imports", bin2hex(random_bytes(16)) . '.' . $ext, 'company_files');
        $job = ImportJob::query()->create([
            'uploaded_by' => $actor->id, 'original_name' => mb_substr($file->getClientOriginalName(), 0, 255), 'stored_key' => $key,
            'format' => $ext, 'size_bytes' => $file->getSize(), 'sha256' => hash_file('sha256', $file->getRealPath()), 'status' => 'uploaded',
        ]);
        $headers = $this->readRows($job, 1)[0] ?? [];
        if ($headers === []) {
            throw new DomainException('empty_file', 'The file has no header row.');
        }
        $job->forceFill(['headers' => $headers, 'mapping' => ImportValidator::suggestMapping($headers)])->save();
        Audit::record('import.uploaded', $job, ['name' => $job->original_name, 'sha256' => $job->sha256]);
        return $job;
    }

    public function preview(ImportJob $job, array $mapping, array $options): array
    {
        $this->saveMapping($job, $mapping, $options);
        $rows = array_slice($this->readRows($job, self::PREVIEW_ROWS + 1), 1);
        return ['mapping' => $job->mapping, 'result' => $this->validateRows($job, $this->mapRows($rows, $job->mapping))];
    }

    public function saveMapping(ImportJob $job, array $mapping, array $options): void
    {
        if (!in_array($job->status, ['uploaded', 'ready'], true)) {
            throw new DomainException('import_locked');
        }
        $clean = [];
        foreach (ImportValidator::FIELDS as $f) {
            $i = $mapping[$f] ?? null;
            $clean[$f] = ($i === null || $i === '') ? null : (int) $i;
            if ($clean[$f] !== null && ($clean[$f] < 0 || $clean[$f] >= count($job->headers ?? []))) {
                throw new DomainException('invalid_mapping');
            }
        }
        foreach (['customer_ref', 'name', 'phone'] as $req) {
            if ($clean[$req] === null) {
                throw new DomainException('mapping_incomplete', "Map a column to {$req}.");
            }
        }
        $job->forceFill(['mapping' => $clean, 'options' => ['on_existing' => ($options['on_existing'] ?? 'update') === 'skip' ? 'skip' : 'update']])->save();
    }

    /** Background step 1: validate every row and store row errors. */
    public function validateAll(ImportJob $job): void
    {
        $job->forceFill(['status' => 'validating', 'started_at' => now()])->save();
        ImportRowError::query()->where('import_job_id', $job->id)->delete();
        $rows = array_slice($this->readRows($job), 1);
        $r = $this->validateRows($job, $this->mapRows($rows, $job->mapping));
        foreach (array_chunk($r['errors'], 500) as $chunk) {
            ImportRowError::query()->insert(array_map(fn ($e) => [
                'company_id' => $job->company_id, 'import_job_id' => $job->id, 'row_number' => $e['row'], 'field' => $e['field'],
                'code' => $e['code'], 'message' => mb_substr($e['message'], 0, 255),
            ], $chunk));
        }
        $job->forceFill(['status' => 'ready', 'total_rows' => count($rows), 'valid_rows' => count($r['valid']),
            'error_rows' => count(array_unique(array_column($r['errors'], 'row')))])->save();
    }

    /** Background step 2: write valid rows. Re-validates (data may have changed since preview). */
    public function commit(ImportJob $job, User $actor): void
    {
        $job->forceFill(['status' => 'committing'])->save();
        $rows = array_slice($this->readRows($job), 1);
        $r = $this->validateRows($job, $this->mapRows($rows, $job->mapping));
        $users = User::query()->pluck('id', 'employee_code');
        $teams = Team::query()->pluck('id', 'code');
        $created = $updated = $skipped = 0;
        foreach (array_chunk($r['valid'], 500) as $chunk) {
            DB::transaction(function () use ($chunk, $job, $actor, $users, $teams, &$created, &$updated, &$skipped) {
                foreach ($chunk as $row) {
                    $userId = $row['assigned_employee'] ? $users[$row['assigned_employee']] ?? null : null;
                    $teamId = $row['assigned_team'] ? $teams[$row['assigned_team']] ?? null : null;
                    $c = Customer::query()->where('customer_ref', $row['customer_ref'])->lockForUpdate()->first();
                    if ($c && ($job->options['on_existing'] ?? 'update') === 'skip') {
                        $skipped++;
                        continue;
                    }
                    $attrs = ['name' => $row['name'], 'phone' => $row['phone'], 'alt_phone' => $row['alt_phone'], 'campaign' => $row['campaign'],
                        'status' => $row['status'], 'notes' => $row['notes'], 'follow_up_on' => $row['follow_up_date'], 'last_import_id' => $job->id];
                    $changedAssignment = !$c || $c->assigned_user_id !== $userId || $c->assigned_team_id !== $teamId || $c->withdrawn_at !== null;
                    if ($c) {
                        $c->fill($attrs + ['assigned_user_id' => $userId, 'assigned_team_id' => $teamId, 'withdrawn_at' => null])->save();
                        $updated++;
                    } else {
                        $c = Customer::query()->create($attrs + ['customer_ref' => $row['customer_ref'], 'assigned_user_id' => $userId, 'assigned_team_id' => $teamId]);
                        $created++;
                    }
                    if ($changedAssignment) {
                        CustomerAssignment::query()->create(['customer_id' => $c->id, 'user_id' => $userId, 'team_id' => $teamId,
                            'action' => 'assigned', 'actor_user_id' => $actor->id, 'import_job_id' => $job->id]);
                    }
                }
            });
        }
        $job->forceFill(['status' => 'completed', 'created_count' => $created, 'updated_count' => $updated, 'skipped_count' => $skipped, 'finished_at' => now()])->save();
        Audit::record('import.committed', $job, compact('created', 'updated', 'skipped'));
    }

    public function start(ImportJob $job, string $step, User $actor): void
    {
        ProcessImport::dispatch($job->company_id, $job->id, $step, $actor->id);
    }

    private function validateRows(ImportJob $job, array $mapped): array
    {
        $country = $this->current->get()->default_country;
        $employees = User::query()->where('status', 'active')->pluck('employee_code')->flip();
        $teams = Team::query()->pluck('code')->flip();
        return ImportValidator::validate(
            $mapped, $country,
            fn (string $phone) => Customer::query()->where('phone', $phone)->value('customer_ref'),
            fn (string $code) => isset($employees[$code]),
            fn (string $code) => isset($teams[$code]),
        );
    }

    private function mapRows(array $rows, array $mapping): array
    {
        return array_map(function (array $row) use ($mapping) {
            $out = [];
            foreach ($mapping as $field => $idx) {
                $out[$field] = $idx === null ? null : (isset($row[$idx]) ? trim((string) $row[$idx]) : null);
            }
            return $out;
        }, $rows);
    }

    /** @return list<list<string>> */
    private function readRows(ImportJob $job, ?int $limit = null): array
    {
        $path = Storage::disk('company_files')->path($job->stored_key);
        $reader = $job->format === 'xlsx' ? new XlsxReader() : new CsvReader();
        $reader->open($path);
        $out = [];
        try {
            foreach ($reader->getSheetIterator() as $sheet) {
                foreach ($sheet->getRowIterator() as $row) {
                    $out[] = array_map(static fn ($v) => $v instanceof \DateTimeInterface ? $v->format('Y-m-d') : (string) $v, $row->toArray());
                    if ($limit !== null && count($out) >= $limit) {
                        break 2;
                    }
                    if (count($out) > 200_000) {
                        throw new DomainException('import_too_many_rows', 'Split files larger than 200,000 rows.');
                    }
                }
                break; // first sheet only
            }
        } finally {
            $reader->close();
        }
        return $out;
    }
}
