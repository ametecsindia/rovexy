<?php

declare(strict_types=1);

namespace App\Services;

use App\Domain\Calling\CallAuthoriser;
use App\Domain\Calling\CallLifecycle;
use App\Domain\Calling\RecordingState;
use App\Domain\DomainException;
use App\Events\AdminFeed;
use App\Events\DeviceChannelEvent;
use App\Jobs\FetchRecording;
use App\Jobs\RecordingWatchdog;
use App\Models\Call;
use App\Models\CallDisposition;
use App\Models\CallEvent;
use App\Models\Company;
use App\Models\Customer;
use App\Models\DispositionCode;
use App\Models\FollowUp;
use App\Models\ManagedDevice;
use App\Models\Recording;
use App\Models\User;
use App\Support\Audit;
use App\Support\CurrentCompany;
use App\Telephony\TelephonyManager;
use App\Telephony\TelephonyUnavailable;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class CallService
{
    public function __construct(
        private readonly TelephonyManager $telephony,
        private readonly PolicyService $policies,
        private readonly CurrentCompany $current,
    ) {
    }

    /** Validates everything server-side, then asks the telephony system to connect. The client never supplies the route. */
    public function start(User $user, ManagedDevice $device, ?int $customerId, string $which, ?string $requestedNumber): Call
    {
        $lock = Cache::lock("call-start:{$user->id}", 10);
        if (!$lock->get()) {
            throw new DomainException('call_in_progress', 'A call is already being started.');
        }
        try {
            $policy = $this->policies->currentSnapshot($device)->values;
            $customer = $customerId === null ? null : Customer::query()->whereKey($customerId)->whereNull('withdrawn_at')->first();
            if ($customerId !== null && $customer === null) {
                throw new DomainException('customer_not_assigned', 'Customer is not available.');
            }
            $active = Call::query()->where('user_id', $user->id)->whereNotIn('state', CallLifecycle::TERMINAL)
                ->where('initiated_at', '>', now()->subHours(2))->exists();
            $decision = CallAuthoriser::authorise($policy, $customer ? [
                'id' => $customer->id, 'phone' => $customer->phone, 'alt_phone' => $customer->alt_phone, 'status' => $customer->status,
                'assigned_user_id' => $customer->assigned_user_id, 'assigned_team_id' => $customer->assigned_team_id,
            ] : null, $requestedNumber, $which, [
                'user_id' => $user->id, 'team_ids' => $user->teams()->pluck('teams.id')->map(fn ($i) => (int) $i)->all(),
                'compliant' => (bool) $device->compliant, 'active_call' => $active, 'timezone' => $this->current->get()->timezone,
            ], new \DateTimeImmutable('now', new \DateTimeZone('UTC')));

            $agentLeg = $policy['calling.agent_leg'];
            if ($agentLeg === 'pstn_callback' && !$user->phone) {
                throw new DomainException('agent_phone_missing', 'Your work number is not configured. Contact your administrator.');
            }
            $adapter = $this->telephony->adapter();
            $call = DB::transaction(function () use ($user, $device, $customer, $which, $decision, $agentLeg, $adapter) {
                $call = Call::query()->create([
                    'uuid' => (string) Str::uuid(), 'provider' => $adapter->name(), 'user_id' => $user->id, 'device_id' => $device->id,
                    'customer_id' => $customer?->id, 'destination' => $decision['destination'], 'which_number' => $which,
                    'agent_leg' => $agentLeg, 'state' => 'initiated', 'initiated_at' => now(),
                    'recording_required' => $decision['record'],
                    'recording_status' => $decision['record'] ? RecordingState::Pending->value : RecordingState::NotRequired->value,
                ]);
                if ($decision['record']) {
                    Recording::query()->create(['call_id' => $call->id, 'status' => RecordingState::Pending->value]);
                }
                return $call;
            });
            $recordPath = $decision['record']
                ? sprintf('ametecs/%d/%s/%s.wav', $call->company_id, now()->utc()->format('Y/m'), $call->uuid) : null;
            if ($recordPath) {
                Recording::query()->where('call_id', $call->id)->update(['source_path' => $recordPath]);
            }
            try {
                $adapter->originate($call, [
                    'call_id' => $call->uuid, 'company_id' => $call->company_id, 'agent_leg' => $agentLeg,
                    'agent_target' => $agentLeg === 'pstn_callback' ? (string) $user->phone : 'dev_' . $device->id,
                    'customer_e164' => $decision['destination'], 'record_path' => $recordPath,
                ]);
            } catch (TelephonyUnavailable $e) {
                $call->forceFill(['state' => 'failed', 'failure_reason' => 'telephony_unavailable', 'ended_at' => now(),
                    'recording_status' => $decision['record'] ? RecordingState::Failed->value : RecordingState::NotRequired->value])->save();
                Recording::query()->where('call_id', $call->id)->update(['status' => RecordingState::Failed->value, 'last_error' => 'call not placed']);
                throw new DomainException('telephony_unavailable', 'Calling service is unavailable. Try again shortly.');
            }
            $device->forceFill(['work_state' => 'on_call'])->saveQuietly();
            Audit::record('call.started', $call, ['customer_id' => $customer?->id, 'which' => $which]);
            return $call;
        } finally {
            $lock->release();
        }
    }

    /**
     * Idempotent ingestion of a normalised telephony event. Returns 'applied' | 'duplicate' | 'ignored'.
     * Duplicate provider events hit the unique (call_id, provider_event_id) index and change nothing.
     */
    public function ingest(array $e): string
    {
        /** @var Call|null $call */
        $call = $this->current->withoutScope(fn () => Call::query()->where('uuid', $e['call_id'])->first());
        if ($call === null || ($e['company_id'] ?? $call->company_id) !== $call->company_id) {
            return 'ignored';
        }
        $company = Company::query()->findOrFail($call->company_id);
        return $this->current->run($company, function () use ($call, $e) {
            return DB::transaction(function () use ($call, $e) {
                try {
                    CallEvent::query()->create([
                        'call_id' => $call->id, 'provider_event_id' => $e['provider_event_id'], 'type' => $e['type'],
                        'occurred_at' => new \DateTimeImmutable($e['at']), 'payload' => array_intersect_key($e, array_flip(['cause', 'provider_call_id', 'record_path'])),
                    ]);
                } catch (UniqueConstraintViolationException) {
                    return 'duplicate';
                }
                $call = Call::query()->whereKey($call->id)->lockForUpdate()->firstOrFail();
                $wasTerminal = $call->isTerminal();
                if ($call->provider_call_id === null && !empty($e['provider_call_id'])) {
                    $call->provider_call_id = $e['provider_call_id'];
                }
                if (in_array($e['type'], ['recording_started', 'recording_stopped'], true)) {
                    $this->onRecordingEvent($call, $e['type']);
                    $call->save();
                    return 'applied';
                }
                if ($e['type'] === 'customer_hangup') {
                    $call->save();
                    return 'applied'; // informational; the agent (A) leg hangup ends the call
                }
                $next = CallLifecycle::apply($call->lifecycleSnapshot(), $e);
                $call->forceFill([
                    'state' => $next['state'], 'hangup_cause' => $next['hangup_cause'],
                    'agent_answered_at' => $next['agent_answered_at'], 'ringing_at' => $next['ringing_at'],
                    'answered_at' => $next['answered_at'], 'ended_at' => $next['ended_at'],
                ] + CallLifecycle::durations($next))->save();

                if ($e['type'] === 'customer_answered' && $call->recording_required) {
                    RecordingWatchdog::dispatch($call->company_id, $call->id)->delay(now()->addSeconds(10));
                }
                if (!$wasTerminal && $call->isTerminal()) {
                    $this->onCallEnded($call);
                }
                DeviceChannelEvent::dispatchFor(ManagedDevice::query()->findOrFail($call->device_id), 'call.updated', ['call_id' => $call->uuid, 'state' => $call->state]);
                AdminFeed::dispatchFor($call->company_id, 'call.updated', ['call_id' => $call->id, 'state' => $call->state]);
                return 'applied';
            });
        });
    }

    private function onRecordingEvent(Call $call, string $type): void
    {
        $rec = Recording::query()->where('call_id', $call->id)->lockForUpdate()->first();
        if ($rec === null) {
            return;
        }
        $state = RecordingState::from($rec->status);
        $target = $type === 'recording_started' ? RecordingState::Recording : RecordingState::Processing;
        if ($state->canMoveTo($target)) {
            $rec->forceFill(['status' => $target->value])->save();
            $call->recording_status = $target->value;
            if ($target === RecordingState::Processing) {
                FetchRecording::dispatch($call->company_id, $rec->id)->delay(now()->addSeconds(5));
            }
        }
    }

    private function onCallEnded(Call $call): void
    {
        ManagedDevice::query()->whereKey($call->device_id)->where('work_state', 'on_call')->update(['work_state' => 'updating_customer']);
        $rec = Recording::query()->where('call_id', $call->id)->first();
        if ($rec === null) {
            return;
        }
        if ($call->answered_at === null && $rec->status === RecordingState::Pending->value) {
            // Nothing was ever connected, so nothing could be recorded.
            $rec->forceFill(['status' => RecordingState::NotRequired->value])->save();
            $call->forceFill(['recording_status' => RecordingState::NotRequired->value])->save();
        } elseif ($call->answered_at !== null && in_array($rec->status, [RecordingState::Pending->value, RecordingState::Recording->value], true)) {
            // Answered but no RECORD_STOP seen: try to fetch anyway; reconciliation will mark Failed if the file never appears.
            $rec->forceFill(['status' => RecordingState::Processing->value])->save();
            $call->forceFill(['recording_status' => RecordingState::Processing->value])->save();
            FetchRecording::dispatch($call->company_id, $rec->id)->delay(now()->addSeconds(15));
        }
    }

    /** Called by RecordingWatchdog: mandatory recording that has not started after answer. */
    public function handleRecordingNotStarted(Call $call): void
    {
        $rec = Recording::query()->where('call_id', $call->id)->first();
        if ($rec === null || $rec->status !== RecordingState::Pending->value || $call->isTerminal()) {
            return;
        }
        $device = ManagedDevice::query()->findOrFail($call->device_id);
        $policy = $this->policies->currentSnapshot($device)->values;
        $action = RecordingState::failureAction($policy['recording.mode'], $policy['recording.on_failure']);
        $rec->forceFill(['status' => RecordingState::Failed->value, 'last_error' => 'recording did not start'])->save();
        $call->forceFill(['recording_status' => RecordingState::Failed->value])->save();
        Audit::record('recording.start_failed', $call, ['action' => $action]);
        AdminFeed::dispatchFor($call->company_id, 'recording.failed', ['call_id' => $call->id, 'action' => $action]);
        DeviceChannelEvent::dispatchFor($device, 'recording.failed', ['call_id' => $call->uuid, 'action' => $action]);
        if ($action === 'terminate') {
            try {
                $this->telephony->adapter()->hangup($call, 'MANAGER_REQUEST');
            } catch (TelephonyUnavailable) {
                // Reported via the failed status above; reconciliation surfaces the call too.
            }
        }
    }

    public function hangup(Call $call, User $user): void
    {
        if ($call->user_id !== $user->id) {
            throw new DomainException('forbidden');
        }
        if (!$call->isTerminal()) {
            $this->telephony->adapter()->hangup($call, 'NORMAL_CLEARING');
        }
    }

    /** Policy `revocation.active_call`: terminate (default) or allow the in-progress call to finish. */
    public function handleRevocation(ManagedDevice $device): void
    {
        $values = $this->policies->currentSnapshot($device)->values;
        if ($values['revocation.active_call'] !== 'terminate') {
            return;
        }
        Call::query()->where('device_id', $device->id)->whereNotIn('state', CallLifecycle::TERMINAL)->each(function (Call $c) {
            try {
                $this->telephony->adapter()->hangup($c, 'MANAGER_REQUEST');
                Audit::record('call.terminated_on_revocation', $c);
            } catch (\Throwable) {
                Audit::record('call.terminate_on_revocation_failed', $c);
            }
        });
    }

    public function dispose(Call $call, User $user, string $code, ?string $notes, ?string $followUpAt): CallDisposition
    {
        if ($call->user_id !== $user->id) {
            throw new DomainException('forbidden');
        }
        if (!$call->isTerminal()) {
            throw new DomainException('call_not_ended', 'Submit the outcome after the call ends.');
        }
        $dc = DispositionCode::query()->where('code', $code)->where('active', true)->first() ?? throw new DomainException('invalid_disposition');
        $follow = $followUpAt ? new \DateTimeImmutable($followUpAt) : null;
        if ($dc->requires_follow_up && $follow === null) {
            throw new DomainException('follow_up_required', 'This outcome needs a follow-up date.');
        }
        return DB::transaction(function () use ($call, $user, $dc, $notes, $follow) {
            $existing = CallDisposition::query()->where('call_id', $call->id)->first();
            if ($existing) {
                return $existing; // idempotent (offline replay)
            }
            $d = CallDisposition::query()->create(['call_id' => $call->id, 'user_id' => $user->id, 'code' => $dc->code,
                'notes' => $notes ? mb_substr($notes, 0, 2000) : null, 'follow_up_at' => $follow, 'submitted_at' => now()]);
            $call->forceFill(['disposition_status' => 'submitted'])->save();
            if ($call->customer_id) {
                $c = Customer::query()->find($call->customer_id);
                if ($follow) {
                    FollowUp::query()->create(['customer_id' => $call->customer_id, 'user_id' => $user->id, 'call_id' => $call->id, 'due_at' => $follow, 'notes' => $notes]);
                    $c?->forceFill(['status' => 'follow_up', 'follow_up_on' => $follow->format('Y-m-d')])->save();
                } elseif ($c && $c->status === 'new') {
                    $c->forceFill(['status' => 'in_progress'])->save();
                }
            }
            ManagedDevice::query()->whereKey($call->device_id)->where('work_state', 'updating_customer')->update(['work_state' => 'idle']);
            return $d;
        });
    }
}
