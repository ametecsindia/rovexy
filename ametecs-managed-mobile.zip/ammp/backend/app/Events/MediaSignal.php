<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\MediaSession;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

/** WebRTC signalling relay (SDP/ICE) on the session's private channel; only the two parties are authorised. */
final class MediaSignal implements ShouldBroadcastNow
{
    use BroadcastsSafely;

    public function __construct(public readonly int $companyId, public readonly string $sessionUuid, public readonly string $from, public readonly string $type, public readonly array $payload)
    {
    }

    public static function dispatchFor(MediaSession $s, string $from, string $type, array $payload): void
    {
        self::safely(new self($s->company_id, $s->uuid, $from, $type, $payload));
    }

    public function broadcastOn(): array
    {
        return [new PrivateChannel("company.{$this->companyId}.media.{$this->sessionUuid}")];
    }

    public function broadcastAs(): string
    {
        return 'signal';
    }

    public function broadcastWith(): array
    {
        return ['from' => $this->from, 'type' => $this->type, 'payload' => $this->payload];
    }
}
