<?php

declare(strict_types=1);

namespace App\Models;

use App\Support\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class CompanyBranding extends Model
{
    use BelongsToCompany;

    protected $table = 'company_branding';

    protected $fillable = ['display_name','logo_key','logo_sha256','logo_mime','primary_color','accent_color','version','updated_by'];

    protected function casts(): array
    {
        return [];
    }
}
