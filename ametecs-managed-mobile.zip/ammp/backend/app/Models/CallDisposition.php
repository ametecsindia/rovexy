<?php

declare(strict_types=1);

namespace App\Models;

use App\Support\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class CallDisposition extends Model
{
    use BelongsToCompany;

    protected $table = 'call_dispositions';

    public $timestamps = false;

    protected $fillable = ['call_id','user_id','code','notes','follow_up_at','submitted_at'];

    protected function casts(): array
    {
        return ['follow_up_at' => 'datetime','submitted_at' => 'datetime'];
    }
}
