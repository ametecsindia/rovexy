<?php

declare(strict_types=1);

namespace App\Models;

use App\Support\BelongsToCompany;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use BelongsToCompany;

    protected $table = 'customers';

    protected $fillable = ['customer_ref','name','phone','alt_phone','campaign','status','notes','follow_up_on','assigned_user_id','assigned_team_id','withdrawn_at','last_import_id'];

    protected function casts(): array
    {
        return ['follow_up_on' => 'date','withdrawn_at' => 'datetime'];
    }

    /** Customers the employee may see/call right now: assigned directly, or to one of their teams with no individual owner. */
    public function scopeVisibleTo(\Illuminate\Database\Eloquent\Builder $q, User $user): \Illuminate\Database\Eloquent\Builder
    {
        $teamIds = $user->teams()->pluck('teams.id');
        return $q->whereNull('withdrawn_at')->where(function ($w) use ($user, $teamIds) {
            $w->where('assigned_user_id', $user->id)
              ->orWhere(fn ($t) => $t->whereNull('assigned_user_id')->whereIn('assigned_team_id', $teamIds));
        });
    }
}
