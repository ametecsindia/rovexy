<?php

declare(strict_types=1);

namespace App\Domain\Customers;

use App\Domain\DomainException;

/**
 * Validates mapped import rows. Pure: lookups for existing data are injected as closures.
 * Duplicates: within the file by customer_ref and by phone; against existing company records by customer_ref
 * (=> update) and by phone owned by a different customer_ref (=> error, needs review).
 */
final class ImportValidator
{
    public const FIELDS = ['customer_ref', 'name', 'phone', 'alt_phone', 'campaign', 'assigned_employee', 'assigned_team', 'notes', 'status', 'follow_up_date'];
    public const STATUSES = ['new', 'in_progress', 'follow_up', 'closed', 'do_not_call'];

    private const SYNONYMS = [
        'customer_ref' => ['customer id', 'customer_id', 'cust id', 'id', 'account', 'account no', 'loan no', 'ref'],
        'name' => ['customer name', 'name', 'full name', 'borrower'],
        'phone' => ['phone', 'phone number', 'mobile', 'mobile number', 'contact', 'number'],
        'alt_phone' => ['alternate number', 'alternate', 'alt phone', 'alt mobile', 'phone 2', 'secondary'],
        'campaign' => ['campaign', 'portfolio', 'bucket'],
        'assigned_employee' => ['assigned employee', 'employee', 'agent', 'employee code', 'agent id'],
        'assigned_team' => ['assigned team', 'team', 'team code'],
        'notes' => ['notes', 'remarks', 'comment'],
        'status' => ['status'],
        'follow_up_date' => ['follow-up date', 'follow up date', 'followup', 'follow_up', 'ptp date', 'next action'],
    ];

    /** @param list<string> $headers @return array<string,?int> field => header index */
    public static function suggestMapping(array $headers): array
    {
        $norm = array_map(static fn ($h) => strtolower(trim(preg_replace('/\s+/', ' ', (string) $h) ?? '')), $headers);
        $out = [];
        foreach (self::SYNONYMS as $field => $syn) {
            $out[$field] = null;
            foreach ($norm as $i => $h) {
                if ($h === $field || in_array($h, $syn, true)) {
                    $out[$field] = $i;
                    break;
                }
            }
        }
        return $out;
    }

    /**
     * @param list<array<string,?string>> $rows mapped rows (field => raw string)
     * @param callable(string):?string $existingRefForPhone returns the customer_ref owning a phone in this company
     * @param callable(string):bool $employeeExists
     * @param callable(string):bool $teamExists
     * @return array{valid: list<array<string,mixed>>, errors: list<array{row:int,field:string,code:string,message:string}>}
     */
    public static function validate(array $rows, string $defaultCountry, callable $existingRefForPhone, callable $employeeExists, callable $teamExists, int $firstRowNumber = 2): array
    {
        $valid = [];
        $errors = [];
        $seenRef = [];
        $seenPhone = [];
        foreach ($rows as $i => $raw) {
            $n = $firstRowNumber + $i;
            $rowErrors = [];
            $err = static function (string $field, string $code, string $message) use (&$rowErrors, $n): void {
                $rowErrors[] = ['row' => $n, 'field' => $field, 'code' => $code, 'message' => $message];
            };
            $get = static fn (string $f): string => trim((string) ($raw[$f] ?? ''));

            $ref = $get('customer_ref');
            $name = $get('name');
            if ($ref === '' || strlen($ref) > 64) {
                $err('customer_ref', 'required', 'Customer ID is required (max 64 chars).');
            }
            if ($name === '' || mb_strlen($name) > 150) {
                $err('name', 'required', 'Customer name is required (max 150 chars).');
            }
            $phone = null;
            try {
                $phone = PhoneNormaliser::normalise($get('phone'), $defaultCountry);
            } catch (DomainException $e) {
                $err('phone', 'invalid_phone', $e->getMessage());
            }
            $alt = null;
            if ($get('alt_phone') !== '') {
                try {
                    $alt = PhoneNormaliser::normalise($get('alt_phone'), $defaultCountry);
                } catch (DomainException $e) {
                    $err('alt_phone', 'invalid_phone', $e->getMessage());
                }
            }
            $status = strtolower($get('status')) ?: 'new';
            $status = str_replace([' ', '-'], '_', $status);
            if (!in_array($status, self::STATUSES, true)) {
                $err('status', 'invalid_status', 'Status must be one of: ' . implode(', ', self::STATUSES) . '.');
            }
            $followUp = null;
            if ($get('follow_up_date') !== '') {
                $followUp = self::parseDate($get('follow_up_date'));
                if ($followUp === null) {
                    $err('follow_up_date', 'invalid_date', 'Use YYYY-MM-DD or DD/MM/YYYY.');
                }
            }
            $emp = $get('assigned_employee') ?: null;
            if ($emp !== null && !$employeeExists($emp)) {
                $err('assigned_employee', 'unknown_employee', 'Employee not found or inactive in this company.');
            }
            $team = $get('assigned_team') ?: null;
            if ($team !== null && !$teamExists($team)) {
                $err('assigned_team', 'unknown_team', 'Team not found in this company.');
            }
            if ($ref !== '' && isset($seenRef[$ref])) {
                $err('customer_ref', 'duplicate_in_file', "Duplicate of row {$seenRef[$ref]}.");
            }
            if ($phone !== null && isset($seenPhone[$phone])) {
                $err('phone', 'duplicate_in_file', "Phone duplicates row {$seenPhone[$phone]}.");
            }
            if ($phone !== null) {
                $owner = $existingRefForPhone($phone);
                if ($owner !== null && $owner !== $ref) {
                    $err('phone', 'duplicate_existing', "Phone already belongs to customer {$owner}.");
                }
            }
            if ($rowErrors === []) {
                $seenRef[$ref] = $n;
                $seenPhone[$phone] = $n;
                $valid[] = [
                    'row' => $n, 'customer_ref' => $ref, 'name' => $name, 'phone' => $phone, 'alt_phone' => $alt,
                    'campaign' => $get('campaign') ?: null, 'assigned_employee' => $emp, 'assigned_team' => $team,
                    'notes' => mb_substr($get('notes'), 0, 2000) ?: null, 'status' => $status, 'follow_up_date' => $followUp,
                ];
            } else {
                array_push($errors, ...$rowErrors);
            }
        }
        return ['valid' => $valid, 'errors' => $errors];
    }

    public static function parseDate(string $s): ?string
    {
        foreach (['!Y-m-d', '!d/m/Y', '!d-m-Y', '!d.m.Y'] as $fmt) {
            $d = \DateTimeImmutable::createFromFormat($fmt, $s);
            if ($d !== false && $d->format(substr($fmt, 1)) === $s) {
                return $d->format('Y-m-d');
            }
        }
        if (is_numeric($s) && (float) $s > 20000 && (float) $s < 80000) { // Excel serial date
            return (new \DateTimeImmutable('1899-12-30'))->modify('+' . (int) $s . ' days')->format('Y-m-d');
        }
        return null;
    }
}
