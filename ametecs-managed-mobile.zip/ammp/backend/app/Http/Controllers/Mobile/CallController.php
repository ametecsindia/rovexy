<?php

declare(strict_types=1);

namespace App\Http\Controllers\Mobile;

use App\Http\Controllers\Controller;
use App\Models\Call;
use App\Services\CallService;
use Illuminate\Http\Request;

final class CallController extends Controller
{
    public function store(Request $r, CallService $svc)
    {
        $data = $r->validate([
            'customer_id' => 'nullable|integer',
            'which' => 'required|in:primary,alternate',
            'number' => 'nullable|string|max:20',   // only meaningful for manual dialling; otherwise must match the record
        ]);
        $call = $svc->start($r->user(), $this->device($r), $data['customer_id'] ?? null, $data['which'], $data['number'] ?? null);
        return response()->json($this->body($call), 201);
    }

    public function show(Request $r, string $uuid)
    {
        return response()->json($this->body($this->own($r, $uuid)));
    }

    public function hangup(Request $r, string $uuid, CallService $svc)
    {
        $svc->hangup($this->own($r, $uuid), $r->user());
        return response()->json(['ok' => true]);
    }

    public function disposition(Request $r, string $uuid, CallService $svc)
    {
        $data = $r->validate(['code' => 'required|string|max:32', 'notes' => 'nullable|string|max:2000', 'follow_up_at' => 'nullable|date']);
        $d = $svc->dispose($this->own($r, $uuid), $r->user(), $data['code'], $data['notes'] ?? null, $data['follow_up_at'] ?? null);
        return response()->json(['ok' => true, 'disposition_id' => $d->id]);
    }

    private function own(Request $r, string $uuid): Call
    {
        return Call::query()->where('uuid', $uuid)->where('user_id', $r->user()->id)->firstOrFail();
    }

    private function body(Call $c): array
    {
        return ['call_id' => $c->uuid, 'state' => $c->state, 'customer_id' => $c->customer_id, 'recording_status' => $c->recording_status,
            'ring_seconds' => $c->ring_seconds, 'talk_seconds' => $c->talk_seconds, 'total_seconds' => $c->total_seconds,
            'failure_reason' => $c->failure_reason, 'disposition_status' => $c->disposition_status, 'agent_leg' => $c->agent_leg];
    }
}
