<?php

declare(strict_types=1);

namespace App\Http\Controllers\Mobile;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\DispositionCode;
use Illuminate\Http\Request;

/**
 * Sync of the employee's currently assigned customers. `visible_ids` is authoritative: the app deletes any cached
 * customer not in it (withdrawn/reassigned). Customer data stays in the app's encrypted store, never device contacts.
 */
final class CustomerController extends Controller
{
    public function index(Request $r)
    {
        $since = $r->query('since') ? new \DateTimeImmutable((string) $r->query('since')) : null;
        $base = Customer::query()->visibleTo($r->user());
        $changed = (clone $base)->when($since, fn ($q) => $q->where('updated_at', '>', $since))
            ->orderBy('id')->limit(5000)
            ->get(['id', 'customer_ref', 'name', 'phone', 'alt_phone', 'campaign', 'status', 'notes', 'follow_up_on', 'updated_at']);
        return response()->json([
            'server_time' => now()->toAtomString(),
            'visible_ids' => $base->pluck('id'),
            'items' => $changed,
        ]);
    }

    public function dispositions()
    {
        return response()->json(DispositionCode::query()->where('active', true)->orderBy('label')->get(['code', 'label', 'requires_follow_up']));
    }
}
