<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Domain\Customers\PhoneNormaliser;
use App\Domain\DomainException;
use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\Team;
use App\Models\User;
use App\Support\Audit;
use App\Support\CurrentCompany;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

final class PeopleController extends Controller
{
    public function employees(Request $r)
    {
        $teams = $r->user()->supervisedTeamIds();
        return response()->json(User::query()
            ->when($teams !== null, fn ($q) => $q->whereHas('teams', fn ($t) => $t->whereIn('teams.id', $teams)))
            ->with(['teams:id,code,name', 'roles:id,key,name'])->orderBy('name')
            ->paginate(100, ['id', 'employee_code', 'name', 'email', 'phone', 'status', 'last_login_at', 'mfa_enabled_at']));
    }

    public function createEmployee(Request $r, CurrentCompany $current)
    {
        $cid = $current->id();
        $data = $r->validate([
            'employee_code' => ['required', 'string', 'max:64', 'regex:/^[A-Za-z0-9._-]+$/', Rule::unique('users')->where('company_id', $cid)],
            'name' => 'required|string|max:150',
            'email' => ['nullable', 'email', 'max:190', Rule::unique('users')->where('company_id', $cid)],
            'phone' => 'nullable|string|max:20',
            'password' => ['required', Password::min(10)->letters()->numbers()],
            'roles' => 'required|array|min:1', 'roles.*' => 'string',
            'team_ids' => 'array', 'team_ids.*' => 'integer',
        ]);
        $this->guardRoleGrant($r->user(), $data['roles']);
        $user = DB::transaction(function () use ($data, $cid) {
            $u = User::query()->create([
                'employee_code' => $data['employee_code'], 'name' => $data['name'], 'email' => isset($data['email']) ? strtolower($data['email']) : null,
                'phone' => !empty($data['phone']) ? PhoneNormaliser::normalise($data['phone'], app(CurrentCompany::class)->get()->default_country) : null,
                'password' => $data['password'], 'status' => 'active',
            ]);
            $u->roles()->attach(Role::query()->whereIn('key', $data['roles'])->pluck('id')->mapWithKeys(fn ($id) => [$id => ['company_id' => $cid]])->all());
            $u->teams()->attach(Team::query()->whereIn('id', $data['team_ids'] ?? [])->pluck('id')->mapWithKeys(fn ($id) => [$id => ['company_id' => $cid, 'membership' => 'member']])->all());
            return $u;
        });
        Audit::record('employee.created', $user, ['roles' => $data['roles']]);
        return response()->json(['id' => $user->id], 201);
    }

    public function updateEmployee(Request $r, int $id)
    {
        $user = User::query()->findOrFail($id);
        $data = $r->validate(['name' => 'string|max:150', 'phone' => 'nullable|string|max:20', 'status' => 'in:active,suspended,left',
            'roles' => 'array', 'roles.*' => 'string', 'password' => ['nullable', Password::min(10)->letters()->numbers()]]);
        if (isset($data['roles'])) {
            $this->guardRoleGrant($r->user(), $data['roles']);
            $user->roles()->sync(Role::query()->whereIn('key', $data['roles'])->pluck('id')->mapWithKeys(fn ($rid) => [$rid => ['company_id' => $user->company_id]])->all());
        }
        if (array_key_exists('phone', $data)) {
            $data['phone'] = $data['phone'] ? PhoneNormaliser::normalise($data['phone'], app(CurrentCompany::class)->get()->default_country) : null;
        }
        $user->fill(array_filter(array_intersect_key($data, array_flip(['name', 'phone', 'status', 'password'])), fn ($v) => $v !== null))->save();
        if (($data['status'] ?? 'active') !== 'active') {
            \App\Models\WorkSession::query()->where('user_id', $user->id)->whereNull('ended_at')->update(['ended_at' => now(), 'end_reason' => 'employee_' . $data['status']]);
        }
        Audit::record('employee.updated', $user, array_diff_key($data, ['password' => 1]) + ['password_changed' => isset($data['password'])]);
        return response()->json(['ok' => true]);
    }

    public function teams()
    {
        return response()->json(Team::query()->withCount('users')->orderBy('name')->get());
    }

    public function createTeam(Request $r, CurrentCompany $current)
    {
        $data = $r->validate(['code' => ['required', 'string', 'max:32', 'regex:/^[A-Za-z0-9._-]+$/', Rule::unique('teams')->where('company_id', $current->id())], 'name' => 'required|string|max:100']);
        $t = Team::query()->create($data);
        Audit::record('team.created', $t);
        return response()->json(['id' => $t->id], 201);
    }

    public function setMembers(Request $r, int $id)
    {
        $team = Team::query()->findOrFail($id);
        $data = $r->validate(['members' => 'array', 'members.*.user_id' => 'required|integer', 'members.*.membership' => 'required|in:member,supervisor']);
        $ids = User::query()->whereIn('id', array_column($data['members'] ?? [], 'user_id'))->pluck('id')->all(); // same-company users only
        $sync = [];
        foreach ($data['members'] ?? [] as $m) {
            if (in_array($m['user_id'], $ids, true)) {
                $sync[$m['user_id']] = ['membership' => $m['membership'], 'company_id' => $team->company_id];
            }
        }
        $team->users()->sync($sync);
        Audit::record('team.members_set', $team, ['count' => count($sync)]);
        return response()->json(['ok' => true]);
    }

    public function roles()
    {
        return response()->json(Role::query()->with('permissions:id,key')->get(['id', 'key', 'name', 'system']));
    }

    /** Prevent privilege escalation: you cannot grant a role holding permissions you do not have. */
    private function guardRoleGrant(User $actor, array $roleKeys): void
    {
        $perms = DB::table('roles')->join('permission_role', 'permission_role.role_id', '=', 'roles.id')
            ->join('permissions', 'permissions.id', '=', 'permission_role.permission_id')
            ->where('roles.company_id', $actor->company_id)->whereIn('roles.key', $roleKeys)->pluck('permissions.key')->unique();
        $missing = $perms->diff($actor->permissionKeys())->diff(['mobile.work', 'calls.make']);
        if ($missing->isNotEmpty()) {
            throw new DomainException('forbidden', 'You cannot grant permissions you do not hold.');
        }
    }
}
