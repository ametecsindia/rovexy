<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Domain\DomainException;
use App\Events\DeviceChannelEvent;
use App\Events\MediaSignal;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\LocationEvent;
use App\Models\ManagedDevice;
use App\Models\MediaSession;
use App\Models\User;
use App\Services\ChatService;
use App\Services\MediaSessionService;
use App\Support\Audit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

final class SupervisionController extends Controller
{
    /** Status is reported as observed: signed-in ≠ working. "Idle"/"active" are in-app signals only. */
    public function presence(Request $r)
    {
        $teams = $r->user()->supervisedTeamIds();
        return response()->json(ManagedDevice::query()->where('approval_state', 'approved')
            ->when($teams !== null, fn ($q) => $q->whereIn('team_id', $teams))
            ->with('assignedUser:id,name,employee_code')
            ->get(['id', 'asset_tag', 'assigned_user_id', 'team_id', 'presence', 'work_state', 'battery_pct', 'network_type', 'last_contact_at', 'compliant', 'policy_state']));
    }

    public function locations(Request $r)
    {
        $data = $r->validate(['user_id' => 'required|integer', 'from' => 'nullable|date', 'to' => 'nullable|date']);
        $employee = User::query()->findOrFail($data['user_id']);
        if (!$r->user()->canSeeUser($employee)) {
            throw new DomainException('forbidden');
        }
        Audit::record('location.viewed', $employee, array_intersect_key($data, ['from' => 1, 'to' => 1]));
        return response()->json(LocationEvent::query()->where('user_id', $employee->id)
            ->where('captured_at', '>=', $data['from'] ?? now()->startOfDay())->where('captured_at', '<', $data['to'] ?? now()->addMinute())
            ->orderBy('captured_at')->limit(2000)->get(['lat', 'lng', 'accuracy_m', 'captured_at', 'received_at', 'battery_pct'])
            ->map(fn ($l) => $l->toArray() + ['stale' => $l->captured_at->lt(now()->subMinutes(15))]));
    }

    public function mediaIndex(Request $r)
    {
        abort_unless($r->user()->hasPermission('media.screen') || $r->user()->hasPermission('media.camera') || $r->user()->hasPermission('audit.view'), 403);
        $teams = $r->user()->supervisedTeamIds();
        return response()->json(MediaSession::query()
            ->when($teams !== null, fn ($q) => $q->where(fn ($w) => $w->where('requested_by', $r->user()->id)
                ->orWhereIn('user_id', \Illuminate\Support\Facades\DB::table('team_user')->whereIn('team_id', $teams)->pluck('user_id'))))
            ->latest('id')->paginate(50));
    }

    public function mediaRequest(Request $r, MediaSessionService $svc)
    {
        $data = $r->validate(['device_id' => 'required|integer', 'kind' => 'required|in:screen,camera', 'purpose' => 'required|string|max:255']);
        $s = $svc->request($r->user(), ManagedDevice::query()->findOrFail($data['device_id']), $data['kind'], $data['purpose']);
        return response()->json($s, 201);
    }

    public function mediaEnd(Request $r, string $uuid, MediaSessionService $svc)
    {
        $s = $this->ownSession($r, $uuid);
        return response()->json($svc->act($s, 'end', 'supervisor_stopped', $r->user()));
    }

    public function mediaSignal(Request $r, string $uuid)
    {
        $s = $this->ownSession($r, $uuid);
        $data = $r->validate(['type' => 'required|in:offer,answer,candidate,bye', 'payload' => 'required|array']);
        abort_unless(in_array($s->state, ['accepted', 'active'], true), 409);
        MediaSignal::dispatchFor($s, 'supervisor', $data['type'], $data['payload']);
        DeviceChannelEvent::dispatchFor(ManagedDevice::query()->findOrFail($s->device_id), 'media.signal', ['session_id' => $s->uuid, 'type' => $data['type'], 'payload' => $data['payload']]);
        return response()->json(['ok' => true]);
    }

    public function mediaIce(Request $r, string $uuid, MediaSessionService $svc)
    {
        return response()->json(['ice_servers' => $svc->iceServers($this->ownSession($r, $uuid))]);
    }

    /** Screenshot = a frame captured by the supervisor's console from the live, consented stream. */
    public function screenshot(Request $r, string $uuid)
    {
        $s = $this->ownSession($r, $uuid);
        if ($s->kind !== 'screen' || $s->state !== 'active' || !($s->options['screenshots'] ?? false)) {
            throw new DomainException('screenshot_not_permitted', 'Screenshots need an active screen session with screenshots allowed by policy.');
        }
        $r->validate(['image' => 'required|file|mimes:png,jpg,jpeg|max:4096']);
        $key = $r->file('image')->store("companies/{$s->company_id}/screenshots/{$s->uuid}", 'company_files');
        $sha = hash('sha256', (string) Storage::disk('company_files')->get($key));
        \Illuminate\Support\Facades\DB::table('media_screenshots')->insert(['company_id' => $s->company_id, 'media_session_id' => $s->id, 'object_key' => $key, 'sha256' => $sha, 'taken_by' => $r->user()->id, 'created_at' => now()]);
        Audit::record('media.screenshot', $s, ['sha256' => $sha]);
        DeviceChannelEvent::dispatchFor(ManagedDevice::query()->findOrFail($s->device_id), 'media.screenshot_taken', ['session_id' => $s->uuid]);
        return response()->json(['ok' => true], 201);
    }

    public function conversations(Request $r)
    {
        $uid = $r->user()->id;
        return response()->json(Conversation::query()->whereHas('participants', fn ($q) => $q->where('users.id', $uid))
            ->with('participants:id,name')->orderByDesc('last_message_at')->limit(100)->get());
    }

    public function startConversation(Request $r, ChatService $chat)
    {
        $data = $r->validate(['user_id' => 'required|integer', 'subject' => 'nullable|string|max:150']);
        return response()->json($chat->start($r->user(), User::query()->findOrFail($data['user_id']), $data['subject'] ?? null), 201);
    }

    public function messages(Request $r, int $id, ChatService $chat)
    {
        return response()->json($chat->page($chat->conversationFor($r->user(), $id), $r->user(), (int) $r->query('after', 0)));
    }

    public function send(Request $r, int $id, ChatService $chat)
    {
        $data = $r->validate(['body' => 'nullable|string|max:4000', 'attachment' => 'nullable|file']);
        $m = $chat->send($chat->conversationFor($r->user(), $id), $r->user(), $data['body'] ?? null, $r->file('attachment'), null,
            ['image/jpeg', 'image/png', 'application/pdf'], 10);
        return response()->json(['id' => $m->id], 201);
    }

    private function ownSession(Request $r, string $uuid): MediaSession
    {
        $s = MediaSession::query()->where('uuid', $uuid)->firstOrFail();
        if ($s->requested_by !== $r->user()->id) {
            throw new DomainException('forbidden', 'Only the requesting supervisor can control this session.');
        }
        return $s;
    }
}
