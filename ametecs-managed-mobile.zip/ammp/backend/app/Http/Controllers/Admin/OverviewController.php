<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Call;
use App\Models\ManagedDevice;
use App\Models\Recording;
use Illuminate\Http\Request;

final class OverviewController extends Controller
{
    public function show(Request $r)
    {
        $teams = $r->user()->supervisedTeamIds();
        $devices = ManagedDevice::query()->when($teams !== null, fn ($q) => $q->whereIn('team_id', $teams));
        $calls = Call::query()->where('initiated_at', '>=', now()->startOfDay())
            ->when($teams !== null, fn ($q) => $q->whereIn('user_id', \Illuminate\Support\Facades\DB::table('team_user')->whereIn('team_id', $teams)->pluck('user_id')));
        return response()->json([
            'devices' => [
                'pending' => (clone $devices)->where('approval_state', 'pending')->count(),
                'approved' => (clone $devices)->where('approval_state', 'approved')->count(),
                'online' => (clone $devices)->where('approval_state', 'approved')->where('presence', 'online')->count(),
                'non_compliant' => (clone $devices)->where('approval_state', 'approved')->where('compliant', false)->count(),
                'on_call' => (clone $devices)->where('work_state', 'on_call')->count(),
            ],
            'calls_today' => [
                'total' => (clone $calls)->count(),
                'answered' => (clone $calls)->whereNotNull('answered_at')->count(),
                'talk_seconds' => (int) (clone $calls)->sum('talk_seconds'),
            ],
            'recordings_failed_7d' => Recording::query()->where('status', 'failed')->where('updated_at', '>=', now()->subDays(7))->count(),
        ]);
    }
}
