<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Domain\Customers\PhoneNormaliser;
use App\Domain\Security\SpreadsheetSanitiser;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\ImportJob;
use App\Models\ImportRowError;
use App\Services\CustomerAssignmentService;
use App\Services\ImportService;
use Illuminate\Http\Request;

final class CustomerController extends Controller
{
    public function template()
    {
        $rows = [
            ['Customer ID', 'Customer Name', 'Phone Number', 'Alternate Number', 'Campaign', 'Assigned Employee', 'Assigned Team', 'Notes', 'Status', 'Follow-up Date'],
            ['CUST-0001', 'Sample Customer', '9876543210', '', 'Campaign A', 'EMP001', '', 'Example row — replace', 'new', '2026-10-15'],
        ];
        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            foreach ($rows as $row) {
                fputcsv($out, $row);
            }
            fclose($out);
        }, 'customer-import-template.csv', ['Content-Type' => 'text/csv']);
    }

    public function imports()
    {
        return response()->json(ImportJob::query()->latest('id')->paginate(50));
    }

    public function upload(Request $r, ImportService $svc)
    {
        $r->validate(['file' => 'required|file|max:' . (config('ammp.uploads.import_max_mb') * 1024)]);
        $job = $svc->upload($r->file('file'), $r->user());
        return response()->json($job, 201);
    }

    public function preview(Request $r, int $id, ImportService $svc)
    {
        $data = $r->validate(['mapping' => 'required|array', 'on_existing' => 'in:update,skip']);
        return response()->json($svc->preview(ImportJob::query()->findOrFail($id), $data['mapping'], $data));
    }

    public function validateImport(Request $r, int $id, ImportService $svc)
    {
        $job = ImportJob::query()->findOrFail($id);
        abort_unless(in_array($job->status, ['uploaded', 'ready'], true), 409);
        $svc->start($job, 'validate', $r->user());
        return response()->json(['status' => 'queued'], 202);
    }

    public function commit(Request $r, int $id, ImportService $svc)
    {
        $job = ImportJob::query()->findOrFail($id);
        abort_unless($job->status === 'ready', 409, 'Validate the import first.');
        $svc->start($job, 'commit', $r->user());
        return response()->json(['status' => 'queued'], 202);
    }

    public function importStatus(int $id)
    {
        $job = ImportJob::query()->findOrFail($id);
        return response()->json($job->toArray() + ['sample_errors' => ImportRowError::query()->where('import_job_id', $id)->orderBy('row_number')->limit(50)->get()]);
    }

    public function errorReport(int $id)
    {
        $job = ImportJob::query()->findOrFail($id);
        return response()->streamDownload(function () use ($job) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Row', 'Field', 'Error', 'Message']);
            ImportRowError::query()->where('import_job_id', $job->id)->orderBy('row_number')->chunk(1000, function ($chunk) use ($out) {
                foreach ($chunk as $e) {
                    fputcsv($out, SpreadsheetSanitiser::row([$e->row_number, $e->field, $e->code, $e->message]));
                }
            });
            fclose($out);
        }, "import-{$job->id}-errors.csv", ['Content-Type' => 'text/csv']);
    }

    public function index(Request $r)
    {
        $teams = $r->user()->supervisedTeamIds();
        return response()->json(Customer::query()
            ->when($teams !== null, fn ($q) => $q->where(fn ($w) => $w->whereIn('assigned_team_id', $teams)
                ->orWhereIn('assigned_user_id', \Illuminate\Support\Facades\DB::table('team_user')->whereIn('team_id', $teams)->pluck('user_id'))))
            ->when($r->query('q'), fn ($q, $s) => $q->where(fn ($w) => $w->where('name', 'like', '%' . addcslashes($s, '%_') . '%')->orWhere('customer_ref', $s)))
            ->when($r->query('status'), fn ($q, $s) => $q->where('status', $s))
            ->when(!$r->boolean('include_withdrawn'), fn ($q) => $q->whereNull('withdrawn_at'))
            ->orderByDesc('id')->paginate(100)
            ->through(fn (Customer $c) => $c->toArray() + ['phone_masked' => PhoneNormaliser::mask($c->phone)]));
    }

    public function assign(Request $r, CustomerAssignmentService $svc)
    {
        $data = $r->validate(['customer_ids' => 'required|array|max:5000', 'customer_ids.*' => 'integer', 'user_id' => 'nullable|integer', 'team_id' => 'nullable|integer']);
        return response()->json(['updated' => $svc->assign($data['customer_ids'], $data['user_id'] ?? null, $data['team_id'] ?? null, $r->user())]);
    }

    public function withdraw(Request $r, CustomerAssignmentService $svc)
    {
        $data = $r->validate(['customer_ids' => 'required|array|max:5000', 'customer_ids.*' => 'integer']);
        return response()->json(['withdrawn' => $svc->withdraw($data['customer_ids'], $r->user())]);
    }
}
