<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Domain\Tenancy\CompanyResolver;
use App\Models\Company;
use App\Support\CurrentCompany;
use App\Support\DbCompanyDirectory;
use Closure;
use Illuminate\Http\Request;

final class ResolveCompany
{
    public function __construct(private readonly CurrentCompany $current)
    {
    }

    public function handle(Request $request, Closure $next)
    {
        $cfg = config('ammp.tenancy');
        $resolver = new CompanyResolver(
            new DbCompanyDirectory(),
            $cfg['mode'] === 'fixed' ? ($cfg['fixed_company_id'] ?? throw new \RuntimeException('TENANCY_FIXED_COMPANY_ID is required in fixed mode.')) : null,
            $cfg['base_domain'],
        );
        $id = $resolver->resolve($request->getHost(), $request->header('X-Workspace'));
        $company = Company::query()->whereKey($id)->where('status', 'active')->firstOrFail();
        $this->current->set($company);
        return $next($request);
    }
}
