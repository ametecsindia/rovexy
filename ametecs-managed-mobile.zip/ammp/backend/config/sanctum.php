<?php

return [
    // Hosts allowed to use cookie (SPA) authentication: the admin UI is served from the same origin.
    'stateful' => explode(',', (string) env('SANCTUM_STATEFUL_DOMAINS', 'localhost,127.0.0.1')),
    'guard' => ['web'],
    'expiration' => null,
    'token_prefix' => '',
    'middleware' => [
        // Disabled: it resolves the session user before the company is bound (tenant scope would throw).
        // Session expiry/rotation is enforced by EnsureMfaVerified (idle + absolute limits) instead.
        'authenticate_session' => null,
        'encrypt_cookies' => Illuminate\Cookie\Middleware\EncryptCookies::class,
        'validate_csrf_token' => Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class,
    ],
];
