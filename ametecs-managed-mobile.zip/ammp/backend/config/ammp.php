<?php

return [
    'product_name' => env('APP_PRODUCT_NAME', 'Ametecs Managed Mobile'),
    'employee_app_package' => env('AMMP_APP_PACKAGE', 'in.ametecs.managedmobile'),

    'tenancy' => [
        // 'shared' (SaaS: resolve from verified domain or workspace slug) | 'fixed' (on-prem single company)
        'mode' => env('TENANCY_MODE', 'shared'),
        'fixed_company_id' => env('TENANCY_FIXED_COMPANY_ID') ? (int) env('TENANCY_FIXED_COMPANY_ID') : null,
        'base_domain' => env('TENANCY_BASE_DOMAIN'),
    ],

    'sessions' => [
        'device_token_ttl' => 900,          // 15 min
        'work_access_ttl' => 900,           // 15 min
        'work_refresh_ttl' => 43200,        // 12 h
        'admin_absolute_hours' => 12,
        'ws_revalidate_seconds' => 60,      // documented WebSocket revocation bound
    ],

    'rate_limits' => [
        'register_per_ip_per_hour' => 20,
        'login_per_device_per_minute' => 5,
        'status_poll_per_device_per_minute' => 12,
    ],

    'management' => [
        // 'amapi' (Android Management API, production) | 'app_only' (no device-level enforcement; reported honestly)
        'driver' => env('MANAGEMENT_DRIVER', 'app_only'),
        'amapi' => [
            'enterprise' => env('AMAPI_ENTERPRISE_NAME'),           // enterprises/LC0xxxxx (per company — stored on companies.amapi_enterprise when multi-tenant)
            'service_account_json' => env('AMAPI_SERVICE_ACCOUNT_JSON_PATH'),
            'pubsub_audience' => env('AMAPI_PUBSUB_AUDIENCE'),
        ],
    ],

    'telephony' => [
        // 'freeswitch' | 'simulator' (refuses to run unless APP_ENV=local or testing)
        'driver' => env('TELEPHONY_DRIVER', 'freeswitch'),
        'freeswitch' => [
            'host' => env('FREESWITCH_ESL_HOST', '127.0.0.1'),
            'port' => (int) env('FREESWITCH_ESL_PORT', 8021),
            'password' => env('FREESWITCH_ESL_PASSWORD'),
            'gateway' => env('FREESWITCH_GATEWAY'),
            'caller_id' => env('FREESWITCH_CALLER_ID'),
            'sip_domain' => env('FREESWITCH_SIP_DOMAIN'),
            'recordings_base' => env('FREESWITCH_RECORDINGS_BASE', '/var/lib/freeswitch/recordings'),
            // 'local' (shared mount readable by app server) | 'http' (pull from FS host via signed URL)
            'recording_source' => env('FREESWITCH_RECORDING_SOURCE', 'local'),
            'recording_http_base' => env('FREESWITCH_RECORDING_HTTP_BASE'),
            'recording_http_secret' => env('FREESWITCH_RECORDING_HTTP_SECRET'),
        ],
        // HMAC secret for the HTTP event webhook alternative (existing Ametecs telephony systems).
        'webhook_secret' => env('TELEPHONY_WEBHOOK_SECRET'),
    ],

    'recordings' => [
        'disk' => env('RECORDINGS_DISK', 'recordings'),
        'playback_url_ttl' => 300,
        'transcode' => env('RECORDINGS_TRANSCODE', 'mp3'),     // 'none' | 'mp3' (requires ffmpeg on PATH)
        'missing_after_minutes' => 30,                          // reconciliation alert threshold
    ],

    'push' => [
        // 'fcm' | 'log' (development only; refuses in production)
        'driver' => env('PUSH_DRIVER', 'log'),
        'fcm_project_id' => env('FCM_PROJECT_ID'),
        'fcm_service_account_json' => env('FCM_SERVICE_ACCOUNT_JSON_PATH'),
    ],

    'media' => [
        'turn_urls' => array_filter(explode(',', (string) env('TURN_URLS', ''))),
        'turn_secret' => env('TURN_SHARED_SECRET'),
        'stun_urls' => array_filter(explode(',', (string) env('STUN_URLS', ''))),
    ],

    'uploads' => [
        'import_max_mb' => 20,
        'branding_logo_max_kb' => 512,
    ],
];
