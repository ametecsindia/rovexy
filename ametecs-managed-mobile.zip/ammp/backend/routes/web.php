<?php

use Illuminate\Support\Facades\Route;

// The admin SPA (React build output copied to public/admin). Served from the company's own origin so cookies,
// CSRF and CSP stay same-origin. The Electron desktop app loads this URL.
Route::get('/admin/{path?}', function () {
    $index = public_path('admin/index.html');
    abort_unless(is_file($index), 404, 'Admin UI not built. Run: cd admin && npm run build');
    return response()->file($index, ['Cache-Control' => 'no-store']);
})->where('path', '^(?!assets/).*$');

Route::get('/', fn () => redirect('/admin'));
