<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\Mobile;
use App\Http\Controllers\Telephony\TelephonyWebhookController;
use App\Http\Controllers\Management\AmapiNotificationController;
use Illuminate\Support\Facades\Route;

/*
| Mobile API v1 — every route first resolves the company (no fallback).
| Layers: bootstrap (public) → device-signed → device session → work session (+ permission, + compliance).
*/
Route::prefix('mobile/v1')->middleware('company')->group(function () {
    Route::get('bootstrap', [Mobile\BootstrapController::class, 'show'])->middleware('throttle:bootstrap');
    Route::get('branding/logo', [Mobile\BootstrapController::class, 'logo'])->middleware('throttle:bootstrap');
    Route::post('devices/register', [Mobile\DeviceController::class, 'register'])->middleware('throttle:register');

    Route::get('device/status', [Mobile\DeviceController::class, 'status'])->middleware(['device.signed:allow_inactive', 'throttle:status']);
    Route::post('device/session', [Mobile\DeviceController::class, 'session'])->middleware(['device.signed', 'throttle:status']);
    Route::post('auth/refresh', [Mobile\AuthController::class, 'refresh'])->middleware(['device.signed', 'throttle:login']);

    Route::middleware('device.session')->group(function () {
        Route::post('auth/login', [Mobile\AuthController::class, 'login'])->middleware('throttle:login');
        Route::get('policy', [Mobile\PolicyController::class, 'show']);
        Route::post('policy/ack', [Mobile\PolicyController::class, 'ack']);
        Route::put('device/push-token', [Mobile\DeviceController::class, 'pushToken']);
        Route::post('device/commands/{id}/ack', [Mobile\DeviceController::class, 'ackCommand']);
    });

    Route::middleware('work.session')->group(function () {
        Route::get('me', [Mobile\AuthController::class, 'me']);
        Route::post('auth/logout', [Mobile\AuthController::class, 'logout']);
        Route::post('sync', [Mobile\SyncController::class, 'store']);
        Route::get('conversations', [Mobile\ChatController::class, 'index'])->middleware('perm:chat.use');
        Route::get('conversations/{id}/messages', [Mobile\ChatController::class, 'messages'])->middleware('perm:chat.use');
        Route::post('conversations/{id}/messages', [Mobile\ChatController::class, 'send'])->middleware(['perm:chat.use', 'throttle:chat']);
        Route::get('conversations/{id}/messages/{messageId}/attachment', [Mobile\ChatController::class, 'attachment'])->middleware('perm:chat.use');
        Route::get('media/pending', [Mobile\MediaController::class, 'pending']);
        Route::post('media/{uuid}/{action}', [Mobile\MediaController::class, 'act'])->whereIn('action', ['accept', 'decline', 'start', 'end', 'signal', 'protected-content']);
        Route::get('media/{uuid}/ice', [Mobile\MediaController::class, 'ice']);

        Route::middleware('work.compliant')->group(function () {
            Route::get('customers', [Mobile\CustomerController::class, 'index']);
            Route::get('dispositions', [Mobile\CustomerController::class, 'dispositions']);
            Route::post('calls', [Mobile\CallController::class, 'store'])->middleware(['perm:calls.make', 'throttle:calls']);
            Route::get('calls/{uuid}', [Mobile\CallController::class, 'show']);
            Route::post('calls/{uuid}/hangup', [Mobile\CallController::class, 'hangup']);
            Route::post('calls/{uuid}/disposition', [Mobile\CallController::class, 'disposition']);
        });
    });
});

/*
| Admin API — Sanctum stateful cookie session + CSRF, company-resolved, MFA-gated, permission-gated.
*/
Route::prefix('admin')->middleware('company')->group(function () {
    Route::post('auth/login', [Admin\AuthController::class, 'login'])->middleware('throttle:admin-login');
    Route::middleware('auth:web')->group(function () {
        Route::post('auth/mfa/setup', [Admin\AuthController::class, 'mfaSetup']);
        Route::post('auth/mfa/verify', [Admin\AuthController::class, 'mfaVerify'])->middleware('throttle:admin-login');
        Route::post('auth/logout', [Admin\AuthController::class, 'logout']);
        Route::get('auth/me', [Admin\AuthController::class, 'me']);
    });

    Route::middleware(['auth:web', 'mfa'])->group(function () {
        Route::get('overview', [Admin\OverviewController::class, 'show']);

        Route::get('employees', [Admin\PeopleController::class, 'employees'])->middleware('perm:employees.view');
        Route::post('employees', [Admin\PeopleController::class, 'createEmployee'])->middleware('perm:employees.manage');
        Route::patch('employees/{id}', [Admin\PeopleController::class, 'updateEmployee'])->middleware('perm:employees.manage');
        Route::get('teams', [Admin\PeopleController::class, 'teams'])->middleware('perm:employees.view');
        Route::post('teams', [Admin\PeopleController::class, 'createTeam'])->middleware('perm:employees.manage');
        Route::put('teams/{id}/members', [Admin\PeopleController::class, 'setMembers'])->middleware('perm:employees.manage');
        Route::get('roles', [Admin\PeopleController::class, 'roles'])->middleware('perm:employees.view');

        Route::get('devices', [Admin\DeviceController::class, 'index'])->middleware('perm:devices.view');
        Route::get('devices/{id}', [Admin\DeviceController::class, 'show'])->middleware('perm:devices.view');
        Route::post('devices/{id}/approve', [Admin\DeviceController::class, 'approve'])->middleware('perm:devices.approve');
        Route::post('devices/{id}/reject', [Admin\DeviceController::class, 'reject'])->middleware('perm:devices.approve');
        Route::post('devices/{id}/reassign', [Admin\DeviceController::class, 'reassign'])->middleware('perm:devices.approve');
        Route::post('devices/{id}/revoke', [Admin\DeviceController::class, 'revoke'])->middleware('perm:devices.revoke');
        Route::post('devices/{id}/wipe', [Admin\DeviceController::class, 'wipe'])->middleware('perm:devices.wipe');
        Route::post('enrolment-tokens', [Admin\DeviceController::class, 'enrolmentToken'])->middleware('perm:devices.approve');

        Route::get('policy/catalog', [Admin\PolicyController::class, 'catalog'])->middleware('perm:policies.view');
        Route::get('policies', [Admin\PolicyController::class, 'index'])->middleware('perm:policies.view');
        Route::post('policies', [Admin\PolicyController::class, 'createProfile'])->middleware('perm:policies.edit');
        Route::post('policies/{id}/versions', [Admin\PolicyController::class, 'draft'])->middleware('perm:policies.edit');
        Route::post('policies/{id}/versions/{versionId}/publish', [Admin\PolicyController::class, 'publish'])->middleware('perm:policies.publish');
        Route::post('policies/{id}/rollback', [Admin\PolicyController::class, 'rollback'])->middleware('perm:policies.publish');
        Route::put('policy-assignments', [Admin\PolicyController::class, 'assign'])->middleware('perm:policies.publish');
        Route::get('devices/{id}/effective-policy', [Admin\PolicyController::class, 'effective'])->middleware('perm:policies.view');

        Route::get('imports/template', [Admin\CustomerController::class, 'template'])->middleware('perm:customers.import');
        Route::get('imports', [Admin\CustomerController::class, 'imports'])->middleware('perm:customers.import');
        Route::post('imports', [Admin\CustomerController::class, 'upload'])->middleware(['perm:customers.import', 'throttle:uploads']);
        Route::post('imports/{id}/preview', [Admin\CustomerController::class, 'preview'])->middleware('perm:customers.import');
        Route::post('imports/{id}/validate', [Admin\CustomerController::class, 'validateImport'])->middleware('perm:customers.import');
        Route::post('imports/{id}/commit', [Admin\CustomerController::class, 'commit'])->middleware('perm:customers.import');
        Route::get('imports/{id}', [Admin\CustomerController::class, 'importStatus'])->middleware('perm:customers.import');
        Route::get('imports/{id}/errors.csv', [Admin\CustomerController::class, 'errorReport'])->middleware('perm:customers.import');
        Route::get('customers', [Admin\CustomerController::class, 'index'])->middleware('perm:customers.view');
        Route::post('customers/assign', [Admin\CustomerController::class, 'assign'])->middleware('perm:customers.assign');
        Route::post('customers/withdraw', [Admin\CustomerController::class, 'withdraw'])->middleware('perm:customers.assign');

        Route::get('calls', [Admin\CallController::class, 'index'])->middleware('perm:calls.view');
        Route::get('calls/{id}', [Admin\CallController::class, 'show'])->middleware('perm:calls.view');
        Route::post('calls/{id}/recording/playback', [Admin\CallController::class, 'playback'])->middleware('perm:recordings.play');
        Route::post('calls/{id}/recording/download', [Admin\CallController::class, 'download'])->middleware('perm:recordings.download');
        Route::post('calls/{id}/recording/retry', [Admin\CallController::class, 'retry'])->middleware('perm:telephony.configure');
        Route::get('follow-ups', [Admin\CallController::class, 'followUps'])->middleware('perm:calls.view');
        Route::get('disposition-codes', [Admin\CallController::class, 'codes'])->middleware('perm:calls.view');
        Route::put('disposition-codes', [Admin\CallController::class, 'saveCodes'])->middleware('perm:telephony.configure');

        Route::get('presence', [Admin\SupervisionController::class, 'presence'])->middleware('perm:employees.view');
        Route::get('locations', [Admin\SupervisionController::class, 'locations'])->middleware('perm:location.view');
        Route::get('media-sessions', [Admin\SupervisionController::class, 'mediaIndex']);
        Route::post('media-sessions', [Admin\SupervisionController::class, 'mediaRequest']);
        Route::post('media-sessions/{uuid}/end', [Admin\SupervisionController::class, 'mediaEnd']);
        Route::post('media-sessions/{uuid}/signal', [Admin\SupervisionController::class, 'mediaSignal']);
        Route::get('media-sessions/{uuid}/ice', [Admin\SupervisionController::class, 'mediaIce']);
        Route::post('media-sessions/{uuid}/screenshots', [Admin\SupervisionController::class, 'screenshot'])->middleware('perm:media.screenshot');
        Route::get('conversations', [Admin\SupervisionController::class, 'conversations'])->middleware('perm:chat.use');
        Route::post('conversations', [Admin\SupervisionController::class, 'startConversation'])->middleware('perm:chat.use');
        Route::get('conversations/{id}/messages', [Admin\SupervisionController::class, 'messages'])->middleware('perm:chat.use');
        Route::post('conversations/{id}/messages', [Admin\SupervisionController::class, 'send'])->middleware(['perm:chat.use', 'throttle:chat']);

        Route::get('branding', [Admin\SettingsController::class, 'branding']);
        Route::post('branding', [Admin\SettingsController::class, 'saveBranding'])->middleware('perm:branding.manage');
        Route::get('storage/estimate', [Admin\SettingsController::class, 'estimate'])->middleware('perm:settings.storage');
        Route::get('retention-jobs', [Admin\SettingsController::class, 'retentionJobs'])->middleware('perm:settings.retention');
        Route::post('retention-jobs', [Admin\SettingsController::class, 'planRetention'])->middleware('perm:settings.retention');
        Route::post('retention-jobs/{id}/approve', [Admin\SettingsController::class, 'approveRetention'])->middleware('perm:settings.retention');
        Route::get('audit', [Admin\SettingsController::class, 'audit'])->middleware('perm:audit.view');
        Route::get('health', [Admin\SettingsController::class, 'health'])->middleware('perm:system.health');
        Route::get('reports/calls.csv', [Admin\SettingsController::class, 'exportCalls'])->middleware('perm:reports.export');
    });
});

// Short-lived signed recording stream (local storage driver). URL minted only after a scoped, audited lookup.
Route::get('admin/recordings/{id}/stream', [Admin\CallController::class, 'stream'])->name('recordings.stream')->middleware(['company', 'signed']);

// Telephony HMAC webhook (alternative to the ESL listener for existing Ametecs telephony systems). No tenant guessing:
// the company is taken from the call record the event references.
Route::post('telephony/v1/events', [TelephonyWebhookController::class, 'store'])->middleware('throttle:telephony');
// AMAPI Pub/Sub push notifications (OIDC-verified).
Route::post('amapi/v1/notifications', [AmapiNotificationController::class, 'store']);
