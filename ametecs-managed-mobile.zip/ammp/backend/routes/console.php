<?php

use App\Jobs\ReconcileRecordings;
use App\Models\Company;
use App\Services\MediaSessionService;
use App\Support\CurrentCompany;
use Illuminate\Support\Facades\Schedule;

Schedule::call(function () {
    Company::query()->where('status', 'active')->each(fn (Company $c) => ReconcileRecordings::dispatch($c->id));
})->everyTenMinutes()->name('recordings:reconcile')->withoutOverlapping();

Schedule::call(function () {
    $ctx = app(CurrentCompany::class);
    Company::query()->where('status', 'active')->each(fn (Company $c) => $ctx->run($c, fn () => app(MediaSessionService::class)->expireStale()));
})->everyMinute()->name('media:expire');

Schedule::call(function () {
    // Presence: a device with no contact for 3 minutes is offline (heartbeat every 60 s while the app runs).
    \Illuminate\Support\Facades\DB::table('managed_devices')->where('presence', 'online')->where('last_contact_at', '<', now()->subMinutes(3))->update(['presence' => 'offline']);
})->everyMinute()->name('presence:sweep');
