// Same-origin JSON client. Cookie session + Laravel CSRF (XSRF-TOKEN cookie → X-XSRF-TOKEN header).
// No tokens are ever stored in localStorage/sessionStorage.

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public body?: unknown) {
    super(message);
  }
}

const workspace = (import.meta.env.VITE_WORKSPACE as string | undefined) ?? undefined;

function xsrf(): string | undefined {
  const m = document.cookie.match(/(?:^|; )XSRF-TOKEN=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : undefined;
}

let csrfReady: Promise<void> | null = null;
export function ensureCsrf(): Promise<void> {
  csrfReady ??= fetch('/sanctum/csrf-cookie', { credentials: 'same-origin' }).then(() => undefined);
  return csrfReady;
}

export function headers(extra: Record<string, string> = {}): Record<string, string> {
  const h: Record<string, string> = { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...extra };
  const t = xsrf();
  if (t) h['X-XSRF-TOKEN'] = t;
  if (workspace) h['X-Workspace'] = workspace;
  return h;
}

export async function api<T = any>(method: string, path: string, body?: unknown): Promise<T> {
  if (method !== 'GET') await ensureCsrf();
  const isForm = body instanceof FormData;
  const res = await fetch(`/api/admin${path}`, {
    method,
    credentials: 'same-origin',
    headers: headers(isForm || body === undefined ? {} : { 'Content-Type': 'application/json' }),
    body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
  });
  const text = await res.text();
  const data = text ? safeJson(text) : null;
  if (!res.ok) {
    const code = (data && (data.error as string)) || (res.status === 419 ? 'csrf_expired' : `http_${res.status}`);
    const msg = (data && (data.message as string)) || friendly(code);
    if (res.status === 419) csrfReady = null;
    throw new ApiError(res.status, code, msg, data);
  }
  return data as T;
}

function safeJson(t: string): any {
  try {
    return JSON.parse(t);
  } catch {
    return { message: t.slice(0, 200) };
  }
}

export function friendly(code: string): string {
  const map: Record<string, string> = {
    invalid_credentials: 'Email or password is incorrect.',
    invalid_code: 'That code is not valid. Check the time on your authenticator device.',
    mfa_required: 'Two-step verification is required.',
    session_expired: 'Your session expired. Sign in again.',
    forbidden: 'You do not have permission for this action.',
    csrf_expired: 'Security token expired. Please retry.',
    policy_conflicts: 'Resolve the listed policy conflicts before publishing.',
    approval_code_mismatch: 'The code does not match the code shown on the phone.',
  };
  return map[code] ?? code.replace(/_/g, ' ');
}

export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b?: unknown) => api<T>('POST', p, b ?? {});
export const put = <T = any>(p: string, b?: unknown) => api<T>('PUT', p, b ?? {});
export const patch = <T = any>(p: string, b?: unknown) => api<T>('PATCH', p, b ?? {});

export function qs(params: Record<string, string | number | boolean | undefined | null>): string {
  const s = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') s.set(k, String(v));
  const q = s.toString();
  return q ? `?${q}` : '';
}

export function fmtDate(iso?: string | null, tz?: string): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', { timeZone: tz, dateStyle: 'medium', timeStyle: 'short' });
}

export function fmtSeconds(s?: number | null): string {
  if (s === null || s === undefined) return '—';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h}h ${m}m` : m ? `${m}m ${s % 60}s` : `${s}s`;
}
