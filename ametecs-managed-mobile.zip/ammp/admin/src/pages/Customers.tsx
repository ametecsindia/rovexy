import { useEffect, useState } from 'react';
import { get, post, fmtDate, qs } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Badge, Card, ErrorBox, Field, Notice, Page, Table, useAction, useAsync } from '../components/ui';

const FIELDS: [string, string, boolean][] = [
  ['customer_ref', 'Customer ID', true], ['name', 'Customer name', true], ['phone', 'Phone number', true], ['alt_phone', 'Alternate number', false],
  ['campaign', 'Campaign', false], ['assigned_employee', 'Assigned employee (User ID)', false], ['assigned_team', 'Assigned team (code)', false],
  ['notes', 'Notes', false], ['status', 'Status', false], ['follow_up_date', 'Follow-up date', false],
];

export function ImportsPage() {
  const imports = useAsync(() => get('/imports'));
  const [job, setJob] = useState<any | null>(null);
  const [mapping, setMapping] = useState<Record<string, number | null>>({});
  const [onExisting, setOnExisting] = useState('update');
  const [preview, setPreview] = useState<any | null>(null);
  const a = useAction();

  useEffect(() => {
    if (!job || !['validating', 'committing'].includes(job.status)) return;
    const t = setInterval(async () => setJob(await get(`/imports/${job.id}`)), 2000);
    return () => clearInterval(t);
  }, [job]);

  const upload = (file: File) => a.run(async () => {
    const fd = new FormData();
    fd.append('file', file);
    const j = await post('/imports', fd);
    setJob(j);
    setMapping(j.mapping);
    setPreview(null);
  });

  return (
    <Page title="Customer imports" subtitle="Upload → map columns → preview → validate all rows → commit. Numbers are never written to phone contacts."
      actions={<a className="button secondary" href="/api/admin/imports/template">Download sample template</a>}>
      <ErrorBox error={a.error ?? imports.error} />
      <Card title="1. Upload CSV or XLSX">
        <input type="file" accept=".csv,.xlsx" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} aria-label="Import file" />
      </Card>
      {job && (
        <Card title={`2. Map columns — ${job.original_name}`} actions={<Badge value={job.status} />}>
          <div className="form-grid">
            {FIELDS.map(([f, label, req]) => (
              <Field key={f} label={`${label}${req ? ' *' : ''}`}>
                <select value={mapping[f] ?? ''} onChange={(e) => setMapping({ ...mapping, [f]: e.target.value === '' ? null : Number(e.target.value) })}>
                  <option value="">— not in file —</option>{(job.headers as string[]).map((h, i) => <option key={i} value={i}>{h}</option>)}
                </select>
              </Field>
            ))}
            <Field label="If Customer ID already exists"><select value={onExisting} onChange={(e) => setOnExisting(e.target.value)}><option value="update">Update it</option><option value="skip">Skip the row</option></select></Field>
          </div>
          <div className="row">
            <button disabled={a.busy} onClick={() => a.run(async () => setPreview((await post(`/imports/${job.id}/preview`, { mapping, on_existing: onExisting })).result))}>Preview first rows</button>
            <button className="secondary" disabled={a.busy || !preview} onClick={() => a.run(async () => { await post(`/imports/${job.id}/validate`); setJob(await get(`/imports/${job.id}`)); })}>Validate whole file</button>
            <button disabled={a.busy || job.status !== 'ready' || job.valid_rows === 0} onClick={() => a.run(async () => { await post(`/imports/${job.id}/commit`); setJob(await get(`/imports/${job.id}`)); })}>Commit {job.valid_rows ? `${job.valid_rows} valid rows` : ''}</button>
          </div>
          {job.status === 'ready' && <Notice tone={job.error_rows ? 'warn' : 'ok'}>{job.total_rows} rows: {job.valid_rows} valid, {job.error_rows} with errors. {job.error_rows > 0 && <a href={`/api/admin/imports/${job.id}/errors.csv`}>Download error report</a>}</Notice>}
          {job.status === 'completed' && <Notice tone="ok">Imported: {job.created_count} created, {job.updated_count} updated, {job.skipped_count} skipped.</Notice>}
          {job.status === 'failed' && <Notice tone="bad">Import failed: {job.failure}</Notice>}
        </Card>
      )}
      {preview && (
        <Card title="Preview">
          <Table rows={preview.valid.map((r: any) => ({ id: r.row, ...r }))} empty="No valid rows in the preview." columns={[{ key: 'row', label: 'Row' }, { key: 'customer_ref', label: 'Customer ID' }, { key: 'name', label: 'Name' },
            { key: 'phone', label: 'Normalised phone' }, { key: 'assigned_employee', label: 'Employee' }, { key: 'status', label: 'Status' }]} />
          {preview.errors.length > 0 && <Table rows={preview.errors.map((e: any, i: number) => ({ id: i, ...e }))} columns={[{ key: 'row', label: 'Row' }, { key: 'field', label: 'Field' }, { key: 'message', label: 'Problem' }]} />}
        </Card>
      )}
      <Card title="Import history">
        <Table rows={imports.data?.data} columns={[{ key: 'id', label: '#' }, { key: 'original_name', label: 'File' }, { key: 'status', label: 'Status', render: (j: any) => <Badge value={j.status} /> },
          { key: 'total_rows', label: 'Rows', align: 'right' }, { key: 'error_rows', label: 'Errors', align: 'right' }, { key: 'created_count', label: 'Created', align: 'right' },
          { key: 'updated_count', label: 'Updated', align: 'right' }, { key: 'created_at', label: 'Uploaded', render: (j: any) => fmtDate(j.created_at) }]} />
      </Card>
    </Page>
  );
}

export function CustomersPage() {
  const { can } = useAuth();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const customers = useAsync(() => get(`/customers${qs({ q, status })}`), [q, status]);
  const emps = useAsync(() => (can('employees.view') ? get('/employees') : Promise.resolve({ data: [] })));
  const [sel, setSel] = useState<number[]>([]);
  const [to, setTo] = useState('');
  const a = useAction();
  const toggle = (id: number) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  return (
    <Page title="Customers & assignment" subtitle="Phones receive only customers currently assigned to the signed-in employee; withdrawn customers are removed at the next sync.">
      <ErrorBox error={customers.error ?? a.error} />
      <Card actions={can('customers.assign') && sel.length > 0 && (
        <>
          <span className="muted">{sel.length} selected</span>
          <select value={to} onChange={(e) => setTo(e.target.value)} aria-label="Assign to"><option value="">Assign to…</option>{(emps.data?.data ?? []).map((e: any) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
          <button disabled={a.busy || !to} onClick={() => a.run(async () => { await post('/customers/assign', { customer_ids: sel, user_id: Number(to) }); setSel([]); await customers.reload(); })}>Assign</button>
          <button className="danger" disabled={a.busy} onClick={() => a.run(async () => { await post('/customers/withdraw', { customer_ids: sel }); setSel([]); await customers.reload(); })}>Withdraw</button>
        </>
      )}>
        <div className="row" style={{ marginBottom: 12 }}>
          <input placeholder="Search name or exact Customer ID" value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 300 }} />
          <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status"><option value="">All statuses</option>{['new', 'in_progress', 'follow_up', 'closed', 'do_not_call'].map((s) => <option key={s}>{s}</option>)}</select>
        </div>
        <Table rows={customers.data?.data} columns={[
          { key: 's', label: '', render: (c: any) => <input type="checkbox" checked={sel.includes(c.id)} onChange={() => toggle(c.id)} aria-label={`Select ${c.customer_ref}`} style={{ width: 'auto' }} /> },
          { key: 'customer_ref', label: 'Customer ID' }, { key: 'name', label: 'Name' }, { key: 'phone_masked', label: 'Phone' },
          { key: 'campaign', label: 'Campaign' }, { key: 'status', label: 'Status', render: (c: any) => <Badge value={c.status === 'do_not_call' ? 'failed' : 'info'} label={c.status} /> },
          { key: 'assigned_user_id', label: 'Employee', render: (c: any) => (emps.data?.data ?? []).find((e: any) => e.id === c.assigned_user_id)?.name ?? (c.assigned_team_id ? `Team #${c.assigned_team_id}` : '—') },
          { key: 'follow_up_on', label: 'Follow-up', render: (c: any) => c.follow_up_on?.slice(0, 10) ?? '—' },
        ]} />
      </Card>
    </Page>
  );
}
