import { useState, type FormEvent } from 'react';
import QRCode from 'qrcode';
import { post } from '../lib/api';
import { useAuth } from '../lib/auth';
import { ErrorBox, Field, useAction } from '../components/ui';

/** Email + password, then mandatory TOTP. First sign-in enrols an authenticator app. */
export function LoginPage() {
  const { refresh } = useAuth();
  const [step, setStep] = useState<'password' | 'verify' | 'enrol'>('password');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [enrol, setEnrol] = useState<{ secret: string; qr: string } | null>(null);
  const a = useAction();

  const submitPassword = (e: FormEvent) => {
    e.preventDefault();
    void a.run(async () => {
      const r = await post<{ mfa: 'verify' | 'enrol' }>('/auth/login', { email, password });
      setPassword('');
      if (r.mfa === 'enrol') {
        const s = await post<{ secret: string; otpauth_uri: string }>('/auth/mfa/setup');
        setEnrol({ secret: s.secret, qr: await QRCode.toDataURL(s.otpauth_uri, { margin: 1, width: 200 }) });
      }
      setStep(r.mfa);
    });
  };
  const submitCode = (e: FormEvent) => {
    e.preventDefault();
    void a.run(async () => {
      await post('/auth/mfa/verify', { code });
      await refresh();
    });
  };

  return (
    <div className="login">
      <div className="card">
        <h1 style={{ marginBottom: 12 }}>Administrator sign-in</h1>
        <ErrorBox error={a.error} />
        {step === 'password' ? (
          <form onSubmit={submitPassword}>
            <Field label="Email"><input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></Field>
            <Field label="Password"><input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
            <button disabled={a.busy} type="submit">Continue</button>
          </form>
        ) : (
          <form onSubmit={submitCode}>
            {step === 'enrol' && enrol && (
              <>
                <p>Two-step verification is required. Scan this with an authenticator app, then enter the 6-digit code.</p>
                <img src={enrol.qr} alt="Authenticator QR code" width={200} height={200} />
                <p className="muted">Or enter this key manually: <span className="code">{enrol.secret}</span></p>
              </>
            )}
            <Field label="6-digit code"><input inputMode="numeric" pattern="\d{6}" maxLength={6} autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value)} required /></Field>
            <button disabled={a.busy} type="submit">Verify</button>
          </form>
        )}
      </div>
    </div>
  );
}
