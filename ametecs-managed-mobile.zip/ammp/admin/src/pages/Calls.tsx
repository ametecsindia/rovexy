import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { get, post, put, fmtDate, fmtSeconds, qs } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Badge, Card, ErrorBox, Modal, Notice, Page, Table, useAction, useAsync } from '../components/ui';

export function CallsPage() {
  const { me } = useAuth();
  const [params] = useSearchParams();
  const [f, setF] = useState({ state: '', recording_status: params.get('recording_status') ?? '' });
  const calls = useAsync(() => get(`/calls${qs(f)}`), [f.state, f.recording_status]);
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Page title="Call history & recordings" subtitle="Ring time, talk time and total time are measured separately. A completed call does not imply a recording exists."
      actions={<>
        <select value={f.state} onChange={(e) => setF({ ...f, state: e.target.value })} aria-label="Outcome"><option value="">All outcomes</option>{['completed', 'busy', 'no_answer', 'rejected', 'failed', 'disconnected', 'agent_unanswered', 'cancelled'].map((s) => <option key={s}>{s}</option>)}</select>
        <select value={f.recording_status} onChange={(e) => setF({ ...f, recording_status: e.target.value })} aria-label="Recording"><option value="">All recordings</option>{['available', 'processing', 'pending', 'failed', 'not_required', 'deleted_by_retention'].map((s) => <option key={s}>{s}</option>)}</select>
        <button className="secondary" onClick={calls.reload}>Refresh</button></>}>
      <ErrorBox error={calls.error} />
      <Card>
        <Table rows={calls.data?.data} onRow={(c: any) => setOpen(c.id)} columns={[
          { key: 'initiated_at', label: 'Started', render: (c: any) => fmtDate(c.initiated_at, me?.company.timezone) },
          { key: 'user', label: 'Employee', render: (c: any) => c.user?.name },
          { key: 'customer', label: 'Customer', render: (c: any) => c.customer ? `${c.customer.customer_ref} · ${c.customer.name}` : 'Manual' },
          { key: 'destination_masked', label: 'Number' },
          { key: 'state', label: 'Outcome', render: (c: any) => <Badge value={c.state} /> },
          { key: 'ring_seconds', label: 'Ring', align: 'right', render: (c: any) => fmtSeconds(c.ring_seconds) },
          { key: 'talk_seconds', label: 'Talk', align: 'right', render: (c: any) => fmtSeconds(c.talk_seconds) },
          { key: 'recording_status', label: 'Recording', render: (c: any) => <Badge value={c.recording_status} /> },
          { key: 'disposition', label: 'Disposition', render: (c: any) => c.disposition?.code ?? (c.disposition_status === 'pending' ? <Badge value="pending" /> : '—') },
        ]} />
      </Card>
      {open && <CallDetail id={open} onClose={() => setOpen(null)} />}
    </Page>
  );
}

function CallDetail({ id, onClose }: { id: number; onClose: () => void }) {
  const { can, me } = useAuth();
  const call = useAsync(() => get(`/calls/${id}`), [id]);
  const [audio, setAudio] = useState<string | null>(null);
  const a = useAction();
  const c = call.data;
  return (
    <Modal title={`Call ${c?.uuid ?? ''}`} onClose={onClose}>
      <ErrorBox error={call.error ?? a.error} />
      {c && (
        <>
          <p><Badge value={c.state} /> {c.hangup_cause && <span className="muted">cause {c.hangup_cause}</span>} {c.failure_reason && <Badge value="failed" label={c.failure_reason} />}</p>
          <p>Ring {fmtSeconds(c.ring_seconds)} · Talk {fmtSeconds(c.talk_seconds)} · Total {fmtSeconds(c.total_seconds)} · Mode {c.calling_mode} / {c.agent_leg}</p>
          <Card title="Recording" actions={<Badge value={c.recording?.status ?? c.recording_status} />}>
            {c.recording?.status === 'available' ? (
              <>
                <p className="muted">{c.recording.format?.toUpperCase()} · {Math.round((c.recording.size_bytes ?? 0) / 1024)} KB · SHA-256 <span className="code">{c.recording.sha256?.slice(0, 16)}…</span> · retained until {fmtDate(c.recording.retention_expires_at, me?.company.timezone)}</p>
                <div className="row">
                  {can('recordings.play') && <button disabled={a.busy} onClick={() => a.run(async () => setAudio((await post(`/calls/${id}/recording/playback`)).url))}>Play</button>}
                  {can('recordings.download') && <button className="secondary" disabled={a.busy} onClick={() => a.run(async () => { const r = await post(`/calls/${id}/recording/download`); window.location.assign(r.url); })}>Download</button>}
                </div>
                {audio && <audio controls autoPlay src={audio} style={{ width: '100%', marginTop: 8 }} />}
              </>
            ) : c.recording?.status === 'failed' ? (
              <>
                <Notice tone="bad">Recording failed: {c.recording.last_error ?? 'unknown'} (attempts: {c.recording.attempts})</Notice>
                {can('telephony.configure') && <button className="secondary" disabled={a.busy} onClick={() => a.run(async () => { await post(`/calls/${id}/recording/retry`); await call.reload(); })}>Retry fetch</button>}
              </>
            ) : <p className="muted">{c.recording ? 'Not yet available.' : 'No recording for this call.'}</p>}
          </Card>
          <Card title="Lifecycle events">
            <Table rows={c.events} columns={[{ key: 'occurred_at', label: 'Time', render: (e: any) => fmtDate(e.occurred_at, me?.company.timezone) }, { key: 'type', label: 'Event' }, { key: 'payload', label: 'Detail', render: (e: any) => e.payload?.cause ?? '' }]} />
          </Card>
          {c.disposition && <Card title="Disposition"><p><strong>{c.disposition.code}</strong> {c.disposition.notes}</p>{c.disposition.follow_up_at && <p>Follow-up: {fmtDate(c.disposition.follow_up_at, me?.company.timezone)}</p>}</Card>}
        </>
      )}
    </Modal>
  );
}

export function CallingConfigPage() {
  const codes = useAsync(() => get<any[]>('/disposition-codes'));
  const health = useAsync(() => get('/health'));
  const [rows, setRows] = useState<any[] | null>(null);
  const a = useAction();
  const list = rows ?? codes.data ?? [];
  return (
    <Page title="Calling configuration" subtitle="Calling hours, prefixes, recording mode and failure behaviour are policy settings (Policy profiles). Telephony credentials live only on the server.">
      <ErrorBox error={codes.error ?? a.error} />
      <Card title="Telephony connection">
        {health.data && (
          <>
            <p>Driver <strong>{health.data.telephony.driver}</strong> · <Badge value={health.data.telephony.ok} label={health.data.telephony.ok ? 'reachable' : 'unreachable'} /> <span className="muted">{health.data.telephony.detail}</span></p>
            {health.data.telephony.simulated && <Notice tone="warn">SIMULATOR — development only. No real calls are placed and no audio is recorded.</Notice>}
          </>
        )}
      </Card>
      <Card title="Disposition codes" actions={<button className="secondary" onClick={() => setRows([...list, { code: '', label: '', requires_follow_up: false, active: true }])}>Add code</button>}>
        <Table rows={list.map((r, i) => ({ ...r, id: i }))} columns={[
          { key: 'code', label: 'Code', render: (r: any) => <input value={r.code} onChange={(e) => setRows(list.map((x, i) => i === r.id ? { ...x, code: e.target.value.toUpperCase() } : x))} /> },
          { key: 'label', label: 'Label', render: (r: any) => <input value={r.label} onChange={(e) => setRows(list.map((x, i) => i === r.id ? { ...x, label: e.target.value } : x))} /> },
          { key: 'f', label: 'Needs follow-up', render: (r: any) => <input type="checkbox" style={{ width: 'auto' }} checked={!!r.requires_follow_up} onChange={(e) => setRows(list.map((x, i) => i === r.id ? { ...x, requires_follow_up: e.target.checked } : x))} /> },
          { key: 'a', label: 'Active', render: (r: any) => <input type="checkbox" style={{ width: 'auto' }} checked={!!r.active} onChange={(e) => setRows(list.map((x, i) => i === r.id ? { ...x, active: e.target.checked } : x))} /> },
        ]} />
        <button disabled={a.busy || !rows} onClick={() => a.run(async () => { await put('/disposition-codes', { codes: list.map(({ code, label, requires_follow_up, active }) => ({ code, label, requires_follow_up: !!requires_follow_up, active: !!active })) }); setRows(null); await codes.reload(); })}>Save codes</button>
      </Card>
    </Page>
  );
}

export function FollowUpsPage() {
  const { me } = useAuth();
  const fu = useAsync(() => get('/follow-ups'));
  return (
    <Page title="Follow-ups & dispositions" subtitle="Open follow-ups created from call dispositions and offline notes.">
      <ErrorBox error={fu.error} />
      <Card>
        <Table rows={fu.data?.data} empty="No open follow-ups." columns={[{ key: 'due_at', label: 'Due', render: (f: any) => fmtDate(f.due_at, me?.company.timezone) },
          { key: 'customer_id', label: 'Customer #' }, { key: 'user_id', label: 'Employee #' }, { key: 'notes', label: 'Notes' },
          { key: 'overdue', label: '', render: (f: any) => new Date(f.due_at) < new Date() ? <Badge value="failed" label="overdue" /> : null }]} />
      </Card>
    </Page>
  );
}
