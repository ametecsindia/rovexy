import { useState } from 'react';
import { get, patch, post, put, fmtDate } from '../lib/api';
import { useAuth } from '../lib/auth';
import { Badge, Card, ErrorBox, Field, Modal, Page, Table, useAction, useAsync } from '../components/ui';

const ROLE_KEYS = ['employee', 'supervisor', 'it_admin', 'auditor', 'company_admin'];

export function EmployeesPage() {
  const { can } = useAuth();
  const emps = useAsync(() => get('/employees'));
  const teams = useAsync(() => get<any[]>('/teams'));
  const [creating, setCreating] = useState(false);
  const [teamModal, setTeamModal] = useState<any | null>(null);
  const a = useAction();
  return (
    <Page title="Employees & teams" actions={can('employees.manage') && <><button onClick={() => setCreating(true)}>Add employee</button><button className="secondary" onClick={() => setTeamModal({})}>Add team</button></>}>
      <ErrorBox error={emps.error ?? teams.error ?? a.error} />
      <Card title="Employees">
        <Table rows={emps.data?.data} columns={[
          { key: 'employee_code', label: 'User ID' }, { key: 'name', label: 'Name' }, { key: 'phone', label: 'Work number' },
          { key: 'roles', label: 'Roles', render: (u: any) => u.roles.map((r: any) => r.name).join(', ') },
          { key: 'teams', label: 'Teams', render: (u: any) => u.teams.map((t: any) => t.name).join(', ') || '—' },
          { key: 'status', label: 'Status', render: (u: any) => <Badge value={u.status === 'active' ? 'active' : 'revoked'} label={u.status} /> },
          { key: 'last_login_at', label: 'Last sign-in', render: (u: any) => fmtDate(u.last_login_at) },
          { key: 'actions', label: '', render: (u: any) => can('employees.manage') && (
            <button className="secondary" disabled={a.busy} onClick={() => a.run(async () => { await patch(`/employees/${u.id}`, { status: u.status === 'active' ? 'suspended' : 'active' }); await emps.reload(); })}>
              {u.status === 'active' ? 'Suspend' : 'Reactivate'}
            </button>) },
        ]} />
      </Card>
      <Card title="Teams">
        <Table rows={teams.data} columns={[{ key: 'code', label: 'Code' }, { key: 'name', label: 'Name' }, { key: 'users_count', label: 'Members', align: 'right' },
          { key: 'm', label: '', render: (t: any) => can('employees.manage') && <button className="secondary" onClick={() => setTeamModal(t)}>Members</button> }]} />
      </Card>
      {creating && <CreateEmployee teams={teams.data ?? []} onClose={() => setCreating(false)} onDone={() => { setCreating(false); void emps.reload(); }} />}
      {teamModal && <TeamModal team={teamModal} employees={emps.data?.data ?? []} onClose={() => setTeamModal(null)} onDone={() => { setTeamModal(null); void teams.reload(); void emps.reload(); }} />}
    </Page>
  );
}

function CreateEmployee({ teams, onClose, onDone }: { teams: any[]; onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ employee_code: '', name: '', email: '', phone: '', password: '', roles: ['employee'], team_ids: [] as number[] });
  const a = useAction();
  return (
    <Modal title="Add employee" onClose={onClose}>
      <ErrorBox error={a.error} />
      <div className="form-grid">
        <Field label="User ID (typed on the phone)"><input value={f.employee_code} onChange={(e) => setF({ ...f, employee_code: e.target.value })} /></Field>
        <Field label="Name"><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Email (admins only)"><input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Work phone number" hint="Called first in callback calling mode"><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
        <Field label="Initial password" hint="Min 10 chars, letters and numbers"><input type="password" autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
        <Field label="Role">
          <select value={f.roles[0]} onChange={(e) => setF({ ...f, roles: [e.target.value] })}>{ROLE_KEYS.map((r) => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}</select>
        </Field>
        <Field label="Team">
          <select value={f.team_ids[0] ?? ''} onChange={(e) => setF({ ...f, team_ids: e.target.value ? [Number(e.target.value)] : [] })}>
            <option value="">— none —</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </Field>
      </div>
      <button disabled={a.busy} onClick={() => a.run(async () => { await post('/employees', { ...f, email: f.email || null, phone: f.phone || null }); onDone(); })}>Create</button>
    </Modal>
  );
}

function TeamModal({ team, employees, onClose, onDone }: { team: any; employees: any[]; onClose: () => void; onDone: () => void }) {
  const isNew = !team.id;
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [members, setMembers] = useState<Record<number, string>>(() =>
    Object.fromEntries(employees.filter((e) => e.teams.some((t: any) => t.id === team.id)).map((e) => [e.id, 'member'])));
  const a = useAction();
  return (
    <Modal title={isNew ? 'Add team' : `Members of ${team.name}`} onClose={onClose}>
      <ErrorBox error={a.error} />
      {isNew ? (
        <>
          <Field label="Code"><input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
          <Field label="Name"><input value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <button disabled={a.busy} onClick={() => a.run(async () => { await post('/teams', { code, name }); onDone(); })}>Create team</button>
        </>
      ) : (
        <>
          <Table rows={employees} columns={[{ key: 'name', label: 'Employee' }, { key: 'm', label: 'Membership', render: (e: any) => (
            <select value={members[e.id] ?? ''} onChange={(ev) => setMembers((m) => { const n = { ...m }; if (ev.target.value) n[e.id] = ev.target.value; else delete n[e.id]; return n; })}>
              <option value="">Not a member</option><option value="member">Member</option><option value="supervisor">Supervisor</option>
            </select>) }]} />
          <button disabled={a.busy} onClick={() => a.run(async () => { await put(`/teams/${team.id}/members`, { members: Object.entries(members).map(([user_id, membership]) => ({ user_id: Number(user_id), membership })) }); onDone(); })}>Save members</button>
        </>
      )}
    </Modal>
  );
}
