import { Link } from 'react-router-dom';
import { get, fmtSeconds } from '../lib/api';
import { Card, ErrorBox, Notice, Page, Stat, useAsync } from '../components/ui';

export function OverviewPage() {
  const { data, error, reload } = useAsync(() => get('/overview'));
  return (
    <Page title="Overview" subtitle="Live counts from the server. Signed-in does not mean actively working." actions={<button className="secondary" onClick={reload}>Refresh</button>}>
      <ErrorBox error={error} />
      {data && (
        <>
          {data.devices.pending > 0 && <Notice tone="warn">{data.devices.pending} phone(s) waiting for approval. <Link to="/devices">Review requests</Link></Notice>}
          {data.recordings_failed_7d > 0 && <Notice tone="bad">{data.recordings_failed_7d} recording(s) failed in the last 7 days. <Link to="/calls?recording_status=failed">Review</Link></Notice>}
          <Card title="Devices">
            <div className="grid">
              <Stat label="Approved" value={data.devices.approved} />
              <Stat label="Online now" value={data.devices.online} />
              <Stat label="On a call" value={data.devices.on_call} />
              <Stat label="Pending approval" value={data.devices.pending} tone={data.devices.pending ? 'warn' : ''} />
              <Stat label="Not compliant" value={data.devices.non_compliant} tone={data.devices.non_compliant ? 'bad' : ''} />
            </div>
          </Card>
          <Card title="Calls today">
            <div className="grid">
              <Stat label="Calls placed" value={data.calls_today.total} />
              <Stat label="Answered" value={data.calls_today.answered} />
              <Stat label="Talk time" value={fmtSeconds(data.calls_today.talk_seconds)} />
            </div>
          </Card>
        </>
      )}
    </Page>
  );
}
