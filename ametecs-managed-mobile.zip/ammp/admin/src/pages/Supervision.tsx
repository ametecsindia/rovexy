import { useEffect, useRef, useState } from 'react';
import { api, get, post, fmtDate, qs } from '../lib/api';
import { useAuth } from '../lib/auth';
import { realtime } from '../lib/realtime';
import { Badge, Card, ErrorBox, Field, Notice, Page, Table, useAction, useAsync } from '../components/ui';

export function LocationPage() {
  const { me } = useAuth();
  const presence = useAsync(() => get<any[]>('/presence'));
  const [userId, setUserId] = useState('');
  const [day, setDay] = useState(() => new Date().toISOString().slice(0, 10));
  const fixes = useAsync(() => (userId ? get<any[]>(`/locations${qs({ user_id: userId, from: `${day}T00:00:00`, to: `${day}T23:59:59` })}`) : Promise.resolve([])), [userId, day]);
  return (
    <Page title="Employee status & location" subtitle="Location is collected only during work sessions, as configured by policy. Every view is audited.">
      <ErrorBox error={presence.error ?? fixes.error} />
      <Card title="Status (observed signals only)">
        <Table rows={presence.data} columns={[{ key: 'u', label: 'Employee', render: (d: any) => d.assigned_user?.name ?? '—' }, { key: 'asset_tag', label: 'Device' },
          { key: 'presence', label: 'Connection', render: (d: any) => <Badge value={d.presence} /> }, { key: 'work_state', label: 'In-app state', render: (d: any) => <Badge value={d.work_state} /> },
          { key: 'battery_pct', label: 'Battery', align: 'right', render: (d: any) => (d.battery_pct ?? '—') + (d.battery_pct != null ? '%' : '') }, { key: 'network_type', label: 'Network' },
          { key: 'compliant', label: 'Policy', render: (d: any) => <Badge value={d.compliant} label={d.compliant ? 'compliant' : 'not compliant'} /> },
          { key: 'last_contact_at', label: 'Last contact', render: (d: any) => fmtDate(d.last_contact_at, me?.company.timezone) },
          { key: 'v', label: '', render: (d: any) => <button className="secondary" onClick={() => setUserId(String(d.assigned_user_id))}>Locations</button> }]} />
      </Card>
      {userId && (
        <Card title="Location fixes" actions={<input type="date" value={day} onChange={(e) => setDay(e.target.value)} aria-label="Day" />}>
          <Table rows={fixes.data?.map((f, i) => ({ ...f, id: i }))} empty="No fixes for this day (location may be disabled, denied or the device offline)." columns={[
            { key: 'captured_at', label: 'Captured', render: (f: any) => fmtDate(f.captured_at, me?.company.timezone) },
            { key: 'pos', label: 'Position', render: (f: any) => <a href={`https://www.openstreetmap.org/?mlat=${f.lat}&mlon=${f.lng}#map=17/${f.lat}/${f.lng}`} target="_blank" rel="noreferrer noopener">{Number(f.lat).toFixed(5)}, {Number(f.lng).toFixed(5)}</a> },
            { key: 'accuracy_m', label: 'Accuracy', align: 'right', render: (f: any) => (f.accuracy_m != null ? `±${Math.round(f.accuracy_m)} m` : '—') },
            { key: 'stale', label: '', render: (f: any) => (f.stale ? <Badge value="expired" label="stale" /> : null) },
          ]} />
        </Card>
      )}
    </Page>
  );
}

export function MediaPage({ kind }: { kind: 'screen' | 'camera' }) {
  const { me } = useAuth();
  const presence = useAsync(() => get<any[]>('/presence'));
  const sessions = useAsync(() => get('/media-sessions'));
  const [deviceId, setDeviceId] = useState('');
  const [purpose, setPurpose] = useState('');
  const [active, setActive] = useState<any | null>(null);
  const a = useAction();
  const echo = me ? realtime(me) : null;

  useEffect(() => {
    if (!echo || !me) return;
    const name = `company.${me.company.id}.admin`;
    echo.private(name).listen('.feed', (e: any) => { if (e.type === 'media.updated') void sessions.reload(); });
    return () => echo.leave(name);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [echo, me]);
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => void sessions.reload(), 4000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);
  const current = active ? sessions.data?.data.find((s: any) => s.uuid === active.uuid) ?? active : null;

  return (
    <Page title={kind === 'screen' ? 'Live screen sessions' : 'Camera session requests'}
      subtitle={kind === 'screen'
        ? 'The employee must accept and then approve Android’s screen-capture prompt. A visible indicator is shown on the phone. Sessions are not recorded.'
        : 'The employee must accept and grant camera permission. The camera preview and an indicator are visible on the phone. Either side can stop.'}>
      <ErrorBox error={a.error ?? sessions.error} />
      {!echo && <Notice tone="warn">Live media needs the WebSocket service (Reverb). It is not configured, so sessions can be requested but video cannot be connected.</Notice>}
      <Card title="Request a session">
        <div className="form-grid">
          <Field label="Employee device">
            <select value={deviceId} onChange={(e) => setDeviceId(e.target.value)}><option value="">Select…</option>
              {(presence.data ?? []).filter((d) => d.work_state !== 'signed_out').map((d) => <option key={d.id} value={d.id}>{d.assigned_user?.name} · {d.asset_tag ?? `#${d.id}`}</option>)}</select>
          </Field>
          <Field label="Purpose (shown to the employee and audited)"><input value={purpose} onChange={(e) => setPurpose(e.target.value)} /></Field>
        </div>
        <button disabled={a.busy || !deviceId || purpose.length < 5} onClick={() => a.run(async () => { setActive(await post('/media-sessions', { device_id: Number(deviceId), kind, purpose })); await sessions.reload(); })}>Send request</button>
      </Card>
      {current && <Viewer session={current} kind={kind} onEnd={() => { setActive(null); void sessions.reload(); }} />}
      <Card title="Session log">
        <Table rows={sessions.data?.data.filter((s: any) => s.kind === kind)} columns={[{ key: 'requested_at', label: 'Requested', render: (s: any) => fmtDate(s.requested_at, me?.company.timezone) },
          { key: 'user_id', label: 'Employee #' }, { key: 'purpose', label: 'Purpose' }, { key: 'state', label: 'State', render: (s: any) => <Badge value={s.state} /> },
          { key: 'end_reason', label: 'End reason' }, { key: 'protected_content_reported', label: 'Protected content', render: (s: any) => (s.protected_content_reported ? 'Reported' : '—') },
          { key: 'o', label: '', render: (s: any) => ['accepted', 'active', 'requested'].includes(s.state) ? <button className="secondary" onClick={() => setActive(s)}>Open</button> : null }]} />
      </Card>
    </Page>
  );
}

function Viewer({ session, kind, onEnd }: { session: any; kind: string; onEnd: () => void }) {
  const { me } = useAuth();
  const video = useRef<HTMLVideoElement>(null);
  const [status, setStatus] = useState('Waiting for the employee to accept…');
  const a = useAction();
  const ready = ['accepted', 'active'].includes(session.state);

  useEffect(() => {
    if (!ready || !me) return;
    const echo = realtime(me);
    if (!echo) return;
    let pc: RTCPeerConnection | null = null;
    const channel = `company.${me.company.id}.media.${session.uuid}`;
    const signal = (type: string, payload: unknown) => post(`/media-sessions/${session.uuid}/signal`, { type, payload });
    (async () => {
      const { ice_servers } = await get(`/media-sessions/${session.uuid}/ice`);
      pc = new RTCPeerConnection({ iceServers: ice_servers });
      pc.ontrack = (ev) => { if (video.current) video.current.srcObject = ev.streams[0]; setStatus('Connected'); };
      pc.onicecandidate = (ev) => { if (ev.candidate) void signal('candidate', ev.candidate.toJSON()); };
      pc.onconnectionstatechange = () => { if (pc && ['failed', 'disconnected'].includes(pc.connectionState)) setStatus(`Connection ${pc.connectionState}`); };
      echo.private(channel).listen('.signal', async (m: any) => {
        if (m.from !== 'device' || !pc) return;
        if (m.type === 'offer') {
          await pc.setRemoteDescription(m.payload);
          const ans = await pc.createAnswer();
          await pc.setLocalDescription(ans);
          await signal('answer', { type: ans.type, sdp: ans.sdp });
        } else if (m.type === 'candidate') await pc.addIceCandidate(m.payload).catch(() => undefined);
        else if (m.type === 'bye') setStatus('Ended by the employee');
      });
      setStatus('Waiting for the phone to start sharing…');
    })().catch((e) => setStatus(`Could not connect: ${e}`));
    return () => { pc?.close(); echo.leave(channel); };
  }, [ready, me, session.uuid]);

  const screenshot = () => a.run(async () => {
    const v = video.current!;
    const c = document.createElement('canvas');
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext('2d')!.drawImage(v, 0, 0);
    const blob: Blob = await new Promise((res) => c.toBlob((b) => res(b!), 'image/png'));
    const fd = new FormData();
    fd.append('image', blob, 'screenshot.png');
    await api('POST', `/media-sessions/${session.uuid}/screenshots`, fd);
  });

  return (
    <Card title={`${kind === 'screen' ? 'Screen' : 'Camera'} session`} actions={<><Badge value={session.state} />
      {kind === 'screen' && session.options?.screenshots && session.state === 'active' && <button className="secondary" disabled={a.busy} onClick={screenshot}>Take screenshot</button>}
      <button className="danger" onClick={() => a.run(async () => { await post(`/media-sessions/${session.uuid}/end`); onEnd(); })}>End session</button></>}>
      <ErrorBox error={a.error} />
      {['declined', 'expired', 'ended'].includes(session.state) ? <Notice tone="info">Session {session.state}{session.end_reason ? ` (${session.end_reason.replace(/_/g, ' ')})` : ''}.</Notice> : <p className="muted">{status}</p>}
      {session.protected_content_reported && <Notice tone="warn">The phone reported protected content that cannot be captured (it appears black).</Notice>}
      <video ref={video} autoPlay playsInline muted />
    </Card>
  );
}

export function ChatPage() {
  const { me } = useAuth();
  const convs = useAsync(() => get<any[]>('/conversations'));
  const emps = useAsync(() => get('/employees'));
  const [open, setOpen] = useState<number | null>(null);
  const [newWith, setNewWith] = useState('');
  const a = useAction();
  return (
    <Page title="Employee chat" subtitle="Server-timestamped, with delivery and read status. Attachments are type- and size-checked on the server.">
      <ErrorBox error={convs.error ?? a.error} />
      <div className="chat">
        <Card title="Conversations">
          <div className="row" style={{ marginBottom: 8 }}>
            <select value={newWith} onChange={(e) => setNewWith(e.target.value)} aria-label="Start chat with"><option value="">New chat with…</option>{(emps.data?.data ?? []).filter((e: any) => e.id !== me?.id).map((e: any) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
            <button disabled={!newWith || a.busy} onClick={() => a.run(async () => { const c = await post('/conversations', { user_id: Number(newWith) }); await convs.reload(); setOpen(c.id); })}>Start</button>
          </div>
          {(convs.data ?? []).map((c) => (
            <button key={c.id} className={open === c.id ? '' : 'secondary'} style={{ width: '100%', marginBottom: 6, textAlign: 'left' }} onClick={() => setOpen(c.id)}>
              {c.participants.filter((p: any) => p.id !== me?.id).map((p: any) => p.name).join(', ')}
            </button>
          ))}
        </Card>
        {open ? <Thread id={open} /> : <Card><p className="muted">Select a conversation.</p></Card>}
      </div>
    </Page>
  );
}

function Thread({ id }: { id: number }) {
  const { me } = useAuth();
  const [msgs, setMsgs] = useState<any[]>([]);
  const [text, setText] = useState('');
  const a = useAction();
  const load = async () => {
    const after = msgs.length ? msgs[msgs.length - 1].id : 0;
    const more = await get<any[]>(`/conversations/${id}/messages?after=${after}`);
    if (more.length) setMsgs((m) => [...m, ...more]);
  };
  useEffect(() => {
    setMsgs([]);
    const echo = me ? realtime(me) : null;
    const name = `company.${me?.company.id}.conversation.${id}`;
    echo?.private(name).listen('.conversation', () => void load());
    const t = setInterval(() => void load(), echo ? 30000 : 5000); // polling fallback
    void load();
    return () => { clearInterval(t); echo?.leave(name); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  return (
    <Card title="Messages">
      <ErrorBox error={a.error} />
      <div className="msgs" aria-live="polite">
        {msgs.map((m) => (
          <div key={m.id} className={`msg ${m.sender_user_id === me?.id ? 'mine' : ''}`}>
            {m.body}{m.attachment && <div className="muted">📎 {m.attachment.name}</div>}
            <div><small className="muted">{fmtDate(m.created_at, me?.company.timezone)} {m.sender_user_id === me?.id && (m.read ? '· read' : m.delivered ? '· delivered' : '· sent')}</small></div>
          </div>
        ))}
      </div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); void a.run(async () => { await post(`/conversations/${id}/messages`, { body: text }); setText(''); await load(); }); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" style={{ flex: 1 }} aria-label="Message" />
        <button disabled={!text.trim() || a.busy}>Send</button>
      </form>
    </Card>
  );
}
