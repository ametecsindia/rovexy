import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { ApiError } from '../lib/api';

export function useAsync<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await fn());
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    void reload();
  }, [reload]);
  return { data, error, loading, reload, setData };
}

/** Wraps a mutating action: disables the button, shows the server's message on failure. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : String(e));
      return undefined;
    } finally {
      setBusy(false);
    }
  };
  return { busy, error, run, setError };
}

export function Page({ title, actions, children, subtitle }: { title: string; subtitle?: string; actions?: ReactNode; children: ReactNode }) {
  return (
    <section className="page">
      <header className="page-head">
        <div>
          <h1>{title}</h1>
          {subtitle && <p className="muted">{subtitle}</p>}
        </div>
        <div className="row">{actions}</div>
      </header>
      {children}
    </section>
  );
}

export function Card({ title, children, actions }: { title?: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <div className="card">
      {(title || actions) && (
        <div className="card-head">
          {title && <h2>{title}</h2>}
          <div className="row">{actions}</div>
        </div>
      )}
      {children}
    </div>
  );
}

const TONES: Record<string, string> = {
  approved: 'ok', applied: 'ok', available: 'ok', completed: 'ok', online: 'ok', active: 'ok', supported: 'ok', true: 'ok', ready: 'ok', published: 'ok',
  pending: 'warn', applying: 'warn', processing: 'warn', recording: 'warn', requested: 'warn', accepted: 'warn', validating: 'warn', committing: 'warn',
  partially_applied: 'warn', requires_setup: 'warn', planned: 'warn', draft: 'warn', on_call: 'info', updating_customer: 'info', idle: 'muted',
  rejected: 'bad', revoked: 'bad', failed: 'bad', unsupported: 'bad', false: 'bad', offline: 'muted', expired: 'muted', ended: 'muted',
  signed_out: 'muted', not_required: 'muted', deleted_by_retention: 'muted', superseded: 'muted', busy: 'warn', no_answer: 'warn', agent_unanswered: 'warn',
  disconnected: 'warn', cancelled: 'muted', declined: 'muted',
};

export function Badge({ value, label }: { value: string | boolean | null | undefined; label?: string }) {
  const v = String(value ?? '—');
  return <span className={`badge ${TONES[v] ?? 'muted'}`}>{label ?? v.replace(/_/g, ' ')}</span>;
}

export function ErrorBox({ error }: { error: string | null | undefined }) {
  return error ? <div className="alert bad" role="alert">{error}</div> : null;
}

export function Notice({ tone = 'info', children }: { tone?: 'info' | 'warn' | 'bad' | 'ok'; children: ReactNode }) {
  return <div className={`alert ${tone}`}>{children}</div>;
}

export type Column<T> = { key: string; label: string; render?: (row: T) => ReactNode; align?: 'right' };

export function Table<T extends { id?: number | string }>({ rows, columns, empty = 'Nothing to show.', onRow }: { rows: T[] | undefined | null; columns: Column<T>[]; empty?: string; onRow?: (r: T) => void }) {
  if (!rows) return <p className="muted">Loading…</p>;
  if (rows.length === 0) return <p className="muted">{empty}</p>;
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>{columns.map((c) => <th key={c.key} className={c.align === 'right' ? 'num' : undefined}>{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={(r.id as any) ?? i} onClick={onRow ? () => onRow(r) : undefined} className={onRow ? 'clickable' : undefined}>
              {columns.map((c) => (
                <td key={c.key} className={c.align === 'right' ? 'num' : undefined}>{c.render ? c.render(r) : String((r as any)[c.key] ?? '—')}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={title} onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="card-head">
          <h2>{title}</h2>
          <button className="ghost" onClick={onClose} aria-label="Close">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <small className="muted">{hint}</small>}
    </label>
  );
}

export function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: string }) {
  return (
    <div className={`stat ${tone ?? ''}`}>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

/** Neutral placeholder used until an official logo is uploaded. Deliberately generic: no invented brand mark. */
export function LogoPlaceholder({ name, size = 40 }: { name: string; size?: number }) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join('') || '··';
  return (
    <div className="logo-ph" style={{ width: size, height: size, fontSize: size * 0.38 }} aria-label="Logo placeholder" title="No logo uploaded">
      {initials}
    </div>
  );
}
