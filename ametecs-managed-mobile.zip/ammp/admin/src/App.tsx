import { NavLink, Navigate, Route, Routes } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useAuth } from './lib/auth';
import { get, post } from './lib/api';
import { disconnectRealtime } from './lib/realtime';
import { LogoPlaceholder } from './components/ui';
import { LoginPage } from './pages/Login';
import { OverviewPage } from './pages/Overview';
import { EmployeesPage } from './pages/Employees';
import { DevicesPage } from './pages/Devices';
import { PoliciesPage } from './pages/Policies';
import { ImportsPage, CustomersPage } from './pages/Customers';
import { CallingConfigPage, CallsPage, FollowUpsPage } from './pages/Calls';
import { LocationPage, MediaPage, ChatPage } from './pages/Supervision';
import { AuditPage, BrandingPage, HealthPage, ReportsPage, RetentionPage } from './pages/Settings';

type NavItem = { to: string; label: string; perm?: string; group: string };
export const NAV: NavItem[] = [
  { to: '/', label: 'Overview', group: 'Operations' },
  { to: '/employees', label: 'Employees & teams', perm: 'employees.view', group: 'Operations' },
  { to: '/devices', label: 'Devices & approvals', perm: 'devices.view', group: 'Devices' },
  { to: '/policies', label: 'Policy profiles', perm: 'policies.view', group: 'Devices' },
  { to: '/imports', label: 'Customer imports', perm: 'customers.import', group: 'Customers' },
  { to: '/customers', label: 'Customers & assignment', perm: 'customers.view', group: 'Customers' },
  { to: '/calling', label: 'Calling configuration', perm: 'telephony.configure', group: 'Calling' },
  { to: '/calls', label: 'Calls & recordings', perm: 'calls.view', group: 'Calling' },
  { to: '/follow-ups', label: 'Follow-ups & dispositions', perm: 'calls.view', group: 'Calling' },
  { to: '/location', label: 'Employee location', perm: 'location.view', group: 'Supervision' },
  { to: '/screen', label: 'Live screen sessions', perm: 'media.screen', group: 'Supervision' },
  { to: '/camera', label: 'Camera session requests', perm: 'media.camera', group: 'Supervision' },
  { to: '/chat', label: 'Employee chat', perm: 'chat.use', group: 'Supervision' },
  { to: '/reports', label: 'Reports & exports', perm: 'reports.export', group: 'Administration' },
  { to: '/branding', label: 'Company branding', perm: 'branding.manage', group: 'Administration' },
  { to: '/retention', label: 'Storage & retention', perm: 'settings.storage', group: 'Administration' },
  { to: '/audit', label: 'Audit logs', perm: 'audit.view', group: 'Administration' },
  { to: '/health', label: 'System health', perm: 'system.health', group: 'Administration' },
];

export function App() {
  const { me, loading, can, setMe } = useAuth();
  const [branding, setBranding] = useState<{ display_name: string; logo_url: string | null } | null>(null);
  useEffect(() => {
    if (me) get('/branding').then(setBranding).catch(() => setBranding(null));
  }, [me]);
  if (loading) return <p className="muted" style={{ padding: 24 }}>Loading…</p>;
  if (!me) return <LoginPage />;

  const logout = async () => {
    await post('/auth/logout').catch(() => undefined);
    disconnectRealtime();
    setMe(null);
  };
  const items = NAV.filter((n) => !n.perm || can(n.perm));
  const groups = [...new Set(items.map((i) => i.group))];
  const name = branding?.display_name ?? me.company.name;
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          {branding?.logo_url ? <img src={branding.logo_url} alt={`${name} logo`} /> : <LogoPlaceholder name={name} />}
          <span>{name}</span>
        </div>
        <nav className="nav" aria-label="Modules">
          {groups.map((g) => (
            <div key={g}>
              <div className="group">{g}</div>
              {items.filter((i) => i.group === g).map((i) => (
                <NavLink key={i.to} to={i.to} end={i.to === '/'}>{i.label}</NavLink>
              ))}
            </div>
          ))}
        </nav>
      </aside>
      <main className="main">
        <div className="topbar">
          <span className="muted">{me.product_name} · {me.name}</span>
          <button className="secondary" onClick={logout}>Sign out</button>
        </div>
        <Routes>
          <Route path="/" element={<OverviewPage />} />
          <Route path="/employees" element={<EmployeesPage />} />
          <Route path="/devices" element={<DevicesPage />} />
          <Route path="/policies" element={<PoliciesPage />} />
          <Route path="/imports" element={<ImportsPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/calling" element={<CallingConfigPage />} />
          <Route path="/calls" element={<CallsPage />} />
          <Route path="/follow-ups" element={<FollowUpsPage />} />
          <Route path="/location" element={<LocationPage />} />
          <Route path="/screen" element={<MediaPage kind="screen" />} />
          <Route path="/camera" element={<MediaPage kind="camera" />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/branding" element={<BrandingPage />} />
          <Route path="/retention" element={<RetentionPage />} />
          <Route path="/audit" element={<AuditPage />} />
          <Route path="/health" element={<HealthPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
