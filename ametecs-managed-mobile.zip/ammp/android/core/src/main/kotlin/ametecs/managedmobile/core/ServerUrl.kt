package ametecs.managedmobile.core

import java.net.URI

/** Server URLs must be https (no credentials, query or fragment). Returns the scheme://host[:port] origin. */
object ServerUrl {
    fun normalise(input: String, allowLocalHttpForDebug: Boolean = false): String {
        val trimmed = input.trim().let { if (!it.contains("://")) "https://$it" else it }
        val uri = try { URI(trimmed) } catch (e: Exception) { throw IllegalArgumentException("Enter a valid server address") }
        val host = uri.host ?: throw IllegalArgumentException("Enter a valid server address")
        val local = host == "localhost" || host == "127.0.0.1" || host == "10.0.2.2"
        if (uri.scheme != "https" && !(allowLocalHttpForDebug && local && uri.scheme == "http")) {
            throw IllegalArgumentException("The server must use https://")
        }
        if (uri.userInfo != null) throw IllegalArgumentException("Do not include credentials in the address")
        if (uri.query != null || uri.fragment != null) throw IllegalArgumentException("Remove ?… or #… from the address")
        return uri.scheme + "://" + host.toLowerCase() + (if (uri.port != -1) ":" + uri.port else "")
    }
}
