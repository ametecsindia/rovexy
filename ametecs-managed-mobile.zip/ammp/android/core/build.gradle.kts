// Pure Kotlin/JVM logic shared by the app; unit-tested without an Android device.
plugins { alias(libs.plugins.kotlin.jvm) }
kotlin { jvmToolchain(17) }
dependencies { testImplementation(libs.junit) }
