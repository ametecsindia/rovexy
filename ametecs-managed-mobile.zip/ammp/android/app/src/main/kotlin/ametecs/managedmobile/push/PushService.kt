package ametecs.managedmobile.push

import ametecs.managedmobile.AmmpApp
import ametecs.managedmobile.work.SyncWorker
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * FCM is only a wake-up hint. Payloads carry {type:"sync", reason} — no customer data — and never a URL.
 * The app then pulls state over authenticated HTTPS.
 */
class PushService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        if (message.data["type"] == "sync") {
            SyncWorker.syncNow(applicationContext)
            (application as AmmpApp).graph.onPush(message.data["reason"])
        }
    }

    override fun onNewToken(token: String) {
        val g = (application as AmmpApp).graph
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { g.session.device("PUT", "/api/mobile/v1/device/push-token", buildJsonObject { put("token", token); put("provider", "fcm") }) }
        }
    }
}
