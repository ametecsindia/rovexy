package ametecs.managedmobile.media

import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import ametecs.managedmobile.core.MediaRequestGate
import ametecs.managedmobile.data.SessionManager
import ametecs.managedmobile.data.obj
import ametecs.managedmobile.data.str
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.webrtc.PeerConnection
import java.time.OffsetDateTime

data class MediaRequest(val id: String, val kind: String, val purpose: String, val requestedBy: String, val requestedAtMs: Long, val state: String)

/**
 * Employee-side flow: show request → employee accepts/declines → OS consent → visible foreground session.
 * Refuses to accept when notifications are disabled, because the persistent notification is part of the
 * "always visible" guarantee.
 */
class MediaCoordinator(private val context: Context, private val session: SessionManager) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, _ -> })
    private val _pending = MutableStateFlow<MediaRequest?>(null)
    val pending: StateFlow<MediaRequest?> = _pending
    private val _active = MutableStateFlow<WebRtcSession?>(null)
    val active: StateFlow<WebRtcSession?> = _active
    /** Kind ("screen"/"camera") whose OS consent the Activity must launch now (collected on the main thread). */
    private val _consentNeeded = MutableStateFlow<String?>(null)
    val consentNeeded: StateFlow<String?> = _consentNeeded
    val lastError = MutableStateFlow<String?>(null)
    @Volatile private var accepted: MediaRequest? = null
    @Volatile private var cancelledId: String? = null
    private val outbound = Channel<Pair<String, JsonObject>>(Channel.UNLIMITED)

    init {
        // One consumer keeps signalling in order (offer before candidates).
        scope.launch { for ((id, body) in outbound) runCatching { session.work("POST", "/api/mobile/v1/media/$id/signal", body) } }
    }

    /** Polled on sync / triggered by WebSocket/push. Expired or stale requests are dropped, never executed. */
    fun refresh() = scope.launch {
        val now = System.currentTimeMillis()
        _pending.value = runCatching {
            session.work("GET", "/api/mobile/v1/media/pending").jsonArray.map { it.jsonObject }.map {
                MediaRequest(it.str("uuid")!!, it.str("kind")!!, it.str("purpose") ?: "", it.str("requested_by_name") ?: "Supervisor",
                    OffsetDateTime.parse(it.str("requested_at")!!).toInstant().toEpochMilli(), it.str("state")!!)
            }.firstOrNull { MediaRequestGate.canPrompt(it.state, it.requestedAtMs, now) }
        }.getOrNull()
    }

    fun decline(r: MediaRequest) = scope.launch {
        runCatching { session.work("POST", "/api/mobile/v1/media/${r.id}/decline") }
        _pending.value = null
    }

    fun accept(r: MediaRequest) = scope.launch {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            lastError.value = "Turn on notifications for this app first: an indicator must stay visible during sharing."
            return@launch
        }
        runCatching { session.work("POST", "/api/mobile/v1/media/${r.id}/accept") }.onSuccess {
            accepted = r
            cancelledId = null
            _pending.value = null
            _consentNeeded.value = r.kind
        }.onFailure { lastError.value = it.message }
    }

    fun consentLaunched() { _consentNeeded.value = null }

    fun osConsentDenied() = scope.launch {
        accepted?.let { runCatching { session.work("POST", "/api/mobile/v1/media/${it.id}/end", buildJsonObject { put("reason", "os_consent_denied") }) } }
        accepted = null
    }

    fun startScreen(projection: Intent) = ScreenShareService.start(context, projection)
    fun startCamera() = CameraSessionService.start(context)

    /** Called by the visible foreground service once it is in the foreground. */
    fun onForegroundReady(kind: String, projection: Intent?) {
        val r = accepted ?: return
        scope.launch {
            try {
                val ice = session.work("GET", "/api/mobile/v1/media/${r.id}/ice").obj()["ice_servers"]!!.jsonArray.map { s ->
                    val o = s.jsonObject
                    val urls = o["urls"]!!.jsonArray.map { it.jsonPrimitive.content }
                    PeerConnection.IceServer.builder(urls).apply { o.str("username")?.let { setUsername(it) }; o.str("credential")?.let { setPassword(it) } }.createIceServer()
                }
                if (cancelledId == r.id) { finish(r.id, "employee_stopped"); return@launch }   // Stop tapped while connecting
                if (kind == "screen" && projection == null) { finish(r.id, "os_consent_denied"); return@launch }
                val s = WebRtcSession(context, r.id, kind, ice,
                    sendSignal = { type, payload -> outbound.trySend(r.id to buildJsonObject { put("type", type); put("payload", toJson(payload)) }) },
                    onEnded = { reason -> scope.launch { finish(r.id, reason) } })
                session.work("POST", "/api/mobile/v1/media/${r.id}/start")
                s.start(projection, 1280, 720, 5)
                _active.value = s
            } catch (e: Exception) {
                finish(r.id, "connection_failed")
            }
        }
    }

    fun onRemoteSignal(data: JsonObject) {
        val s = _active.value ?: return
        if (data.str("session_id") != s.sessionId) return
        @Suppress("UNCHECKED_CAST")
        runCatching { s.onRemoteSignal(data.str("type")!!, fromJson(data["payload"]!!) as Map<String, Any?>) }
    }

    fun onRemoteState(data: JsonObject) {
        val s = _active.value
        if (s != null && data.str("session_id") == s.sessionId && data.str("state") in setOf("ended", "expired")) s.end("supervisor_stopped")
        if (s == null && accepted?.id == data.str("session_id") && data.str("state") in setOf("ended", "expired")) cancelledId = accepted?.id
    }

    fun endActive(reason: String) {
        val s = _active.value
        if (s != null) s.end(reason) else accepted?.let { cancelledId = it.id }
    }

    private suspend fun finish(id: String, reason: String) {
        if (reason in setOf("employee_stopped", "connection_failed", "os_consent_denied")) {
            runCatching { session.work("POST", "/api/mobile/v1/media/$id/end", buildJsonObject { put("reason", reason) }) }
        }
        _active.value = null
        accepted = null
        context.stopService(Intent(context, ScreenShareService::class.java))
        context.stopService(Intent(context, CameraSessionService::class.java))
    }

    private fun toJson(v: Any?): JsonElement = when (v) {
        null -> JsonNull
        is Map<*, *> -> JsonObject(v.entries.associate { it.key.toString() to toJson(it.value) })
        is Number -> JsonPrimitive(v)
        is Boolean -> JsonPrimitive(v)
        else -> JsonPrimitive(v.toString())
    }

    private fun fromJson(e: JsonElement): Any? = when (e) {
        is JsonNull -> null
        is JsonObject -> e.mapValues { fromJson(it.value) }
        is JsonPrimitive -> if (e.isString) e.content else e.content.toIntOrNull() ?: e.content
        else -> null
    }
}
