package ametecs.managedmobile.work

import android.Manifest
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ServiceCompat
import ametecs.managedmobile.AmmpApp
import ametecs.managedmobile.R
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Work-session location. Runs ONLY between sign-in and sign-out, as a foreground service with a persistent,
 * visible notification. Fixes go to the encrypted queue (idempotent upload). Handles denied permission by stopping.
 */
class LocationService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            val g = (application as AmmpApp).graph
            for (l in r.locations) scope.launch {
                g.work.enqueue("location", buildJsonObject {
                    put("lat", l.latitude); put("lng", l.longitude); put("accuracy_m", l.accuracy.toDouble()); put("provider", l.provider ?: "fused")
                })
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n: Notification = Notification.Builder(this, AmmpApp.CHANNEL_WORK)
            .setSmallIcon(R.drawable.ic_app).setContentTitle("Work session active")
            .setContentText("Location is shared with your company while you are signed in.").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        // Must call startForeground before stopping (else Android crashes the app). Denied permission → stop cleanly.
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        val interval = (application as AmmpApp).graph.work.policy.int("location.interval_seconds", 300) * 1000L
        LocationServices.getFusedLocationProviderClient(this).requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, interval).setMinUpdateIntervalMillis(interval / 2).build(),
            callback, Looper.getMainLooper())
        return START_STICKY
    }

    override fun onDestroy() {
        LocationServices.getFusedLocationProviderClient(this).removeLocationUpdates(callback)
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            val granted = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (granted) ctx.startForegroundService(Intent(ctx, LocationService::class.java))
        }
        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, LocationService::class.java))
    }
}
