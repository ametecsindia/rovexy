package ametecs.managedmobile.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ametecs.managedmobile.core.CachedCustomer
import ametecs.managedmobile.media.MediaRequest

private fun color(hex: String) = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color(0xFF1F3A5F))

@Composable
fun AppRoot(vm: AppViewModel, requestScreenConsent: () -> Unit, requestCameraConsent: () -> Unit) {
    val screen by vm.screen.collectAsState()
    val pending by vm.pendingMedia.collectAsState()
    val active by vm.activeMedia.collectAsState()
    val consent by vm.consentNeeded.collectAsState()
    val mediaError by vm.mediaError.collectAsState()
    // OS consent is launched from the UI thread of the CURRENT activity, after the employee accepted in-app.
    LaunchedEffect(consent) {
        consent?.let { kind -> vm.consentLaunched(); if (kind == "screen") requestScreenConsent() else requestCameraConsent() }
    }
    Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FA))) {
        active?.let { MonitoringBanner(it.sessionId, onStop = vm::stopMedia) }   // always-visible indicator in-app
        mediaError?.let { Text(it, color = Color(0xFFB42318), modifier = Modifier.padding(8.dp)) }
        when (val s = screen) {
            Screen.Connect -> AuthLayout(vm, mode = "connect")
            is Screen.Pending -> PendingScreen(vm, s.code)
            is Screen.Ended -> EndedScreen(s.state, vm::startNewRegistration)
            Screen.Login -> AuthLayout(vm, mode = "login")
            is Screen.Policy -> PolicyScreen(s, vm::retryPolicy, vm::logout)
            Screen.Dashboard -> Dashboard(vm)
            is Screen.Locked -> CenterMessage("Locked", s.reason) { Button(onClick = vm::refresh) { Text("Retry") } }
        }
    }
    pending?.let { MediaRequestDialog(it, onAccept = vm::acceptMedia, onDecline = vm::declineMedia) }
}

/** The requested login layout: company logo, Server URL, User ID, Password, Sign In. Before approval: Connect/Register. */
@Composable
fun AuthLayout(vm: AppViewModel, mode: String) {
    val b by vm.branding.collectAsState()
    val busy by vm.busy.collectAsState()
    val err by vm.error.collectAsState()
    var server by remember { mutableStateOf(vm.serverUrl) }
    var workspace by remember { mutableStateOf(vm.workspace) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val locked = mode == "login" || vm.serverLocked
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Logo(b)
        Spacer(Modifier.height(8.dp))
        Text(b.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(server, { server = it }, label = { Text("Server URL") }, enabled = !locked, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        if (mode == "connect" && !locked) {
            OutlinedTextField(workspace, { workspace = it }, label = { Text("Company workspace (if given)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        if (mode == "login") {
            OutlinedTextField(user, { user = it }, label = { Text("User ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        }
        err?.let { Text(it, color = Color(0xFFB42318), modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (mode == "login") vm.login(user, pass) else vm.connect(server, workspace) }, enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = color(b.primary)), modifier = Modifier.fillMaxWidth().height(48.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White) else Text(if (mode == "login") "Sign In" else "Connect / Register")
        }
    }
}

/** Uploaded company logo, or a neutral placeholder. No brand mark is ever invented. */
@Composable
fun Logo(b: Branding) {
    if (b.logo != null) Image(b.logo.asImageBitmap(), contentDescription = "${b.name} logo", modifier = Modifier.height(72.dp))
    else Box(Modifier.size(72.dp).border(1.dp, Color(0xFF9AA7B4), RoundedCornerShape(12.dp)).background(Color(0xFFE3E8EF), RoundedCornerShape(12.dp))
        .semantics { contentDescription = "Logo placeholder" }, contentAlignment = Alignment.Center) {
        Text(b.name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }, color = Color(0xFF5D6B79), fontWeight = FontWeight.Bold, fontSize = 24.sp)
    }
}

@Composable
fun PendingScreen(vm: AppViewModel, code: String) {
    val b by vm.branding.collectAsState()
    CenterMessage("Waiting for administrator approval", "Read this code to your administrator. It only matches this phone to the request; it is not a password.") {
        Logo(b)
        Spacer(Modifier.height(16.dp))
        Text(code, fontFamily = FontFamily.Monospace, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(12.dp))
        CircularProgressIndicator()
    }
}

@Composable
fun EndedScreen(state: String, onNew: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    CenterMessage(if (state == "rejected") "Request rejected" else "Access revoked",
        "This phone can no longer access work data. Company device restrictions remain in place. Contact your IT administrator.") {
        OutlinedButton(onClick = { confirm = true }) { Text("Register again (administrator asked me to)") }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, confirmButton = { TextButton(onClick = { confirm = false; onNew() }) { Text("Start new registration") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }, title = { Text("New registration") },
        text = { Text("A new identity will be created and must be approved again.") })
}

@Composable
fun PolicyScreen(s: Screen.Policy, retry: () -> Unit, logout: () -> Unit) {
    CenterMessage("Device policy not yet applied", "Work features stay locked until all required company settings are applied and verified (state: ${s.state.replace('_', ' ')}).") {
        if (s.failing.isNotEmpty()) Text("Pending: " + s.failing.joinToString(", "), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Row { Button(onClick = retry) { Text("Check again") }; Spacer(Modifier.size(8.dp)); OutlinedButton(onClick = logout) { Text("Sign out") } }
    }
}

@Composable
fun Dashboard(vm: AppViewModel) {
    val customers by vm.customers.collectAsState()
    val status by vm.sync.collectAsState()
    val call by vm.call.collectAsState()
    val err by vm.error.collectAsState()
    val disclosure by vm.disclosure.collectAsState()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<CachedCustomer?>(null) }
    var showDisclosure by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("My customers", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                val age = status.lastSyncEpochMs?.let { (System.currentTimeMillis() - it) / 60000 }
                Text((if (status.online) "Online" else "Offline") + " · data " + (age?.let { "${it} min old" } ?: "not yet synced") +
                    (if (status.pendingEvents > 0) " · ${status.pendingEvents} update(s) waiting" else ""), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { showDisclosure = true }) { Text("Monitoring") }
            TextButton(onClick = vm::refresh) { Text("Sync") }
            TextButton(onClick = vm::logout) { Text("Sign out") }
        }
        err?.let { Text(it, color = Color(0xFFB42318)) }
        OutlinedTextField(query, { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyColumn(Modifier.weight(1f)) {
            items(customers.filter { query.isBlank() || it.name.contains(query, true) || it.ref.contains(query, true) }, key = { it.id }) { c ->
                Column(Modifier.fillMaxWidth().clickable { selected = c }.padding(vertical = 10.dp)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold)
                    Text("${c.ref} · ${c.status.replace('_', ' ')}", style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
            }
        }
    }
    selected?.let { c ->
        AlertDialog(onDismissRequest = { selected = null }, title = { Text(c.name) }, text = { Text("Customer ${c.ref}. Calls are placed through the company server; the number is not added to your contacts.") },
            confirmButton = { TextButton(onClick = { selected = null; vm.placeCall(c, "primary") }) { Text("Call primary") } },
            dismissButton = { if (c.altPhone != null) TextButton(onClick = { selected = null; vm.placeCall(c, "alternate") }) { Text("Call alternate") } })
    }
    call?.let { CallPanel(it, vm) }
    if (showDisclosure) disclosure?.let { d ->
        AlertDialog(onDismissRequest = { showDisclosure = false }, confirmButton = { TextButton(onClick = { showDisclosure = false }) { Text("OK") } }, title = { Text("What your company can see") },
            text = { Text(listOfNotNull(
                if (d.recorded) "Calls are recorded. ${d.notice}" else "Calls are not recorded.",
                d.location?.let { "Location: $it." } ?: "Location is not collected.",
                if (d.liveView) "Screen sharing can be requested; you must accept and Android will ask for permission each time." else null,
                if (d.camera) "Camera sessions can be requested; you must accept and the camera indicator is shown." else null,
                "Nothing is captured in the background or without your knowledge.").joinToString("\n\n")) })
    }
}

@Composable
fun CallPanel(c: CallUi, vm: AppViewModel) {
    val codes by vm.dispositions.collectAsState()
    val ended = c.state in AppViewModel.TERMINAL
    var code by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var followUp by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = {}, title = { Text(c.customer?.name ?: "Call") }, text = {
        Column {
            Text(when (c.state) {
                "initiated", "agent_ringing" -> if (c.agentLeg == "pstn_callback") "Your work phone will ring — answer it to be connected." else "Connecting…"
                "agent_connected", "ringing" -> "Ringing the customer…"
                "answered" -> "Connected · ${c.talk}s"
                else -> "Call ended: ${c.state.replace('_', ' ')}" + (if (c.talk > 0) " · talk ${c.talk}s" else "")
            })
            if (c.recording.isNotBlank() && c.recording != "not_required") Text("Recording: ${c.recording.replace('_', ' ')}", style = MaterialTheme.typography.bodySmall)
            if (ended) {
                Spacer(Modifier.height(8.dp))
                Text("Outcome", fontWeight = FontWeight.SemiBold)
                codes.forEach { (k, label) -> Row(Modifier.fillMaxWidth().clickable { code = k }.padding(4.dp)) { Text((if (code == k) "● " else "○ ") + label) } }
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(followUp, { followUp = it }, label = { Text("Follow-up (YYYY-MM-DD HH:MM)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }
    }, confirmButton = {
        if (ended) TextButton(enabled = code.isNotBlank(), onClick = {
            val iso = followUp.trim().takeIf { it.isNotEmpty() }?.let { runCatching { java.time.LocalDateTime.parse(it.replace(' ', 'T')).atZone(java.time.ZoneId.systemDefault()).toOffsetDateTime().toString() }.getOrNull() }
            vm.submitDisposition(code, notes, iso)
        }) { Text("Save outcome") }
        else TextButton(onClick = vm::hangup) { Text("Hang up") }
    })
}

@Composable
fun MediaRequestDialog(r: MediaRequest, onAccept: () -> Unit, onDecline: () -> Unit) {
    AlertDialog(onDismissRequest = onDecline, title = { Text(if (r.kind == "screen") "Screen sharing request" else "Camera session request") },
        text = { Text("${r.requestedBy} asks to see your ${if (r.kind == "screen") "screen" else "camera"}.\n\nPurpose: ${r.purpose}\n\nIf you accept, Android will also ask for permission. A notification and indicator stay visible while sharing, and you can stop at any time.") },
        confirmButton = { TextButton(onClick = onAccept) { Text("Accept") } }, dismissButton = { TextButton(onClick = onDecline) { Text("Decline") } })
}

@Composable
fun MonitoringBanner(sessionId: String, onStop: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFFB42318)).padding(horizontal = 12.dp, vertical = 8.dp).semantics { contentDescription = "Sharing active $sessionId" },
        verticalAlignment = Alignment.CenterVertically) {
        Text("● Sharing with your supervisor", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        TextButton(onClick = onStop) { Text("STOP", color = Color.White) }
    }
}

@Composable
fun CenterMessage(title: String, body: String, content: @Composable () -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.height(8.dp))
                Text(body, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))
                content()
            }
        }
    }
}
