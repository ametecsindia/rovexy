package ametecs.managedmobile

import android.Manifest
import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import ametecs.managedmobile.ui.AppRoot
import ametecs.managedmobile.ui.AppViewModel

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    // The OS MediaProjection consent dialog is always shown to the employee; it is never auto-approved.
    private val screenConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        vm.mediaConsent(if (r.resultCode == Activity.RESULT_OK) r.data else null, "screen")
    }
    private val cameraConsent = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.mediaConsent(if (granted) android.content.Intent() else null, "camera")   // non-null = permission granted
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        notifPermission.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        setContent {
            MaterialTheme {
                AppRoot(vm,
                    requestScreenConsent = { screenConsent.launch((getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent()) },
                    requestCameraConsent = { cameraConsent.launch(Manifest.permission.CAMERA) })
            }
        }
    }
}
