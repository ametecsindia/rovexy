package ametecs.managedmobile.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ametecs.managedmobile.AmmpApp
import ametecs.managedmobile.BuildConfig
import ametecs.managedmobile.core.Backoff
import ametecs.managedmobile.core.CachedCustomer
import ametecs.managedmobile.core.RequestSigning
import ametecs.managedmobile.data.ApiClient
import ametecs.managedmobile.data.ApiException
import ametecs.managedmobile.data.obj
import ametecs.managedmobile.data.str
import ametecs.managedmobile.work.LocationService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import java.io.File

sealed class Screen {
    object Connect : Screen()
    data class Pending(val code: String) : Screen()
    data class Ended(val state: String) : Screen()           // rejected | revoked
    object Login : Screen()
    data class Policy(val state: String, val failing: List<String>) : Screen()
    object Dashboard : Screen()
    data class Locked(val reason: String) : Screen()
}

data class Branding(val name: String, val primary: String, val logo: Bitmap?)
data class CallUi(val id: String, val state: String, val talk: Int, val ring: Int?, val recording: String, val agentLeg: String, val customer: CachedCustomer?, val error: String? = null)
data class Disclosure(val recorded: Boolean, val notice: String, val location: String?, val liveView: Boolean, val camera: Boolean)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val g = (app as AmmpApp).graph
    val screen = MutableStateFlow<Screen>(Screen.Connect)
    val branding = MutableStateFlow(Branding(BuildConfig.PRODUCT_NAME, "#1F3A5F", null))
    val busy = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val call = MutableStateFlow<CallUi?>(null)
    val disclosure = MutableStateFlow<Disclosure?>(null)
    val dispositions = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val customers: StateFlow<List<CachedCustomer>> = g.work.customers
    val sync = g.work.status
    val pendingMedia = g.media.pending
    val activeMedia = g.media.active
    val consentNeeded = g.media.consentNeeded
    val mediaError = g.media.lastError
    val serverLocked get() = g.config.isLocked(screen.value !is Screen.Connect)
    val serverUrl get() = g.config.serverOrigin.orEmpty()
    val workspace get() = g.config.workspace.orEmpty()
    private var poller: Job? = null

    init {
        g.session.onRevoked = { viewModelScope.launch { refreshStatus() } }
        g.session.onSignedOut = { viewModelScope.launch { screen.value = Screen.Login; stopWork() } }
        g.onServerEvent = { type, _ -> if (type == "session.revoked" || type == "session.ended" || type == "session.revalidate") viewModelScope.launch { refreshStatus() } }
        viewModelScope.launch { startup() }
    }

    private suspend fun startup() = runCatching { startupInner() }.onFailure { error.value = "Could not start: ${it.message}" }

    private suspend fun startupInner() {
        if (g.config.serverOrigin == null || g.store.getString("registered") == null) { screen.value = Screen.Connect; loadBranding(); return }
        loadBranding()
        refreshStatus()
    }

    /** Steps 3–8: verify server, fetch public branding, generate identity, register, show code. */
    fun connect(url: String, workspace: String) = act {
        if (!g.config.isLocked(false)) g.config.save(url, workspace)
        loadBranding(throwOnError = true)
        g.keys.ensureKey()
        val r = g.api.call("POST", "/api/mobile/v1/devices/register", buildJsonObject {
            put("installation_id", g.keys.installationId)
            put("public_key", g.keys.publicKeyB64())
            put("manufacturer", Build.MANUFACTURER); put("model", Build.MODEL)
            put("os_version", Build.VERSION.RELEASE); put("sdk_int", Build.VERSION.SDK_INT)
            put("app_version", BuildConfig.VERSION_NAME)
        }, ApiClient.Auth.NONE).obj()
        g.store.putString("registered", "1")
        applyStatus(r)
    }

    private suspend fun refreshStatus() {
        val status = try {
            g.api.call("GET", "/api/mobile/v1/device/status", null, ApiClient.Auth.SIGNED).obj()
        } catch (e: ApiException) {
            // 401 on the SIGNED status call means the server does not know this key: register again.
            if (e.status == 401) { g.store.putString("registered", null); screen.value = Screen.Connect } else error.value = e.message
            return
        } catch (e: java.io.IOException) {
            offlineFallback()
            return
        }
        try {
            applyStatus(status)
        } catch (e: ApiException) {
            // Work-session problems (expired / signed out elsewhere) lead back to Login, never to re-registration.
            if (e.status in 401..403 && e.code != "device_not_compliant") { g.session.clearWork(); screen.value = Screen.Login } else error.value = e.message
        } catch (e: java.io.IOException) {
            offlineFallback()
        }
    }

    private suspend fun applyStatus(r: JsonObject) {
        when (r.str("state")) {
            "pending" -> { screen.value = Screen.Pending(r.str("approval_code") ?: ""); pollApproval() }
            "approved" -> if (g.session.hasWorkSession) enterWork() else screen.value = Screen.Login
            else -> { stopWork(); g.session.clearWork(); g.work.clearWorkData(); screen.value = Screen.Ended(r.str("state") ?: "revoked") }
        }
    }

    /** Signed polling with server hint + exponential backoff + jitter. */
    private fun pollApproval() {
        if (poller?.isActive == true) return
        poller = viewModelScope.launch {
            var attempt = 0
            var hint: Int? = null
            while (screen.value is Screen.Pending) {
                delay(Backoff.pollDelaySeconds(hint, attempt++) * 1000)
                try {
                    val s = g.api.call("GET", "/api/mobile/v1/device/status", null, ApiClient.Auth.SIGNED).obj()
                    hint = s.str("poll_after_seconds")?.toIntOrNull()
                    if (s.str("state") != "pending") { refreshStatus(); return@launch }
                } catch (e: ApiException) {
                    if (e.status == 401) { refreshStatus(); return@launch }   // unknown key → back to Connect
                } catch (e: Exception) {
                    // offline: keep polling with backoff
                }
            }
        }
    }

    fun login(user: String, password: String) = act {
        g.session.login(user.trim(), password)
        enterWork()
    }

    /** Steps 12–14: verify, apply policy, report, then open the dashboard only if compliant. */
    private suspend fun enterWork() {
        val ack = g.work.syncPolicy()
        val me = g.session.work("GET", "/api/mobile/v1/me").obj()
        me["realtime"]?.let { rt -> if (rt is JsonObject) { g.realtimeUrl = rt.str("ws_url"); g.realtimeChannel = rt.str("channel") } }
        me["disclosure"]?.jsonObject?.let { d ->
            disclosure.value = Disclosure(d.str("calls_recorded") == "true", d.str("recording_notice") ?: "",
                d["location"]?.let { if (it is JsonObject) "Every ${it.str("interval_seconds")} s while signed in" else null }, d.str("live_view_possible") == "true", d.str("camera_sessions_possible") == "true")
        }
        if (ack.str("compliant") != "true") {
            screen.value = Screen.Policy(ack.str("state") ?: "failed", me["device"]?.jsonObject?.get("failing_mandatory")?.jsonArray?.map { it.toString().trim('"') } ?: emptyList())
            return
        }
        screen.value = Screen.Dashboard
        g.realtime.start()
        if (g.policy.bool("location.enabled")) LocationService.start(getApplication())   // no-op if permission denied (reported to server via policy ack)
        runCatching { g.work.syncAll() }
        dispositions.value = runCatching { g.session.work("GET", "/api/mobile/v1/dispositions").jsonArray.map { it.jsonObject.str("code")!! to it.jsonObject.str("label")!! } }.getOrDefault(emptyList())
        g.media.refresh()
    }

    fun retryPolicy() = act { enterWork() }

    private fun offlineFallback() {
        // Offline: work functions only within the server-issued lease; device restrictions are unaffected either way.
        screen.value = if (g.session.hasWorkSession && g.session.lease.isValid(System.currentTimeMillis())) Screen.Dashboard
        else if (g.session.hasWorkSession) Screen.Locked("Offline access period has ended. Connect to the internet to continue.")
        else Screen.Login
    }

    fun refresh() = act { g.work.syncAll(); g.media.refresh() }

    fun logout() = act {
        stopWork()
        g.session.logout()
        g.work.clearWorkData()
        screen.value = Screen.Login
    }

    /** After revocation/rejection, an administrator may ask the employee to register again: needs a brand-new key. */
    fun startNewRegistration() {
        g.session.wipeIdentity()
        g.store.putString("registered", null)
        screen.value = Screen.Connect
    }

    fun placeCall(c: CachedCustomer, which: String) = act {
        if (!g.session.lease.isValid(System.currentTimeMillis()) && !sync.value.online) throw ApiException(0, "offline", "Calling needs a connection. It will not switch to SIM calling.")
        val r = g.session.work("POST", "/api/mobile/v1/calls", buildJsonObject { put("customer_id", c.id); put("which", which) }).obj()
        call.value = CallUi(r.str("call_id")!!, r.str("state")!!, 0, null, r.str("recording_status") ?: "", r.str("agent_leg") ?: "", c)
        watchCall()
    }

    private fun watchCall() = viewModelScope.launch {
        while (true) {
            val cur = call.value ?: return@launch
            delay(2000)
            val r = runCatching { g.session.work("GET", "/api/mobile/v1/calls/${cur.id}").obj() }.getOrNull() ?: continue
            val state = r.str("state") ?: continue
            call.value = cur.copy(state = state, talk = r.str("talk_seconds")?.toIntOrNull() ?: 0, ring = r.str("ring_seconds")?.toIntOrNull(), recording = r.str("recording_status") ?: "")
            if (r.str("state") in TERMINAL) return@launch
        }
    }

    fun hangup() = act { call.value?.let { g.session.work("POST", "/api/mobile/v1/calls/${it.id}/hangup") } }

    /** Disposition goes through the offline queue (idempotent) so it is never lost on a bad connection. */
    fun submitDisposition(code: String, notes: String, followUpIso: String?) = act {
        val c = call.value ?: return@act
        g.work.enqueue("disposition", buildJsonObject { put("call_id", c.id); put("code", code); put("notes", notes); followUpIso?.let { put("follow_up_at", it) } })
        call.value = null
        runCatching { g.work.syncAll() }
    }

    fun acceptMedia() { pendingMedia.value?.let { g.media.accept(it) } }
    fun consentLaunched() = g.media.consentLaunched()
    fun declineMedia() { pendingMedia.value?.let { g.media.decline(it) } }
    fun mediaConsent(projection: android.content.Intent?, kind: String) {
        if (kind == "screen") { if (projection == null) g.media.osConsentDenied() else g.media.startScreen(projection) }
        else { if (projection == null) g.media.osConsentDenied() else g.media.startCamera() }
    }
    fun stopMedia() = g.media.endActive("employee_stopped")

    private fun stopWork() {
        g.realtime.stop()
        LocationService.stop(getApplication())
        g.media.endActive("employee_stopped")
    }

    private suspend fun loadBranding(throwOnError: Boolean = false) {
        try {
            val b = g.api.call("GET", "/api/mobile/v1/bootstrap", null, ApiClient.Auth.NONE).obj()["branding"]!!.jsonObject
            g.store.writeFile("branding.json", b.toString())
            applyBranding(b, fetchLogo(b))
        } catch (e: Exception) {
            if (throwOnError) throw (e as? ApiException ?: ApiException(0, "unreachable", "Could not reach the server. Check the address and your connection."))
            g.store.readFile("branding.json")?.let { applyBranding(g.api.json.parseToJsonElement(it).jsonObject, cachedLogo()) }
        }
    }

    private fun applyBranding(b: JsonObject, logo: Bitmap?) {
        branding.value = Branding(b.str("display_name") ?: BuildConfig.PRODUCT_NAME, b.str("primary_color") ?: "#1F3A5F", logo)
    }

    /** Logo is accepted only if its SHA-256 matches what the server's branding record says. */
    private suspend fun fetchLogo(b: JsonObject): Bitmap? {
        val url = b.str("logo_url") ?: return null
        val sha = b.str("logo_sha256") ?: return null
        val origin = g.config.serverOrigin ?: return null
        if (!url.startsWith("$origin/")) return null   // only from our own server; never send the workspace header elsewhere
        val bytes = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { okhttp3.OkHttpClient().newCall(okhttp3.Request.Builder().url(url).apply { g.config.workspace?.let { header("X-Workspace", it) } }.build()).execute().use { it.body?.bytes() } }.getOrNull()
        } ?: return cachedLogo()
        if (RequestSigning.sha256Hex(bytes) != sha) return null
        File(getApplication<Application>().filesDir, "branding_logo").writeBytes(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun cachedLogo(): Bitmap? = File(getApplication<Application>().filesDir, "branding_logo").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    private fun act(block: suspend () -> Unit) = viewModelScope.launch {
        busy.value = true
        error.value = null
        try { block() } catch (e: ApiException) { error.value = e.message } catch (e: java.io.IOException) { error.value = "No connection to the server." }
        catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { error.value = e.message ?: "Unexpected error" }
        finally { busy.value = false }
    }

    companion object { val TERMINAL = setOf("completed", "disconnected", "busy", "no_answer", "rejected", "failed", "cancelled", "agent_unanswered") }
}
