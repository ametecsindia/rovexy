package ametecs.managedmobile

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import ametecs.managedmobile.core.PushRouting
import ametecs.managedmobile.data.ApiClient
import ametecs.managedmobile.data.ServerConfig
import ametecs.managedmobile.data.SessionManager
import ametecs.managedmobile.data.WorkRepository
import ametecs.managedmobile.media.MediaCoordinator
import ametecs.managedmobile.policy.PolicyEnforcer
import ametecs.managedmobile.realtime.PusherClient
import ametecs.managedmobile.security.DeviceKeys
import ametecs.managedmobile.security.SecureStore
import ametecs.managedmobile.work.SyncWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.json.JsonObject

class AmmpApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_WORK, getString(R.string.notif_channel_work), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_MONITOR, getString(R.string.notif_channel_monitor), NotificationManager.IMPORTANCE_HIGH))
        SyncWorker.schedulePeriodic(this)
    }

    companion object {
        const val CHANNEL_WORK = "work_session"
        const val CHANNEL_MONITOR = "monitoring_sessions"
    }
}

/** Manual DI: one instance of each collaborator for the process. */
class AppGraph(app: Application) {
    val store = SecureStore(app)
    val keys = DeviceKeys(store, app.packageManager)
    val config = ServerConfig(app, store)
    val api = ApiClient(config, keys)
    val session = SessionManager(api, store, keys)
    val policy = PolicyEnforcer(app)
    val work = WorkRepository(session, store, policy, api)
    val media = MediaCoordinator(app, session)
    val pushDestination = MutableStateFlow(PushRouting.destinationFor(null))
    @Volatile var realtimeUrl: String? = null
    @Volatile var realtimeChannel: String? = null
    var onServerEvent: ((String, JsonObject) -> Unit)? = null

    val realtime = PusherClient(config, { realtimeUrl }, { session.accessToken() }, { realtimeChannel },
        onEvent = { type, data ->
            when (type) {
                "media.requested" -> media.refresh()
                "media.signal" -> media.onRemoteSignal(data["data"] as? JsonObject ?: data)
                "media.updated" -> media.onRemoteState(data["data"] as? JsonObject ?: data)
                else -> SyncWorker.syncNow(app)
            }
            onServerEvent?.invoke(type, data)
        },
        onAuthFailed = { onServerEvent?.invoke("session.revalidate", JsonObject(emptyMap())) })

    fun onPush(reason: String?) {
        pushDestination.value = PushRouting.destinationFor(reason)
        if (reason == "media") media.refresh()
    }
}
